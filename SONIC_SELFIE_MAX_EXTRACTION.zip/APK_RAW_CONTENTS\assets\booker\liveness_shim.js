// APK adaptation shim — provides the small slice of the chrome.* extension API
// that the OPV5 content scripts use, bridging it to the native Android layer.
//
//  * chrome.runtime.sendMessage({action:"saveCredentials", payload})  →
//        AndroidBridge.saveSpoof(ip, oz_plugin, user_agent, bls_host)
//    so the native WebView can spoof User-Agent (and X-Forwarded-For on GETs),
//    exactly like the extension's background.js webRequest listener did.
//  * chrome.storage.local  →  localStorage-backed (retryurl etc.)
//
// Runs at document_start, before liveness_wafblock.js and liveness_content.js.
(function () {
  'use strict';
  if (window.__blsShimInstalled) return;
  window.__blsShimInstalled = true;

  function bridgeSaveSpoof(p) {
    try {
      if (window.AndroidBridge && AndroidBridge.saveSpoof) {
        AndroidBridge.saveSpoof(
          (p && p.host) || '',
          (p && p.oz_plugin) || '',
          (p && p.user_agents) || '',
          (p && p.bls_host) || '',
          (p && p.proxyline) || ''
        );
      }
    } catch (e) {}
  }

  if (typeof window.chrome === 'undefined' || !window.chrome) {
    window.chrome = {};
  }
  if (!window.chrome.runtime) {
    window.chrome.runtime = {
      lastError: null,
      sendMessage: function (message, callback) {
        try {
          if (message && message.action === 'saveCredentials' && message.payload) {
            bridgeSaveSpoof(message.payload);
          }
        } catch (e) {}
        if (typeof callback === 'function') {
          try { callback({ status: 'success', received: true }); } catch (e) {}
        }
      },
      onMessage: { addListener: function () {}, removeListener: function () {} },
      onInstalled: { addListener: function () {} },
      onStartup: { addListener: function () {} }
    };
  }
  if (!window.chrome.storage) {
    window.chrome.storage = {
      local: {
        set: function (obj, cb) {
          try {
            Object.keys(obj || {}).forEach(function (k) {
              localStorage.setItem('cs_' + k, JSON.stringify(obj[k]));
            });
          } catch (e) {}
          if (typeof cb === 'function') try { cb(); } catch (e) {}
        },
        get: function (keys, cb) {
          var out = {};
          try {
            var list = Array.isArray(keys) ? keys
                     : (typeof keys === 'string' ? [keys] : Object.keys(keys || {}));
            list.forEach(function (k) {
              var v = localStorage.getItem('cs_' + k);
              if (v !== null) { try { out[k] = JSON.parse(v); } catch (e) { out[k] = v; } }
            });
          } catch (e) {}
          if (typeof cb === 'function') try { cb(out); } catch (e) {}
        }
      }
    };
  }
})();
