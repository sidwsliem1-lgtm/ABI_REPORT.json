  (function () {
    "use strict";
    
    // AWS WAF token endpoint to block
    const awsWafTokenEndpoint = "5f2749aa43d4.695b66d7.eu-central-1.token.awswaf.com";
    
    // Empty function (placeholder - note: errorMessage is undefined in original)
    function handleError(message) {}
    
    // Store reference to original fetch function
    const originalFetch = window.fetch;
    
    // Override the fetch function to intercept requests
    window.fetch = async function (url, options) {
      // Check if the request URL contains the AWS WAF token endpoint
      if (typeof url === "string" && url.includes(awsWafTokenEndpoint)) {
        //console.warn("[BLS Anti-WAF] " + errorMessage); // Note: errorMessage is undefined in original
        handleError(errorMessage); // Note: errorMessage is undefined in original
        return Promise.reject(new Error(errorMessage)); // Note: errorMessage is undefined in original
      } else {
        // For all other requests, use the original fetch function
        return originalFetch.call(this, url, options);
      }
    };
    
    //console.log("[BLS Anti-WAF] Script initialized. Intercepting requests to AWS WAF token endpoint.");
  })();