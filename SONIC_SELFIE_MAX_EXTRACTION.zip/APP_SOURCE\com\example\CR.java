package com.example;

/* JADX INFO: renamed from: com.example.R, reason: invalid class name */
/* JADX INFO: loaded from: classes2.dex */
public final class CR {

    /* JADX INFO: renamed from: com.example.R$color */
    public static final class color {
        public static int black = 2130837506;
        public static int purple_200 = 2130837522;
        public static int purple_500 = 2130837523;
        public static int purple_700 = 2130837524;
        public static int teal_200 = 2130837525;
        public static int teal_700 = 2130837526;
        public static int white = 2130837529;

        private color() {
        }
    }

    /* JADX INFO: renamed from: com.example.R$drawable */
    public static final class drawable {
        public static int ic_launcher_background = 2130968603;
        public static int ic_launcher_foreground = 2130968604;

        private drawable() {
        }
    }

    /* JADX INFO: renamed from: com.example.R$mipmap */
    public static final class mipmap {
        public static int ic_launcher = 2131230720;
        public static int ic_launcher_round = 2131230721;

        private mipmap() {
        }
    }

    /* JADX INFO: renamed from: com.example.R$raw */
    public static final class raw {
        public static int mitm = 2131296258;
        public static int mitm_ca = 2131296259;

        private raw() {
        }
    }

    /* JADX INFO: renamed from: com.example.R$string */
    public static final class string {
        public static int app_name = 2131361793;

        private string() {
        }
    }

    /* JADX INFO: renamed from: com.example.R$style */
    public static final class style {
        public static int Theme_MyApplication = 2131427338;

        private style() {
        }
    }

    /* JADX INFO: renamed from: com.example.R$xml */
    public static final class xml {
        public static int backup_rules = 2131558400;
        public static int data_extraction_rules = 2131558401;
        public static int network_security_config = 2131558402;

        private xml() {
        }
    }

    private CR() {
    }
}
