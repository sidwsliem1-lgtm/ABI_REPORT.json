package com.example;

import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.activity.compose.ComponentActivityKt;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;

/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 \t2\u00020\u0001:\u0001\tB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0014J\b\u0010\b\u001a\u00020\u0005H\u0002¨\u0006\n"}, m٨٧٩٩d2 = {"Lcom/example/MainActivity;", "Landroidx/activity/ComponentActivity;", "<init>", "()V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "ensureMediaPermissions", "Companion", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class MainActivity extends ComponentActivity {
    private static final int REQUEST_MEDIA = 1001;
    public static final int $stable = 8;

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable$default(this, null, null, 3, null);
        ensureMediaPermissions();
        ComponentActivityKt.setContent$default(this, null, ComposableSingletons$MainActivityKt.INSTANCE.m٨٣٤٣getLambda$601144069$app(), 1, null);
    }

    private final void ensureMediaPermissions() {
        Collection arrayList = new ArrayList();
        for (String str : new String[]{"android.permission.CAMERA", "android.permission.RECORD_AUDIO"}) {
            if (ContextCompat.checkSelfPermission(this, str) != 0) {
                arrayList.add(str);
            }
        }
        Collection needed = (List) arrayList;
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, (String[]) needed.toArray(new String[0]), 1001);
        }
    }
}
