package com.example.data.api;

import com.google.android.gms.common.internal.ImagesContract;
import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Url;

/* JADX INFO: compiled from: AchatApiService.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(m٨٧٩٨d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J2\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\b\b\u0001\u0010\u0005\u001a\u00020\u00062\b\b\u0001\u0010\u0007\u001a\u00020\u00062\b\b\u0001\u0010\b\u001a\u00020\tH§@¢\u0006\u0002\u0010\nJ(\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\u00032\b\b\u0001\u0010\u0005\u001a\u00020\u00062\b\b\u0001\u0010\b\u001a\u00020\rH§@¢\u0006\u0002\u0010\u000e¨\u0006\u000fÀ\u0006\u0003"}, m٨٧٩٩d2 = {"Lcom/example/data/api/AchatApiService;", "", "checkSession", "Lretrofit2/Response;", "Lcom/example/data/api/CheckResponse;", ImagesContract.URL, "", "authHeader", "body", "Lcom/example/data/api/CheckRequest;", "(Ljava/lang/String;Ljava/lang/String;Lcom/example/data/api/CheckRequest;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "resolveSyncCode", "Lcom/example/data/api/SyncCodeResponse;", "Lcom/example/data/api/SyncCodeRequest;", "(Ljava/lang/String;Lcom/example/data/api/SyncCodeRequest;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public interface AchatApiService {
    @POST
    Object checkSession(@Url String str, @Header("Authorization") String str2, @Body CheckRequest checkRequest, Continuation<? super Response<CheckResponse>> continuation);

    @POST
    Object resolveSyncCode(@Url String str, @Body SyncCodeRequest syncCodeRequest, Continuation<? super Response<SyncCodeResponse>> continuation);
}
