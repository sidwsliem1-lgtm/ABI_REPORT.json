package com.example.data.api;

import androidx.compose.animation.core.AnimationKt;
import com.example.util.DebugLog;
import io.ktor.sse.ServerSentEventKt;
import java.util.concurrent.TimeUnit;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import okio.Buffer;
import retrofit2.Retrofit;
import retrofit2.converter.moshi.MoshiConverterFactory;

/* JADX INFO: compiled from: AchatNetworkClient.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082T¢\u0006\u0002\n\u0000R\u001b\u0010\f\u001a\u00020\r8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0012"}, m٨٧٩٩d2 = {"Lcom/example/data/api/AchatNetworkClient;", "", "<init>", "()V", "loggingInterceptor", "Lokhttp3/logging/HttpLoggingInterceptor;", "debugInterceptor", "Lokhttp3/Interceptor;", "okHttpClient", "Lokhttp3/OkHttpClient;", "DEFAULT_BASE_URL", "", "apiService", "Lcom/example/data/api/AchatApiService;", "getApiService", "()Lcom/example/data/api/AchatApiService;", "apiService$delegate", "Lkotlin/Lazy;", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class AchatNetworkClient {
    public static final int $stable;
    private static final String DEFAULT_BASE_URL = "https://dz.blsappointment.com/";
    public static final AchatNetworkClient INSTANCE = new AchatNetworkClient();

    /* JADX INFO: renamed from: apiService$delegate, reason: from kotlin metadata */
    private static final Lazy apiService;
    private static final Interceptor debugInterceptor;
    private static final HttpLoggingInterceptor loggingInterceptor;
    private static final OkHttpClient okHttpClient;

    private AchatNetworkClient() {
    }

    static {
        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor(null, 1, null);
        httpLoggingInterceptor.level(HttpLoggingInterceptor.Level.BODY);
        loggingInterceptor = httpLoggingInterceptor;
        debugInterceptor = new Interceptor() { // from class: com.example.data.api.AchatNetworkClient$$ExternalSyntheticLambda0
            @Override // okhttp3.Interceptor
            public final Response intercept(Interceptor.Chain chain) {
                return AchatNetworkClient.debugInterceptor$lambda$3(chain);
            }
        };
        okHttpClient = new OkHttpClient.Builder().connectTimeout(15L, TimeUnit.SECONDS).readTimeout(15L, TimeUnit.SECONDS).writeTimeout(15L, TimeUnit.SECONDS).addInterceptor(loggingInterceptor).addInterceptor(debugInterceptor).addInterceptor(new Interceptor() { // from class: com.example.data.api.AchatNetworkClient$special$$inlined$-addInterceptor$1
            @Override // okhttp3.Interceptor
            public final Response intercept(Interceptor.Chain chain) {
                Intrinsics.checkNotNullParameter(chain, "chain");
                return chain.proceed(chain.request().newBuilder().header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36").header("Accept", "application/json").build());
            }
        }).build();
        apiService = LazyKt.lazy(new Function0() { // from class: com.example.data.api.AchatNetworkClient$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return AchatNetworkClient.apiService_delegate$lambda$5();
            }
        });
        $stable = 8;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0026  */
    static final Response debugInterceptor$lambda$3(Interceptor.Chain chain) throws Exception {
        String reqBody;
        String strMaskToken;
        String respText;
        Intrinsics.checkNotNullParameter(chain, "chain");
        Request request = chain.request();
        try {
            RequestBody requestBodyBody = request.body();
            if (requestBodyBody != null) {
                Buffer buffer = new Buffer();
                requestBodyBody.writeTo(buffer);
                reqBody = buffer.readUtf8();
                if (reqBody == null) {
                    reqBody = "";
                }
            } else {
                reqBody = "";
            }
        } catch (Exception e) {
            reqBody = "<body read error: " + e.getMessage() + ">";
        }
        String strHeader = request.header("Authorization");
        if (strHeader == null || (strMaskToken = DebugLog.INSTANCE.maskToken(strHeader)) == null) {
            strMaskToken = "<none>";
        }
        String auth = strMaskToken;
        DebugLog.INSTANCE.add("HTTP→", request.method() + ServerSentEventKt.SPACE + request.url() + "  auth=" + auth + "  body=" + reqBody);
        long startNs = System.nanoTime();
        try {
            Response response = chain.proceed(request);
            long ms = (System.nanoTime() - startNs) / AnimationKt.MillisToNanos;
            try {
                respText = response.peekBody(AnimationKt.MillisToNanos).string();
            } catch (Exception e2) {
                respText = "<response read error: " + e2.getMessage() + ">";
            }
            String ctype = Response.header$default(response, "Content-Type", null, 2, null);
            if (ctype == null) {
                ctype = "?";
            }
            DebugLog.INSTANCE.add("HTTP←", response.code() + ServerSentEventKt.SPACE + response.message() + " (" + ms + "ms) type=" + ctype + "  body=" + StringsKt.take(respText, 1200));
            return response;
        } catch (Exception e3) {
            DebugLog.INSTANCE.add("HTTP✗", "network failure: " + e3.getClass().getSimpleName() + ": " + e3.getMessage());
            throw e3;
        }
    }

    public final AchatApiService getApiService() {
        Object value = apiService.getValue();
        Intrinsics.checkNotNullExpressionValue(value, "getValue(...)");
        return (AchatApiService) value;
    }

    static final AchatApiService apiService_delegate$lambda$5() {
        return (AchatApiService) new Retrofit.Builder().baseUrl(DEFAULT_BASE_URL).client(okHttpClient).addConverterFactory(MoshiConverterFactory.create()).build().create(AchatApiService.class);
    }
}
