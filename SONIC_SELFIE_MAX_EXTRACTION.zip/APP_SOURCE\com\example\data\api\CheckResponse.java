package com.example.data.api;

import androidx.core.app.NotificationCompat;
import com.squareup.moshi.JsonClass;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CheckModels.kt */
/* JADX INFO: loaded from: classes7.dex */
@JsonClass(generateAdapter = true)
@Metadata(m٨٧٩٨d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\r\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u000e\u001a\u0004\u0018\u00010\u0003HÆ\u0003J+\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0003HÆ\u0001J\u0013\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001J\t\u0010\u0015\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\t¨\u0006\u0016"}, m٨٧٩٩d2 = {"Lcom/example/data/api/CheckResponse;", "", NotificationCompat.CATEGORY_STATUS, "", "cr", "message", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getStatus", "()Ljava/lang/String;", "getCr", "getMessage", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final /* data */ class CheckResponse {
    public static final int $stable = 0;
    private final String cr;
    private final String message;
    private final String status;

    public static /* synthetic */ CheckResponse copy$default(CheckResponse checkResponse, String str, String str2, String str3, int i, Object obj) {
        if ((i & 1) != 0) {
            str = checkResponse.status;
        }
        if ((i & 2) != 0) {
            str2 = checkResponse.cr;
        }
        if ((i & 4) != 0) {
            str3 = checkResponse.message;
        }
        return checkResponse.copy(str, str2, str3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getCr() {
        return this.cr;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getMessage() {
        return this.message;
    }

    public final CheckResponse copy(String status, String cr, String message) {
        Intrinsics.checkNotNullParameter(status, "status");
        return new CheckResponse(status, cr, message);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CheckResponse)) {
            return false;
        }
        CheckResponse checkResponse = (CheckResponse) other;
        return Intrinsics.areEqual(this.status, checkResponse.status) && Intrinsics.areEqual(this.cr, checkResponse.cr) && Intrinsics.areEqual(this.message, checkResponse.message);
    }

    public int hashCode() {
        return (((this.status.hashCode() * 31) + (this.cr == null ? 0 : this.cr.hashCode())) * 31) + (this.message != null ? this.message.hashCode() : 0);
    }

    public String toString() {
        return "CheckResponse(status=" + this.status + ", cr=" + this.cr + ", message=" + this.message + ")";
    }

    public CheckResponse(String status, String cr, String message) {
        Intrinsics.checkNotNullParameter(status, "status");
        this.status = status;
        this.cr = cr;
        this.message = message;
    }

    public /* synthetic */ CheckResponse(String str, String str2, String str3, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, (i & 2) != 0 ? null : str2, (i & 4) != 0 ? null : str3);
    }

    public final String getStatus() {
        return this.status;
    }

    public final String getCr() {
        return this.cr;
    }

    public final String getMessage() {
        return this.message;
    }
}
