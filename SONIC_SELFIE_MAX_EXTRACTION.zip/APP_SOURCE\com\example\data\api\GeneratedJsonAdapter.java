package com.example.data.api;

import androidx.core.app.NotificationCompat;
import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.JsonReader;
import com.squareup.moshi.JsonWriter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.internal.Util;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import kotlin.Metadata;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: renamed from: com.example.data.api.SyncCodeResponseJsonAdapter, reason: from toString */
/* JADX INFO: compiled from: SyncCodeResponseJsonAdapter.kt */
/* JADX INFO: loaded from: classes7.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\b\u0010\u000e\u001a\u00020\nH\u0016J\u0010\u0010\u000f\u001a\u00020\u00022\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u001a\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0002H\u0016R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u000b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0017"}, m٨٧٩٩d2 = {"Lcom/example/data/api/SyncCodeResponseJsonAdapter;", "Lcom/squareup/moshi/JsonAdapter;", "Lcom/example/data/api/SyncCodeResponse;", "moshi", "Lcom/squareup/moshi/Moshi;", "<init>", "(Lcom/squareup/moshi/Moshi;)V", "options", "Lcom/squareup/moshi/JsonReader$Options;", "stringAdapter", "", "nullableStringAdapter", "constructorRef", "Ljava/lang/reflect/Constructor;", "toString", "fromJson", "reader", "Lcom/squareup/moshi/JsonReader;", "toJson", "", "writer", "Lcom/squareup/moshi/JsonWriter;", "value_", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class GeneratedJsonAdapter extends JsonAdapter<SyncCodeResponse> {
    public static final int $stable = 8;
    private volatile Constructor<SyncCodeResponse> constructorRef;
    private final JsonAdapter<String> nullableStringAdapter;
    private final JsonReader.Options options;
    private final JsonAdapter<String> stringAdapter;

    public GeneratedJsonAdapter(Moshi moshi) {
        Intrinsics.checkNotNullParameter(moshi, "moshi");
        JsonReader.Options options = JsonReader.Options.m٨٧٢٦of(NotificationCompat.CATEGORY_STATUS, "session_id", "client_token", "message");
        Intrinsics.checkNotNullExpressionValue(options, "of(...)");
        this.options = options;
        JsonAdapter<String> jsonAdapterAdapter = moshi.adapter(String.class, SetsKt.emptySet(), NotificationCompat.CATEGORY_STATUS);
        Intrinsics.checkNotNullExpressionValue(jsonAdapterAdapter, "adapter(...)");
        this.stringAdapter = jsonAdapterAdapter;
        JsonAdapter<String> jsonAdapterAdapter2 = moshi.adapter(String.class, SetsKt.emptySet(), "session_id");
        Intrinsics.checkNotNullExpressionValue(jsonAdapterAdapter2, "adapter(...)");
        this.nullableStringAdapter = jsonAdapterAdapter2;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(38);
        sb.append("GeneratedJsonAdapter(").append("SyncCodeResponse").append(')');
        return sb.toString();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.squareup.moshi.JsonAdapter
    public SyncCodeResponse fromJson(JsonReader reader) throws IllegalAccessException, NoSuchMethodException, InstantiationException, IOException, InvocationTargetException {
        Intrinsics.checkNotNullParameter(reader, "reader");
        int mask0 = -1;
        reader.beginObject();
        String status = null;
        String session_id = null;
        String client_token = null;
        String message = null;
        while (reader.hasNext()) {
            switch (reader.selectName(this.options)) {
                case -1:
                    reader.skipName();
                    reader.skipValue();
                    break;
                case 0:
                    String strFromJson = this.stringAdapter.fromJson(reader);
                    if (strFromJson == null) {
                        throw Util.unexpectedNull(NotificationCompat.CATEGORY_STATUS, NotificationCompat.CATEGORY_STATUS, reader);
                    }
                    status = strFromJson;
                    break;
                    break;
                case 1:
                    String session_id2 = this.nullableStringAdapter.fromJson(reader);
                    session_id = session_id2;
                    mask0 &= -3;
                    break;
                case 2:
                    String client_token2 = this.nullableStringAdapter.fromJson(reader);
                    client_token = client_token2;
                    mask0 &= -5;
                    break;
                case 3:
                    String message2 = this.nullableStringAdapter.fromJson(reader);
                    message = message2;
                    mask0 &= -9;
                    break;
            }
        }
        reader.endObject();
        if (mask0 == -15) {
            if (status != null) {
                return new SyncCodeResponse(status, session_id, client_token, message);
            }
            throw Util.missingProperty(NotificationCompat.CATEGORY_STATUS, NotificationCompat.CATEGORY_STATUS, reader);
        }
        Constructor<SyncCodeResponse> declaredConstructor = this.constructorRef;
        if (declaredConstructor == null) {
            declaredConstructor = SyncCodeResponse.class.getDeclaredConstructor(String.class, String.class, String.class, String.class, Integer.TYPE, Util.DEFAULT_CONSTRUCTOR_MARKER);
            this.constructorRef = declaredConstructor;
            Intrinsics.checkNotNullExpressionValue(declaredConstructor, "also(...)");
        }
        if (status == null) {
            throw Util.missingProperty(NotificationCompat.CATEGORY_STATUS, NotificationCompat.CATEGORY_STATUS, reader);
        }
        SyncCodeResponse syncCodeResponseNewInstance = declaredConstructor.newInstance(status, session_id, client_token, message, Integer.valueOf(mask0), null);
        Intrinsics.checkNotNullExpressionValue(syncCodeResponseNewInstance, "newInstance(...)");
        return syncCodeResponseNewInstance;
    }

    @Override // com.squareup.moshi.JsonAdapter
    public void toJson(JsonWriter writer, SyncCodeResponse value_) throws IOException {
        Intrinsics.checkNotNullParameter(writer, "writer");
        if (value_ == null) {
            throw new NullPointerException("value_ was null! Wrap in .nullSafe() to write nullable values.");
        }
        writer.beginObject();
        writer.name(NotificationCompat.CATEGORY_STATUS);
        this.stringAdapter.toJson(writer, value_.getStatus());
        writer.name("session_id");
        this.nullableStringAdapter.toJson(writer, value_.getSession_id());
        writer.name("client_token");
        this.nullableStringAdapter.toJson(writer, value_.getClient_token());
        writer.name("message");
        this.nullableStringAdapter.toJson(writer, value_.getMessage());
        writer.endObject();
    }
}
