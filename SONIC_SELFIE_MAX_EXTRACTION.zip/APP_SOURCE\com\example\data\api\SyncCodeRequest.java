package com.example.data.api;

import com.squareup.moshi.JsonClass;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CheckModels.kt */
/* JADX INFO: loaded from: classes7.dex */
@JsonClass(generateAdapter = true)
@Metadata(m٨٧٩٨d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0010"}, m٨٧٩٩d2 = {"Lcom/example/data/api/SyncCodeRequest;", "", "gcs", "", "<init>", "(Ljava/lang/String;)V", "getGcs", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "hashCode", "", "toString", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final /* data */ class SyncCodeRequest {
    public static final int $stable = 0;
    private final String gcs;

    public static /* synthetic */ SyncCodeRequest copy$default(SyncCodeRequest syncCodeRequest, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = syncCodeRequest.gcs;
        }
        return syncCodeRequest.copy(str);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getGcs() {
        return this.gcs;
    }

    public final SyncCodeRequest copy(String gcs) {
        Intrinsics.checkNotNullParameter(gcs, "gcs");
        return new SyncCodeRequest(gcs);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        return (other instanceof SyncCodeRequest) && Intrinsics.areEqual(this.gcs, ((SyncCodeRequest) other).gcs);
    }

    public int hashCode() {
        return this.gcs.hashCode();
    }

    public String toString() {
        return "SyncCodeRequest(gcs=" + this.gcs + ")";
    }

    public SyncCodeRequest(String gcs) {
        Intrinsics.checkNotNullParameter(gcs, "gcs");
        this.gcs = gcs;
    }

    public final String getGcs() {
        return this.gcs;
    }
}
