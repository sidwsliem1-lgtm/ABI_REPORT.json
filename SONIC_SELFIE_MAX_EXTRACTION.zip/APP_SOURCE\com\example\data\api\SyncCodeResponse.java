package com.example.data.api;

import androidx.core.app.NotificationCompat;
import com.squareup.moshi.JsonClass;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CheckModels.kt */
/* JADX INFO: loaded from: classes7.dex */
@JsonClass(generateAdapter = true)
@Metadata(m٨٧٩٨d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B3\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u000f\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0010\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u000b\u0010\u0011\u001a\u0004\u0018\u00010\u0003HÆ\u0003J7\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0003HÆ\u0001J\u0013\u0010\u0013\u001a\u00020\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0016\u001a\u00020\u0017HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0019"}, m٨٧٩٩d2 = {"Lcom/example/data/api/SyncCodeResponse;", "", NotificationCompat.CATEGORY_STATUS, "", "session_id", "client_token", "message", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getStatus", "()Ljava/lang/String;", "getSession_id", "getClient_token", "getMessage", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final /* data */ class SyncCodeResponse {
    public static final int $stable = 0;
    private final String client_token;
    private final String message;
    private final String session_id;
    private final String status;

    public static /* synthetic */ SyncCodeResponse copy$default(SyncCodeResponse syncCodeResponse, String str, String str2, String str3, String str4, int i, Object obj) {
        if ((i & 1) != 0) {
            str = syncCodeResponse.status;
        }
        if ((i & 2) != 0) {
            str2 = syncCodeResponse.session_id;
        }
        if ((i & 4) != 0) {
            str3 = syncCodeResponse.client_token;
        }
        if ((i & 8) != 0) {
            str4 = syncCodeResponse.message;
        }
        return syncCodeResponse.copy(str, str2, str3, str4);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getSession_id() {
        return this.session_id;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getClient_token() {
        return this.client_token;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getMessage() {
        return this.message;
    }

    public final SyncCodeResponse copy(String status, String session_id, String client_token, String message) {
        Intrinsics.checkNotNullParameter(status, "status");
        return new SyncCodeResponse(status, session_id, client_token, message);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SyncCodeResponse)) {
            return false;
        }
        SyncCodeResponse syncCodeResponse = (SyncCodeResponse) other;
        return Intrinsics.areEqual(this.status, syncCodeResponse.status) && Intrinsics.areEqual(this.session_id, syncCodeResponse.session_id) && Intrinsics.areEqual(this.client_token, syncCodeResponse.client_token) && Intrinsics.areEqual(this.message, syncCodeResponse.message);
    }

    public int hashCode() {
        return (((((this.status.hashCode() * 31) + (this.session_id == null ? 0 : this.session_id.hashCode())) * 31) + (this.client_token == null ? 0 : this.client_token.hashCode())) * 31) + (this.message != null ? this.message.hashCode() : 0);
    }

    public String toString() {
        return "SyncCodeResponse(status=" + this.status + ", session_id=" + this.session_id + ", client_token=" + this.client_token + ", message=" + this.message + ")";
    }

    public SyncCodeResponse(String status, String session_id, String client_token, String message) {
        Intrinsics.checkNotNullParameter(status, "status");
        this.status = status;
        this.session_id = session_id;
        this.client_token = client_token;
        this.message = message;
    }

    public /* synthetic */ SyncCodeResponse(String str, String str2, String str3, String str4, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, (i & 2) != 0 ? null : str2, (i & 4) != 0 ? null : str3, (i & 8) != 0 ? null : str4);
    }

    public final String getStatus() {
        return this.status;
    }

    public final String getSession_id() {
        return this.session_id;
    }

    public final String getClient_token() {
        return this.client_token;
    }

    public final String getMessage() {
        return this.message;
    }
}
