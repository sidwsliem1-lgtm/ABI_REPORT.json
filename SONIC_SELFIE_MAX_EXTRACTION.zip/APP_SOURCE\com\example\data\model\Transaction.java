package com.example.data.model;

import androidx.core.app.NotificationCompat;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Transaction.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\u001f\b\u0087\b\u0018\u00002\u00020\u0001Ba\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\n\u0012\b\b\u0002\u0010\u000b\u001a\u00020\f\u0012\b\b\u0002\u0010\r\u001a\u00020\f\u0012\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\t\u0010 \u001a\u00020\u0005HÆ\u0003J\u000b\u0010!\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\nHÆ\u0003J\t\u0010#\u001a\u00020\fHÆ\u0003J\t\u0010$\u001a\u00020\fHÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\u0005HÆ\u0003Jg\u0010&\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\f2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010'\u001a\u00020\n2\b\u0010(\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010)\u001a\u00020\u0003HÖ\u0001J\t\u0010*\u001a\u00020\u0005HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0014R\u0013\u0010\b\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0014R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0018R\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\r\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001aR\u0013\u0010\u000e\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0014¨\u0006+"}, m٨٧٩٩d2 = {"Lcom/example/data/model/Transaction;", "", "id", "", "sess", "", "token", NotificationCompat.CATEGORY_STATUS, "cr", "isAutoPolling", "", "createdAt", "", "lastCheckedAt", "lastErrorMessage", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZJJLjava/lang/String;)V", "getId", "()I", "getSess", "()Ljava/lang/String;", "getToken", "getStatus", "getCr", "()Z", "getCreatedAt", "()J", "getLastCheckedAt", "getLastErrorMessage", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final /* data */ class Transaction {
    public static final int $stable = 0;
    private final String cr;
    private final long createdAt;
    private final int id;
    private final boolean isAutoPolling;
    private final long lastCheckedAt;
    private final String lastErrorMessage;
    private final String sess;
    private final String status;
    private final String token;

    public static /* synthetic */ Transaction copy$default(Transaction transaction, int i, String str, String str2, String str3, String str4, boolean z, long j, long j2, String str5, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = transaction.id;
        }
        if ((i2 & 2) != 0) {
            str = transaction.sess;
        }
        if ((i2 & 4) != 0) {
            str2 = transaction.token;
        }
        if ((i2 & 8) != 0) {
            str3 = transaction.status;
        }
        if ((i2 & 16) != 0) {
            str4 = transaction.cr;
        }
        if ((i2 & 32) != 0) {
            z = transaction.isAutoPolling;
        }
        if ((i2 & 64) != 0) {
            j = transaction.createdAt;
        }
        if ((i2 & 128) != 0) {
            j2 = transaction.lastCheckedAt;
        }
        if ((i2 & 256) != 0) {
            str5 = transaction.lastErrorMessage;
        }
        String str6 = str5;
        long j3 = j2;
        long j4 = j;
        String str7 = str4;
        boolean z2 = z;
        return transaction.copy(i, str, str2, str3, str7, z2, j4, j3, str6);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getSess() {
        return this.sess;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getToken() {
        return this.token;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getStatus() {
        return this.status;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getCr() {
        return this.cr;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final boolean getIsAutoPolling() {
        return this.isAutoPolling;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final long getCreatedAt() {
        return this.createdAt;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final long getLastCheckedAt() {
        return this.lastCheckedAt;
    }

    /* JADX INFO: renamed from: component9, reason: from getter */
    public final String getLastErrorMessage() {
        return this.lastErrorMessage;
    }

    public final Transaction copy(int id, String sess, String token, String status, String cr, boolean isAutoPolling, long createdAt, long lastCheckedAt, String lastErrorMessage) {
        Intrinsics.checkNotNullParameter(sess, "sess");
        Intrinsics.checkNotNullParameter(token, "token");
        Intrinsics.checkNotNullParameter(status, "status");
        return new Transaction(id, sess, token, status, cr, isAutoPolling, createdAt, lastCheckedAt, lastErrorMessage);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Transaction)) {
            return false;
        }
        Transaction transaction = (Transaction) other;
        return this.id == transaction.id && Intrinsics.areEqual(this.sess, transaction.sess) && Intrinsics.areEqual(this.token, transaction.token) && Intrinsics.areEqual(this.status, transaction.status) && Intrinsics.areEqual(this.cr, transaction.cr) && this.isAutoPolling == transaction.isAutoPolling && this.createdAt == transaction.createdAt && this.lastCheckedAt == transaction.lastCheckedAt && Intrinsics.areEqual(this.lastErrorMessage, transaction.lastErrorMessage);
    }

    public int hashCode() {
        return (((((((((((((((Integer.hashCode(this.id) * 31) + this.sess.hashCode()) * 31) + this.token.hashCode()) * 31) + this.status.hashCode()) * 31) + (this.cr == null ? 0 : this.cr.hashCode())) * 31) + Boolean.hashCode(this.isAutoPolling)) * 31) + Long.hashCode(this.createdAt)) * 31) + Long.hashCode(this.lastCheckedAt)) * 31) + (this.lastErrorMessage != null ? this.lastErrorMessage.hashCode() : 0);
    }

    public String toString() {
        return "Transaction(id=" + this.id + ", sess=" + this.sess + ", token=" + this.token + ", status=" + this.status + ", cr=" + this.cr + ", isAutoPolling=" + this.isAutoPolling + ", createdAt=" + this.createdAt + ", lastCheckedAt=" + this.lastCheckedAt + ", lastErrorMessage=" + this.lastErrorMessage + ")";
    }

    public Transaction(int id, String sess, String token, String status, String cr, boolean isAutoPolling, long createdAt, long lastCheckedAt, String lastErrorMessage) {
        Intrinsics.checkNotNullParameter(sess, "sess");
        Intrinsics.checkNotNullParameter(token, "token");
        Intrinsics.checkNotNullParameter(status, "status");
        this.id = id;
        this.sess = sess;
        this.token = token;
        this.status = status;
        this.cr = cr;
        this.isAutoPolling = isAutoPolling;
        this.createdAt = createdAt;
        this.lastCheckedAt = lastCheckedAt;
        this.lastErrorMessage = lastErrorMessage;
    }

    public /* synthetic */ Transaction(int i, String str, String str2, String str3, String str4, boolean z, long j, long j2, String str5, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 0 : i, str, str2, (i2 & 8) != 0 ? "Pending" : str3, (i2 & 16) != 0 ? null : str4, (i2 & 32) != 0 ? false : z, (i2 & 64) != 0 ? System.currentTimeMillis() : j, (i2 & 128) != 0 ? 0L : j2, (i2 & 256) != 0 ? null : str5);
    }

    public final int getId() {
        return this.id;
    }

    public final String getSess() {
        return this.sess;
    }

    public final String getToken() {
        return this.token;
    }

    public final String getStatus() {
        return this.status;
    }

    public final String getCr() {
        return this.cr;
    }

    public final boolean isAutoPolling() {
        return this.isAutoPolling;
    }

    public final long getCreatedAt() {
        return this.createdAt;
    }

    public final long getLastCheckedAt() {
        return this.lastCheckedAt;
    }

    public final String getLastErrorMessage() {
        return this.lastErrorMessage;
    }
}
