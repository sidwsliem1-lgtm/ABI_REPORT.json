package com.example.data.p٠١٨db;

import com.example.data.model.Transaction;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

/* JADX INFO: compiled from: TransactionDao.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\bg\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'J\u0018\u0010\u0006\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0007\u001a\u00020\bH§@¢\u0006\u0002\u0010\tJ\u0018\u0010\n\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u000b\u001a\u00020\fH§@¢\u0006\u0002\u0010\rJ\u0016\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0011J\u0016\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0010\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0011J\u0016\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0010\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0011J\u0016\u0010\u0015\u001a\u00020\u00132\u0006\u0010\u0007\u001a\u00020\bH§@¢\u0006\u0002\u0010\t¨\u0006\u0016À\u0006\u0003"}, m٨٧٩٩d2 = {"Lcom/example/data/db/TransactionDao;", "", "getAllTransactions", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/example/data/model/Transaction;", "getTransactionById", "id", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getTransactionBySess", "sess", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertTransaction", "", "transaction", "(Lcom/example/data/model/Transaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "updateTransaction", "", "deleteTransaction", "deleteTransactionById", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public interface TransactionDao {
    Object deleteTransaction(Transaction transaction, Continuation<? super Unit> continuation);

    Object deleteTransactionById(int i, Continuation<? super Unit> continuation);

    Flow<List<Transaction>> getAllTransactions();

    Object getTransactionById(int i, Continuation<? super Transaction> continuation);

    Object getTransactionBySess(String str, Continuation<? super Transaction> continuation);

    Object insertTransaction(Transaction transaction, Continuation<? super Long> continuation);

    Object updateTransaction(Transaction transaction, Continuation<? super Unit> continuation);
}
