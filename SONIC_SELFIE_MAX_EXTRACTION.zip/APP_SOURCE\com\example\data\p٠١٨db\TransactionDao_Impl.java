package com.example.data.p٠١٨db;

import androidx.core.app.NotificationCompat;
import androidx.room.EntityDeleteOrUpdateAdapter;
import androidx.room.EntityInsertAdapter;
import androidx.room.RoomDatabase;
import androidx.room.coroutines.FlowUtil;
import androidx.room.util.DBUtil;
import androidx.room.util.SQLiteStatementUtil;
import androidx.sqlite.SQLiteConnection;
import androidx.sqlite.SQLiteStatement;
import com.example.data.model.Transaction;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.reflect.KClass;
import kotlinx.coroutines.flow.Flow;

/* JADX INFO: compiled from: TransactionDao_Impl.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0007\u0018\u0000 \u001f2\u00020\u0001:\u0001\u001fB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u000fJ\u0016\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u000e\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u000fJ\u0016\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u000e\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u000fJ\u0014\u0010\u0013\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00150\u0014H\u0016J\u0018\u0010\u0016\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0017\u001a\u00020\u0018H\u0096@¢\u0006\u0002\u0010\u0019J\u0018\u0010\u001a\u001a\u0004\u0018\u00010\b2\u0006\u0010\u001b\u001a\u00020\u001cH\u0096@¢\u0006\u0002\u0010\u001dJ\u0016\u0010\u001e\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0018H\u0096@¢\u0006\u0002\u0010\u0019R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\nX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006 "}, m٨٧٩٩d2 = {"Lcom/example/data/db/TransactionDao_Impl;", "Lcom/example/data/db/TransactionDao;", "__db", "Landroidx/room/RoomDatabase;", "<init>", "(Landroidx/room/RoomDatabase;)V", "__insertAdapterOfTransaction", "Landroidx/room/EntityInsertAdapter;", "Lcom/example/data/model/Transaction;", "__deleteAdapterOfTransaction", "Landroidx/room/EntityDeleteOrUpdateAdapter;", "__updateAdapterOfTransaction", "insertTransaction", "", "transaction", "(Lcom/example/data/model/Transaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteTransaction", "", "updateTransaction", "getAllTransactions", "Lkotlinx/coroutines/flow/Flow;", "", "getTransactionById", "id", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getTransactionBySess", "sess", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteTransactionById", "Companion", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class TransactionDao_Impl implements TransactionDao {
    private final RoomDatabase __db;
    private final EntityDeleteOrUpdateAdapter<Transaction> __deleteAdapterOfTransaction;
    private final EntityInsertAdapter<Transaction> __insertAdapterOfTransaction;
    private final EntityDeleteOrUpdateAdapter<Transaction> __updateAdapterOfTransaction;

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    public static final int $stable = 8;

    public TransactionDao_Impl(RoomDatabase __db) {
        Intrinsics.checkNotNullParameter(__db, "__db");
        this.__db = __db;
        this.__insertAdapterOfTransaction = new EntityInsertAdapter<Transaction>() { // from class: com.example.data.db.TransactionDao_Impl.1
            @Override // androidx.room.EntityInsertAdapter
            protected String createQuery() {
                return "INSERT OR REPLACE INTO `transactions` (`id`,`sess`,`token`,`status`,`cr`,`isAutoPolling`,`createdAt`,`lastCheckedAt`,`lastErrorMessage`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?)";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityInsertAdapter
            public void bind(SQLiteStatement statement, Transaction entity) {
                Intrinsics.checkNotNullParameter(statement, "statement");
                Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo٨٣٣٤bindLong(1, entity.getId());
                statement.mo٨٣٣٦bindText(2, entity.getSess());
                statement.mo٨٣٣٦bindText(3, entity.getToken());
                statement.mo٨٣٣٦bindText(4, entity.getStatus());
                String cr = entity.getCr();
                if (cr == null) {
                    statement.mo٨٣٣٥bindNull(5);
                } else {
                    statement.mo٨٣٣٦bindText(5, cr);
                }
                statement.mo٨٣٣٤bindLong(6, entity.isAutoPolling() ? 1L : 0L);
                statement.mo٨٣٣٤bindLong(7, entity.getCreatedAt());
                statement.mo٨٣٣٤bindLong(8, entity.getLastCheckedAt());
                String lastErrorMessage = entity.getLastErrorMessage();
                if (lastErrorMessage == null) {
                    statement.mo٨٣٣٥bindNull(9);
                } else {
                    statement.mo٨٣٣٦bindText(9, lastErrorMessage);
                }
            }
        };
        this.__deleteAdapterOfTransaction = new EntityDeleteOrUpdateAdapter<Transaction>() { // from class: com.example.data.db.TransactionDao_Impl.2
            @Override // androidx.room.EntityDeleteOrUpdateAdapter
            protected String createQuery() {
                return "DELETE FROM `transactions` WHERE `id` = ?";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityDeleteOrUpdateAdapter
            public void bind(SQLiteStatement statement, Transaction entity) {
                Intrinsics.checkNotNullParameter(statement, "statement");
                Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo٨٣٣٤bindLong(1, entity.getId());
            }
        };
        this.__updateAdapterOfTransaction = new EntityDeleteOrUpdateAdapter<Transaction>() { // from class: com.example.data.db.TransactionDao_Impl.3
            @Override // androidx.room.EntityDeleteOrUpdateAdapter
            protected String createQuery() {
                return "UPDATE OR ABORT `transactions` SET `id` = ?,`sess` = ?,`token` = ?,`status` = ?,`cr` = ?,`isAutoPolling` = ?,`createdAt` = ?,`lastCheckedAt` = ?,`lastErrorMessage` = ? WHERE `id` = ?";
            }

            /* JADX INFO: Access modifiers changed from: protected */
            @Override // androidx.room.EntityDeleteOrUpdateAdapter
            public void bind(SQLiteStatement statement, Transaction entity) {
                Intrinsics.checkNotNullParameter(statement, "statement");
                Intrinsics.checkNotNullParameter(entity, "entity");
                statement.mo٨٣٣٤bindLong(1, entity.getId());
                statement.mo٨٣٣٦bindText(2, entity.getSess());
                statement.mo٨٣٣٦bindText(3, entity.getToken());
                statement.mo٨٣٣٦bindText(4, entity.getStatus());
                String cr = entity.getCr();
                if (cr == null) {
                    statement.mo٨٣٣٥bindNull(5);
                } else {
                    statement.mo٨٣٣٦bindText(5, cr);
                }
                statement.mo٨٣٣٤bindLong(6, entity.isAutoPolling() ? 1L : 0L);
                statement.mo٨٣٣٤bindLong(7, entity.getCreatedAt());
                statement.mo٨٣٣٤bindLong(8, entity.getLastCheckedAt());
                String lastErrorMessage = entity.getLastErrorMessage();
                if (lastErrorMessage == null) {
                    statement.mo٨٣٣٥bindNull(9);
                } else {
                    statement.mo٨٣٣٦bindText(9, lastErrorMessage);
                }
                statement.mo٨٣٣٤bindLong(10, entity.getId());
            }
        };
    }

    @Override // com.example.data.p٠١٨db.TransactionDao
    public Object insertTransaction(final Transaction transaction, Continuation<? super Long> continuation) {
        return DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.db.TransactionDao_Impl$$ExternalSyntheticLambda3
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return Long.valueOf(TransactionDao_Impl.insertTransaction$lambda$0(this.f$0, transaction, (SQLiteConnection) obj));
            }
        }, continuation);
    }

    static final long insertTransaction$lambda$0(TransactionDao_Impl this$0, Transaction $transaction, SQLiteConnection _connection) throws Exception {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        long _result = this$0.__insertAdapterOfTransaction.insertAndReturnId(_connection, $transaction);
        return _result;
    }

    @Override // com.example.data.p٠١٨db.TransactionDao
    public Object deleteTransaction(final Transaction transaction, Continuation<? super Unit> continuation) {
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.db.TransactionDao_Impl$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TransactionDao_Impl.deleteTransaction$lambda$1(this.f$0, transaction, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit deleteTransaction$lambda$1(TransactionDao_Impl this$0, Transaction $transaction, SQLiteConnection _connection) throws Exception {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        this$0.__deleteAdapterOfTransaction.handle(_connection, $transaction);
        return Unit.INSTANCE;
    }

    @Override // com.example.data.p٠١٨db.TransactionDao
    public Object updateTransaction(final Transaction transaction, Continuation<? super Unit> continuation) {
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.db.TransactionDao_Impl$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TransactionDao_Impl.updateTransaction$lambda$2(this.f$0, transaction, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit updateTransaction$lambda$2(TransactionDao_Impl this$0, Transaction $transaction, SQLiteConnection _connection) throws Exception {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        this$0.__updateAdapterOfTransaction.handle(_connection, $transaction);
        return Unit.INSTANCE;
    }

    @Override // com.example.data.p٠١٨db.TransactionDao
    public Flow<List<Transaction>> getAllTransactions() {
        final String _sql = "SELECT * FROM transactions ORDER BY createdAt DESC";
        return FlowUtil.createFlow(this.__db, false, new String[]{"transactions"}, new Function1() { // from class: com.example.data.db.TransactionDao_Impl$$ExternalSyntheticLambda6
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TransactionDao_Impl.getAllTransactions$lambda$3(_sql, (SQLiteConnection) obj);
            }
        });
    }

    static final List getAllTransactions$lambda$3(String $_sql, SQLiteConnection _connection) {
        String _tmpCr;
        String _tmpLastErrorMessage;
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            int _tmp = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
            int _columnIndexOfSess = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sess");
            int _columnIndexOfToken = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "token");
            int _columnIndexOfStatus = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, NotificationCompat.CATEGORY_STATUS);
            int _columnIndexOfCr = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cr");
            int _columnIndexOfIsAutoPolling = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "isAutoPolling");
            int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
            int _columnIndexOfLastCheckedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastCheckedAt");
            int _columnIndexOfLastErrorMessage = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastErrorMessage");
            List _result = new ArrayList();
            while (_stmt.step()) {
                int _tmpId = (int) _stmt.getLong(_tmp);
                String _tmpSess = _stmt.getText(_columnIndexOfSess);
                String _tmpToken = _stmt.getText(_columnIndexOfToken);
                String _tmpStatus = _stmt.getText(_columnIndexOfStatus);
                if (_stmt.isNull(_columnIndexOfCr)) {
                    _tmpCr = null;
                } else {
                    String _tmpCr2 = _stmt.getText(_columnIndexOfCr);
                    _tmpCr = _tmpCr2;
                }
                int _columnIndexOfId = _tmp;
                int _tmp2 = (int) _stmt.getLong(_columnIndexOfIsAutoPolling);
                boolean _tmpIsAutoPolling = _tmp2 != 0;
                long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
                long _tmpLastCheckedAt = _stmt.getLong(_columnIndexOfLastCheckedAt);
                if (_stmt.isNull(_columnIndexOfLastErrorMessage)) {
                    _tmpLastErrorMessage = null;
                } else {
                    String _tmpLastErrorMessage2 = _stmt.getText(_columnIndexOfLastErrorMessage);
                    _tmpLastErrorMessage = _tmpLastErrorMessage2;
                }
                Transaction _item = new Transaction(_tmpId, _tmpSess, _tmpToken, _tmpStatus, _tmpCr, _tmpIsAutoPolling, _tmpCreatedAt, _tmpLastCheckedAt, _tmpLastErrorMessage);
                _result.add(_item);
                _tmp = _columnIndexOfId;
            }
            return _result;
        } finally {
            _stmt.close();
        }
    }

    @Override // com.example.data.p٠١٨db.TransactionDao
    public Object getTransactionById(final int id, Continuation<? super Transaction> continuation) {
        final String _sql = "SELECT * FROM transactions WHERE id = ? LIMIT 1";
        return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.example.data.db.TransactionDao_Impl$$ExternalSyntheticLambda5
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TransactionDao_Impl.getTransactionById$lambda$4(_sql, id, (SQLiteConnection) obj);
            }
        }, continuation);
    }

    static final Transaction getTransactionById$lambda$4(String $_sql, int $id, SQLiteConnection _connection) {
        Transaction _result;
        String _tmpCr;
        String _tmpLastErrorMessage;
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            _stmt.mo٨٣٣٤bindLong(1, $id);
            int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
            int _columnIndexOfSess = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sess");
            int _columnIndexOfToken = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "token");
            int _columnIndexOfStatus = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, NotificationCompat.CATEGORY_STATUS);
            int _columnIndexOfCr = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cr");
            int _columnIndexOfIsAutoPolling = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "isAutoPolling");
            int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
            int _columnIndexOfLastCheckedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastCheckedAt");
            int _columnIndexOfLastErrorMessage = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastErrorMessage");
            if (_stmt.step()) {
                int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
                String _tmpSess = _stmt.getText(_columnIndexOfSess);
                String _tmpToken = _stmt.getText(_columnIndexOfToken);
                String _tmpStatus = _stmt.getText(_columnIndexOfStatus);
                if (_stmt.isNull(_columnIndexOfCr)) {
                    _tmpCr = null;
                } else {
                    String _tmpCr2 = _stmt.getText(_columnIndexOfCr);
                    _tmpCr = _tmpCr2;
                }
                int _tmp = (int) _stmt.getLong(_columnIndexOfIsAutoPolling);
                boolean _tmpIsAutoPolling = _tmp != 0;
                long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
                long _tmpLastCheckedAt = _stmt.getLong(_columnIndexOfLastCheckedAt);
                if (_stmt.isNull(_columnIndexOfLastErrorMessage)) {
                    _tmpLastErrorMessage = null;
                } else {
                    String _tmpLastErrorMessage2 = _stmt.getText(_columnIndexOfLastErrorMessage);
                    _tmpLastErrorMessage = _tmpLastErrorMessage2;
                }
                _result = new Transaction(_tmpId, _tmpSess, _tmpToken, _tmpStatus, _tmpCr, _tmpIsAutoPolling, _tmpCreatedAt, _tmpLastCheckedAt, _tmpLastErrorMessage);
            } else {
                _result = null;
            }
            return _result;
        } finally {
            _stmt.close();
        }
    }

    @Override // com.example.data.p٠١٨db.TransactionDao
    public Object getTransactionBySess(final String sess, Continuation<? super Transaction> continuation) {
        final String _sql = "SELECT * FROM transactions WHERE sess = ? LIMIT 1";
        return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.example.data.db.TransactionDao_Impl$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TransactionDao_Impl.getTransactionBySess$lambda$5(_sql, sess, (SQLiteConnection) obj);
            }
        }, continuation);
    }

    static final Transaction getTransactionBySess$lambda$5(String $_sql, String $sess, SQLiteConnection _connection) {
        Transaction _result;
        String _tmpCr;
        String _tmpLastErrorMessage;
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            _stmt.mo٨٣٣٦bindText(1, $sess);
            int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
            int _columnIndexOfSess = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sess");
            int _columnIndexOfToken = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "token");
            int _columnIndexOfStatus = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, NotificationCompat.CATEGORY_STATUS);
            int _columnIndexOfCr = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cr");
            int _columnIndexOfIsAutoPolling = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "isAutoPolling");
            int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
            int _columnIndexOfLastCheckedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastCheckedAt");
            int _columnIndexOfLastErrorMessage = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastErrorMessage");
            if (_stmt.step()) {
                int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
                String _tmpSess = _stmt.getText(_columnIndexOfSess);
                String _tmpToken = _stmt.getText(_columnIndexOfToken);
                String _tmpStatus = _stmt.getText(_columnIndexOfStatus);
                if (_stmt.isNull(_columnIndexOfCr)) {
                    _tmpCr = null;
                } else {
                    String _tmpCr2 = _stmt.getText(_columnIndexOfCr);
                    _tmpCr = _tmpCr2;
                }
                int _tmp = (int) _stmt.getLong(_columnIndexOfIsAutoPolling);
                boolean _tmpIsAutoPolling = _tmp != 0;
                long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
                long _tmpLastCheckedAt = _stmt.getLong(_columnIndexOfLastCheckedAt);
                if (_stmt.isNull(_columnIndexOfLastErrorMessage)) {
                    _tmpLastErrorMessage = null;
                } else {
                    String _tmpLastErrorMessage2 = _stmt.getText(_columnIndexOfLastErrorMessage);
                    _tmpLastErrorMessage = _tmpLastErrorMessage2;
                }
                _result = new Transaction(_tmpId, _tmpSess, _tmpToken, _tmpStatus, _tmpCr, _tmpIsAutoPolling, _tmpCreatedAt, _tmpLastCheckedAt, _tmpLastErrorMessage);
            } else {
                _result = null;
            }
            return _result;
        } finally {
            _stmt.close();
        }
    }

    @Override // com.example.data.p٠١٨db.TransactionDao
    public Object deleteTransactionById(final int id, Continuation<? super Unit> continuation) {
        final String _sql = "DELETE FROM transactions WHERE id = ?";
        Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.example.data.db.TransactionDao_Impl$$ExternalSyntheticLambda4
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return TransactionDao_Impl.deleteTransactionById$lambda$6(_sql, id, (SQLiteConnection) obj);
            }
        }, continuation);
        return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
    }

    static final Unit deleteTransactionById$lambda$6(String $_sql, int $id, SQLiteConnection _connection) {
        Intrinsics.checkNotNullParameter(_connection, "_connection");
        SQLiteStatement _stmt = _connection.prepare($_sql);
        try {
            _stmt.mo٨٣٣٤bindLong(1, $id);
            _stmt.step();
            return Unit.INSTANCE;
        } finally {
            _stmt.close();
        }
    }

    /* JADX INFO: compiled from: TransactionDao_Impl.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005¨\u0006\u0007"}, m٨٧٩٩d2 = {"Lcom/example/data/db/TransactionDao_Impl$Companion;", "", "<init>", "()V", "getRequiredConverters", "", "Lkotlin/reflect/KClass;", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final List<KClass<?>> getRequiredConverters() {
            return CollectionsKt.emptyList();
        }
    }
}
