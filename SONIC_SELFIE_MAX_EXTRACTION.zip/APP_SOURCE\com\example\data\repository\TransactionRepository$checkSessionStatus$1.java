package com.example.data.repository;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;

/* JADX INFO: compiled from: TransactionRepository.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
@DebugMetadata(m١٠٠٢٥c = "com.example.data.repository.TransactionRepository", m١٠٠٢٦f = "TransactionRepository.kt", m١٠٠٢٧i = {0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4}, m١٠٠٢٨l = {75, 105, 114, 125, 136}, m١٠٠٢٩m = "checkSessionStatus-0E7RQCE", m١٠٠٣٠n = {"transaction", "endpointUrl", "formattedToken", "request", "transaction", "endpointUrl", "formattedToken", "request", "response", "body", "updatedTransaction", "transaction", "endpointUrl", "formattedToken", "request", "response", "body", "errorMsg", "errorTx", "transaction", "endpointUrl", "formattedToken", "request", "response", "errorMsg", "errorTx", "transaction", "endpointUrl", "e", "errorMsg", "errorTx"}, m١٠٠٣١s = {"L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$0", "L$1", "L$2", "L$3", "L$4"})
final class TransactionRepository$checkSessionStatus$1 extends ContinuationImpl {
    Object L$0;
    Object L$1;
    Object L$2;
    Object L$3;
    Object L$4;
    Object L$5;
    Object L$6;
    Object L$7;
    int label;
    /* synthetic */ Object result;
    final /* synthetic */ TransactionRepository this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    TransactionRepository$checkSessionStatus$1(TransactionRepository transactionRepository, Continuation<? super TransactionRepository$checkSessionStatus$1> continuation) {
        super(continuation);
        this.this$0 = transactionRepository;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        Object obj2 = this.this$0.m٨٣٤٤checkSessionStatus0E7RQCE(null, null, this);
        return obj2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? obj2 : Result.m٨٨٠٨boximpl(obj2);
    }
}
