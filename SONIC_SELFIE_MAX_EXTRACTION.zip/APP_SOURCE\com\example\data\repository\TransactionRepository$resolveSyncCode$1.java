package com.example.data.repository;

import androidx.core.view.MotionEventCompat;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;

/* JADX INFO: compiled from: TransactionRepository.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
@DebugMetadata(m١٠٠٢٥c = "com.example.data.repository.TransactionRepository", m١٠٠٢٦f = "TransactionRepository.kt", m١٠٠٢٧i = {0, 0}, m١٠٠٢٨l = {MotionEventCompat.AXIS_GENERIC_7}, m١٠٠٢٩m = "resolveSyncCode-0E7RQCE", m١٠٠٣٠n = {"code", "endpointUrl"}, m١٠٠٣١s = {"L$0", "L$1"})
final class TransactionRepository$resolveSyncCode$1 extends ContinuationImpl {
    Object L$0;
    Object L$1;
    int label;
    /* synthetic */ Object result;
    final /* synthetic */ TransactionRepository this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    TransactionRepository$resolveSyncCode$1(TransactionRepository transactionRepository, Continuation<? super TransactionRepository$resolveSyncCode$1> continuation) {
        super(continuation);
        this.this$0 = transactionRepository;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object obj) {
        this.result = obj;
        this.label |= Integer.MIN_VALUE;
        Object obj2 = this.this$0.m٨٣٤٥resolveSyncCode0E7RQCE(null, null, this);
        return obj2 == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? obj2 : Result.m٨٨٠٨boximpl(obj2);
    }
}
