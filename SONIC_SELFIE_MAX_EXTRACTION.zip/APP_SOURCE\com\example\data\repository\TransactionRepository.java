package com.example.data.repository;

import com.example.data.api.AchatApiService;
import com.example.data.api.CheckRequest;
import com.example.data.api.CheckResponse;
import com.example.data.api.SyncCodeRequest;
import com.example.data.api.SyncCodeResponse;
import com.example.data.model.Transaction;
import com.example.data.p٠١٨db.TransactionDao;
import com.example.util.DebugLog;
import java.io.IOException;
import java.util.List;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.flow.Flow;
import okhttp3.ResponseBody;
import retrofit2.Response;

/* JADX INFO: compiled from: TransactionRepository.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0018\u0010\u000e\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0086@¢\u0006\u0002\u0010\u0011J\u0018\u0010\u0012\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\u0013\u001a\u00020\u0014H\u0086@¢\u0006\u0002\u0010\u0015J\u0016\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u000bH\u0086@¢\u0006\u0002\u0010\u0019J\u0016\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u0018\u001a\u00020\u000bH\u0086@¢\u0006\u0002\u0010\u0019J\u0016\u0010\u001c\u001a\u00020\u001b2\u0006\u0010\u0018\u001a\u00020\u000bH\u0086@¢\u0006\u0002\u0010\u0019J\u0016\u0010\u001d\u001a\u00020\u001b2\u0006\u0010\u000f\u001a\u00020\u0010H\u0086@¢\u0006\u0002\u0010\u0011J&\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001f2\u0006\u0010!\u001a\u00020\u00142\u0006\u0010\"\u001a\u00020\u0014H\u0086@¢\u0006\u0004\b#\u0010$J&\u0010%\u001a\b\u0012\u0004\u0012\u00020&0\u001f2\u0006\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\"\u001a\u00020\u0014H\u0086@¢\u0006\u0004\b'\u0010(R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n0\t¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006)"}, m٨٧٩٩d2 = {"Lcom/example/data/repository/TransactionRepository;", "", "transactionDao", "Lcom/example/data/db/TransactionDao;", "apiService", "Lcom/example/data/api/AchatApiService;", "<init>", "(Lcom/example/data/db/TransactionDao;Lcom/example/data/api/AchatApiService;)V", "allTransactions", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/example/data/model/Transaction;", "getAllTransactions", "()Lkotlinx/coroutines/flow/Flow;", "getTransactionById", "id", "", "(ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "getTransactionBySess", "sess", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insert", "", "transaction", "(Lcom/example/data/model/Transaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "update", "", "delete", "deleteById", "resolveSyncCode", "Lkotlin/Result;", "Lcom/example/data/api/SyncCodeResponse;", "code", "endpointUrl", "resolveSyncCode-0E7RQCE", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "checkSessionStatus", "Lcom/example/data/api/CheckResponse;", "checkSessionStatus-0E7RQCE", "(Lcom/example/data/model/Transaction;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class TransactionRepository {
    public static final int $stable = 8;
    private final Flow<List<Transaction>> allTransactions;
    private final AchatApiService apiService;
    private final TransactionDao transactionDao;

    public TransactionRepository(TransactionDao transactionDao, AchatApiService apiService) {
        Intrinsics.checkNotNullParameter(transactionDao, "transactionDao");
        Intrinsics.checkNotNullParameter(apiService, "apiService");
        this.transactionDao = transactionDao;
        this.apiService = apiService;
        this.allTransactions = this.transactionDao.getAllTransactions();
    }

    public final Flow<List<Transaction>> getAllTransactions() {
        return this.allTransactions;
    }

    public final Object getTransactionById(int id, Continuation<? super Transaction> continuation) {
        return this.transactionDao.getTransactionById(id, continuation);
    }

    public final Object getTransactionBySess(String sess, Continuation<? super Transaction> continuation) {
        return this.transactionDao.getTransactionBySess(sess, continuation);
    }

    public final Object insert(Transaction transaction, Continuation<? super Long> continuation) {
        return this.transactionDao.insertTransaction(transaction, continuation);
    }

    public final Object update(Transaction transaction, Continuation<? super Unit> continuation) {
        Object objUpdateTransaction = this.transactionDao.updateTransaction(transaction, continuation);
        return objUpdateTransaction == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objUpdateTransaction : Unit.INSTANCE;
    }

    public final Object delete(Transaction transaction, Continuation<? super Unit> continuation) {
        Object objDeleteTransaction = this.transactionDao.deleteTransaction(transaction, continuation);
        return objDeleteTransaction == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objDeleteTransaction : Unit.INSTANCE;
    }

    public final Object deleteById(int id, Continuation<? super Unit> continuation) {
        Object objDeleteTransactionById = this.transactionDao.deleteTransactionById(id, continuation);
        return objDeleteTransactionById == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objDeleteTransactionById : Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0014  */
    /* JADX INFO: renamed from: resolveSyncCode-0E7RQCE, reason: not valid java name */
    public final Object m٨٣٤٥resolveSyncCode0E7RQCE(String code, String endpointUrl, Continuation<? super Result<SyncCodeResponse>> continuation) {
        TransactionRepository$resolveSyncCode$1 transactionRepository$resolveSyncCode$1;
        Object objResolveSyncCode;
        String errorMsg;
        if (continuation instanceof TransactionRepository$resolveSyncCode$1) {
            transactionRepository$resolveSyncCode$1 = (TransactionRepository$resolveSyncCode$1) continuation;
            if ((transactionRepository$resolveSyncCode$1.label & Integer.MIN_VALUE) != 0) {
                transactionRepository$resolveSyncCode$1.label -= Integer.MIN_VALUE;
            } else {
                transactionRepository$resolveSyncCode$1 = new TransactionRepository$resolveSyncCode$1(this, continuation);
            }
        } else {
            transactionRepository$resolveSyncCode$1 = new TransactionRepository$resolveSyncCode$1(this, continuation);
        }
        Object $result = transactionRepository$resolveSyncCode$1.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        boolean z = true;
        try {
            switch (transactionRepository$resolveSyncCode$1.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    DebugLog.INSTANCE.add("SYNC", "resolving code=" + code + " endpoint=" + endpointUrl);
                    AchatApiService achatApiService = this.apiService;
                    SyncCodeRequest syncCodeRequest = new SyncCodeRequest(code);
                    transactionRepository$resolveSyncCode$1.L$0 = SpillingKt.nullOutSpilledVariable(code);
                    transactionRepository$resolveSyncCode$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl);
                    transactionRepository$resolveSyncCode$1.label = 1;
                    objResolveSyncCode = achatApiService.resolveSyncCode(endpointUrl, syncCodeRequest, transactionRepository$resolveSyncCode$1);
                    if (objResolveSyncCode == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    objResolveSyncCode = $result;
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            Response response = (Response) objResolveSyncCode;
            SyncCodeResponse body = (SyncCodeResponse) response.body();
            if (response.isSuccessful() && body != null && StringsKt.equals(body.getStatus(), "success", true)) {
                String session_id = body.getSession_id();
                if (!(session_id == null || session_id.length() == 0)) {
                    String client_token = body.getClient_token();
                    if (client_token != null && client_token.length() != 0) {
                        z = false;
                    }
                    if (!z) {
                        DebugLog.INSTANCE.add("SYNC", "resolved session_id=" + body.getSession_id());
                        Result.Companion companion = Result.INSTANCE;
                        return Result.m٨٨٠٩constructorimpl(body);
                    }
                }
            }
            if (body == null || (errorMsg = body.getMessage()) == null) {
                errorMsg = "Invalid or expired code";
            }
            DebugLog.INSTANCE.add("SYNC", "failed: " + errorMsg);
            Result.Companion companion2 = Result.INSTANCE;
            return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(new Exception(errorMsg)));
        } catch (Exception e) {
            String errorMsg2 = e.getLocalizedMessage();
            if (errorMsg2 == null && (errorMsg2 = e.getMessage()) == null) {
                errorMsg2 = "Network call failed";
            }
            DebugLog.INSTANCE.add("SYNC", "exception " + e.getClass().getSimpleName() + ": " + errorMsg2);
            Result.Companion companion3 = Result.INSTANCE;
            return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(e));
        }
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0310 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:101:0x0311  */
    /* JADX WARN: Code duplicated, block: B:104:0x032c  */
    /* JADX WARN: Code duplicated, block: B:115:0x03da A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:116:0x03db  */
    /* JADX WARN: Code duplicated, block: B:134:0x0489 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:135:0x048a  */
    /* JADX WARN: Code duplicated, block: B:48:0x018b A[Catch: Exception -> 0x03fa, TRY_ENTER, TRY_LEAVE, TryCatch #3 {Exception -> 0x03fa, blocks: (B:45:0x0181, B:48:0x018b, B:64:0x01b7), top: B:144:0x0181 }] */
    /* JADX WARN: Code duplicated, block: B:50:0x0195 A[Catch: Exception -> 0x02ba, TRY_ENTER, TryCatch #4 {Exception -> 0x02ba, blocks: (B:117:0x03e2, B:102:0x0319, B:93:0x02b2, B:50:0x0195, B:53:0x019f, B:59:0x01ac), top: B:146:0x002c }] */
    /* JADX WARN: Code duplicated, block: B:51:0x019c  */
    /* JADX WARN: Code duplicated, block: B:57:0x01a9  */
    /* JADX WARN: Code duplicated, block: B:68:0x01e5 A[Catch: Exception -> 0x03f5, TryCatch #6 {Exception -> 0x03f5, blocks: (B:66:0x01be, B:68:0x01e5, B:70:0x01f2, B:72:0x01fa, B:78:0x0207, B:89:0x027b, B:79:0x0226, B:81:0x0235, B:84:0x0244, B:85:0x0258, B:88:0x0268, B:98:0x02bf, B:105:0x0330, B:107:0x0361, B:109:0x0367, B:113:0x0371), top: B:147:0x0189 }] */
    /* JADX WARN: Code duplicated, block: B:70:0x01f2 A[Catch: Exception -> 0x03f5, TryCatch #6 {Exception -> 0x03f5, blocks: (B:66:0x01be, B:68:0x01e5, B:70:0x01f2, B:72:0x01fa, B:78:0x0207, B:89:0x027b, B:79:0x0226, B:81:0x0235, B:84:0x0244, B:85:0x0258, B:88:0x0268, B:98:0x02bf, B:105:0x0330, B:107:0x0361, B:109:0x0367, B:113:0x0371), top: B:147:0x0189 }] */
    /* JADX WARN: Code duplicated, block: B:76:0x0203  */
    /* JADX WARN: Code duplicated, block: B:78:0x0207 A[Catch: Exception -> 0x03f5, TryCatch #6 {Exception -> 0x03f5, blocks: (B:66:0x01be, B:68:0x01e5, B:70:0x01f2, B:72:0x01fa, B:78:0x0207, B:89:0x027b, B:79:0x0226, B:81:0x0235, B:84:0x0244, B:85:0x0258, B:88:0x0268, B:98:0x02bf, B:105:0x0330, B:107:0x0361, B:109:0x0367, B:113:0x0371), top: B:147:0x0189 }] */
    /* JADX WARN: Code duplicated, block: B:79:0x0226 A[Catch: Exception -> 0x03f5, TryCatch #6 {Exception -> 0x03f5, blocks: (B:66:0x01be, B:68:0x01e5, B:70:0x01f2, B:72:0x01fa, B:78:0x0207, B:89:0x027b, B:79:0x0226, B:81:0x0235, B:84:0x0244, B:85:0x0258, B:88:0x0268, B:98:0x02bf, B:105:0x0330, B:107:0x0361, B:109:0x0367, B:113:0x0371), top: B:147:0x0189 }] */
    /* JADX WARN: Code duplicated, block: B:7:0x001c  */
    /* JADX WARN: Code duplicated, block: B:81:0x0235 A[Catch: Exception -> 0x03f5, TryCatch #6 {Exception -> 0x03f5, blocks: (B:66:0x01be, B:68:0x01e5, B:70:0x01f2, B:72:0x01fa, B:78:0x0207, B:89:0x027b, B:79:0x0226, B:81:0x0235, B:84:0x0244, B:85:0x0258, B:88:0x0268, B:98:0x02bf, B:105:0x0330, B:107:0x0361, B:109:0x0367, B:113:0x0371), top: B:147:0x0189 }] */
    /* JADX WARN: Code duplicated, block: B:83:0x0242  */
    /* JADX WARN: Code duplicated, block: B:85:0x0258 A[Catch: Exception -> 0x03f5, TryCatch #6 {Exception -> 0x03f5, blocks: (B:66:0x01be, B:68:0x01e5, B:70:0x01f2, B:72:0x01fa, B:78:0x0207, B:89:0x027b, B:79:0x0226, B:81:0x0235, B:84:0x0244, B:85:0x0258, B:88:0x0268, B:98:0x02bf, B:105:0x0330, B:107:0x0361, B:109:0x0367, B:113:0x0371), top: B:147:0x0189 }] */
    /* JADX WARN: Code duplicated, block: B:87:0x0266  */
    /* JADX WARN: Code duplicated, block: B:91:0x02a9 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:92:0x02aa  */
    /* JADX WARN: Code duplicated, block: B:97:0x02be  */
    /* JADX WARN: Not initialized variable reg: 12, insn: 0x02bb: MOVE (r10 I:??[OBJECT, ARRAY]) = (r12 I:??[OBJECT, ARRAY] A[D('transaction' com.example.data.model.Transaction)]), block:B:96:0x02bb */
    /* JADX WARN: Not initialized variable reg: 13, insn: 0x00c8: MOVE (r10 I:??[OBJECT, ARRAY]) = (r13 I:??[OBJECT, ARRAY] A[D('transaction' com.example.data.model.Transaction)]), block:B:25:0x00c8 */
    /* JADX INFO: renamed from: checkSessionStatus-0E7RQCE, reason: not valid java name */
    public final Object m٨٣٤٤checkSessionStatus0E7RQCE(Transaction transaction, String endpointUrl, Continuation<? super Result<CheckResponse>> continuation) {
        TransactionRepository$checkSessionStatus$1 transactionRepository$checkSessionStatus$1;
        Transaction transaction2;
        Transaction transaction3;
        Transaction transaction4;
        Exception e;
        String localizedMessage;
        Transaction errorTx;
        TransactionDao transactionDao;
        Transaction transaction5;
        String formattedToken;
        Transaction transaction6;
        Object objCheckSession;
        String formattedToken2;
        CheckRequest request;
        Response response;
        String str;
        String errorMsg;
        ResponseBody responseBodyErrorBody;
        Transaction errorTx2;
        TransactionDao transactionDao2;
        String formattedToken3;
        String strString;
        String strTake;
        CheckResponse body;
        String status;
        String str2;
        CheckRequest request2;
        String endpointUrl2;
        Transaction errorTx3;
        TransactionDao transactionDao3;
        String formattedToken4;
        CheckResponse body2;
        String message;
        Transaction updatedTransaction;
        String message2;
        TransactionDao transactionDao4;
        CheckResponse body3;
        String cr;
        boolean z;
        String message3;
        String cr2;
        String endpointUrl3 = endpointUrl;
        if (continuation instanceof TransactionRepository$checkSessionStatus$1) {
            transactionRepository$checkSessionStatus$1 = (TransactionRepository$checkSessionStatus$1) continuation;
            if ((transactionRepository$checkSessionStatus$1.label & Integer.MIN_VALUE) != 0) {
                transactionRepository$checkSessionStatus$1.label -= Integer.MIN_VALUE;
            } else {
                transactionRepository$checkSessionStatus$1 = new TransactionRepository$checkSessionStatus$1(this, continuation);
            }
        } else {
            transactionRepository$checkSessionStatus$1 = new TransactionRepository$checkSessionStatus$1(this, continuation);
        }
        Object $result = transactionRepository$checkSessionStatus$1.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        try {
            try {
                switch (transactionRepository$checkSessionStatus$1.label) {
                    case 0:
                        ResultKt.throwOnFailure($result);
                        try {
                            if (StringsKt.startsWith(transaction.getToken(), "Bearer ", true)) {
                                try {
                                    formattedToken = transaction.getToken();
                                } catch (Exception e2) {
                                    e = e2;
                                    transaction3 = transaction;
                                }
                            } else {
                                formattedToken = "Bearer " + transaction.getToken();
                            }
                            CheckRequest request3 = new CheckRequest(transaction.getSess());
                            DebugLog.INSTANCE.add("CHECK", "poll endpoint=" + endpointUrl3 + " sess=" + transaction.getSess() + " token=" + DebugLog.INSTANCE.maskToken(transaction.getToken()));
                            AchatApiService achatApiService = this.apiService;
                            transaction6 = transaction;
                            try {
                                transactionRepository$checkSessionStatus$1.L$0 = transaction6;
                                transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl3);
                                transactionRepository$checkSessionStatus$1.L$2 = SpillingKt.nullOutSpilledVariable(formattedToken);
                                transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(request3);
                                transactionRepository$checkSessionStatus$1.label = 1;
                                objCheckSession = achatApiService.checkSession(endpointUrl3, formattedToken, request3, transactionRepository$checkSessionStatus$1);
                                if (objCheckSession == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                formattedToken2 = formattedToken;
                                request = request3;
                                try {
                                    response = (Response) objCheckSession;
                                    str = "-";
                                    try {
                                        if (response.isSuccessful()) {
                                            CheckRequest request4 = request;
                                            String endpointUrl4 = endpointUrl3;
                                            errorMsg = "HTTP error code: " + response.code() + " - " + response.message();
                                            DebugLog debugLog = DebugLog.INSTANCE;
                                            int iCode = response.code();
                                            responseBodyErrorBody = response.errorBody();
                                            if (responseBodyErrorBody != null && (strString = responseBodyErrorBody.string()) != null && (strTake = StringsKt.take(strString, 500)) != null) {
                                                str = strTake;
                                            }
                                            debugLog.add("CHECK", "HTTP error " + iCode + " errBody=" + str);
                                            errorTx2 = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, System.currentTimeMillis(), errorMsg, 119, null);
                                            transactionDao2 = this.transactionDao;
                                            transactionRepository$checkSessionStatus$1.L$0 = transaction6;
                                            transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl4);
                                            transactionRepository$checkSessionStatus$1.L$2 = SpillingKt.nullOutSpilledVariable(formattedToken2);
                                            transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(request4);
                                            transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(response);
                                            transactionRepository$checkSessionStatus$1.L$5 = errorMsg;
                                            transactionRepository$checkSessionStatus$1.L$6 = SpillingKt.nullOutSpilledVariable(errorTx2);
                                            transactionRepository$checkSessionStatus$1.label = 4;
                                            if (transactionDao2.updateTransaction(errorTx2, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            formattedToken3 = errorMsg;
                                            Result.Companion companion = Result.INSTANCE;
                                            return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(new IOException(formattedToken3)));
                                        }
                                        body = (CheckResponse) response.body();
                                        DebugLog debugLog2 = DebugLog.INSTANCE;
                                        if (body != null) {
                                            status = body.getStatus();
                                        } else {
                                            status = null;
                                        }
                                        if (body != null || (cr2 = body.getCr()) == null) {
                                            str2 = "-";
                                        } else {
                                            str2 = cr2;
                                        }
                                        if (body != null && (message3 = body.getMessage()) != null) {
                                            str = message3;
                                        }
                                        request2 = request;
                                        endpointUrl2 = endpointUrl3;
                                        debugLog2.add("CHECK", "result status=" + status + " cr=" + str2 + " message=" + str);
                                        if (body != null) {
                                            errorTx3 = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, System.currentTimeMillis(), "Empty response body from server", 119, null);
                                            transactionDao3 = this.transactionDao;
                                            transactionRepository$checkSessionStatus$1.L$0 = transaction6;
                                            transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl2);
                                            transactionRepository$checkSessionStatus$1.L$2 = SpillingKt.nullOutSpilledVariable(formattedToken2);
                                            transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(request2);
                                            transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(response);
                                            transactionRepository$checkSessionStatus$1.L$5 = SpillingKt.nullOutSpilledVariable(body);
                                            transactionRepository$checkSessionStatus$1.L$6 = "Empty response body from server";
                                            transactionRepository$checkSessionStatus$1.L$7 = SpillingKt.nullOutSpilledVariable(errorTx3);
                                            transactionRepository$checkSessionStatus$1.label = 3;
                                            if (transactionDao3.updateTransaction(errorTx3, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                                                return coroutine_suspended;
                                            }
                                            formattedToken4 = "Empty response body from server";
                                            Result.Companion companion2 = Result.INSTANCE;
                                            return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(new Exception(formattedToken4)));
                                        }
                                        if (StringsKt.equals(body.getStatus(), "success", true)) {
                                            cr = body.getCr();
                                            if (cr != null || cr.length() == 0) {
                                                z = true;
                                            } else {
                                                z = false;
                                            }
                                            if (z) {
                                                body2 = body;
                                                if (StringsKt.equals(body2.getStatus(), "error", true)) {
                                                    long jCurrentTimeMillis = System.currentTimeMillis();
                                                    message2 = body2.getMessage();
                                                    if (message2 == null) {
                                                        message2 = "Server reported error status";
                                                    }
                                                    updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, jCurrentTimeMillis, message2, 119, null);
                                                } else {
                                                    long jCurrentTimeMillis2 = System.currentTimeMillis();
                                                    message = body2.getMessage();
                                                    if (message == null) {
                                                        message = "Session is still pending";
                                                    }
                                                    updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Pending", null, false, 0L, jCurrentTimeMillis2, message, 119, null);
                                                }
                                            } else {
                                                body2 = body;
                                                updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Success", body.getCr(), false, 0L, System.currentTimeMillis(), null, 103, null);
                                            }
                                        } else {
                                            body2 = body;
                                            if (StringsKt.equals(body2.getStatus(), "error", true)) {
                                                long jCurrentTimeMillis3 = System.currentTimeMillis();
                                                message2 = body2.getMessage();
                                                if (message2 == null) {
                                                    message2 = "Server reported error status";
                                                }
                                                updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, jCurrentTimeMillis3, message2, 119, null);
                                            } else {
                                                long jCurrentTimeMillis4 = System.currentTimeMillis();
                                                message = body2.getMessage();
                                                if (message == null) {
                                                    message = "Session is still pending";
                                                }
                                                updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Pending", null, false, 0L, jCurrentTimeMillis4, message, 119, null);
                                            }
                                        }
                                        transactionDao4 = this.transactionDao;
                                        transactionRepository$checkSessionStatus$1.L$0 = transaction6;
                                        transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl2);
                                        transactionRepository$checkSessionStatus$1.L$2 = SpillingKt.nullOutSpilledVariable(formattedToken2);
                                        transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(request2);
                                        transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(response);
                                        transactionRepository$checkSessionStatus$1.L$5 = body2;
                                        transactionRepository$checkSessionStatus$1.L$6 = SpillingKt.nullOutSpilledVariable(updatedTransaction);
                                        transactionRepository$checkSessionStatus$1.label = 2;
                                        if (transactionDao4.updateTransaction(updatedTransaction, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        body3 = body2;
                                        Result.Companion companion3 = Result.INSTANCE;
                                        return Result.m٨٨٠٩constructorimpl(body3);
                                    } catch (Exception e3) {
                                        e = e3;
                                        endpointUrl3 = endpointUrl;
                                        transaction3 = transaction6;
                                    }
                                } catch (Exception e4) {
                                    e = e4;
                                    transaction3 = transaction6;
                                }
                                e = e;
                                localizedMessage = e.getLocalizedMessage();
                                if (localizedMessage == null && (localizedMessage = e.getMessage()) == null) {
                                    localizedMessage = "Network call failed";
                                }
                                String errorMsg2 = localizedMessage;
                                DebugLog.INSTANCE.add("CHECK", "exception " + e.getClass().getSimpleName() + ": " + errorMsg2);
                                errorTx = Transaction.copy$default(transaction3, 0, null, null, "Error", null, false, 0L, System.currentTimeMillis(), errorMsg2, 119, null);
                                transactionDao = this.transactionDao;
                                transactionRepository$checkSessionStatus$1.L$0 = SpillingKt.nullOutSpilledVariable(transaction3);
                                transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl3);
                                transactionRepository$checkSessionStatus$1.L$2 = e;
                                transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(errorMsg2);
                                transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(errorTx);
                                transactionRepository$checkSessionStatus$1.L$5 = null;
                                transactionRepository$checkSessionStatus$1.L$6 = null;
                                transactionRepository$checkSessionStatus$1.L$7 = null;
                                transactionRepository$checkSessionStatus$1.label = 5;
                                if (transactionDao.updateTransaction(errorTx, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                transaction5 = transaction3;
                                Result.Companion companion4 = Result.INSTANCE;
                                return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(e));
                            } catch (Exception e5) {
                                e = e5;
                                transaction3 = transaction6;
                            }
                        } catch (Exception e6) {
                            e = e6;
                            transaction3 = transaction;
                        }
                        break;
                    case 1:
                        request = (CheckRequest) transactionRepository$checkSessionStatus$1.L$3;
                        formattedToken2 = (String) transactionRepository$checkSessionStatus$1.L$2;
                        endpointUrl3 = (String) transactionRepository$checkSessionStatus$1.L$1;
                        Transaction transaction7 = (Transaction) transactionRepository$checkSessionStatus$1.L$0;
                        try {
                            ResultKt.throwOnFailure($result);
                            transaction6 = transaction7;
                            objCheckSession = $result;
                            response = (Response) objCheckSession;
                            str = "-";
                            if (response.isSuccessful()) {
                                CheckRequest request5 = request;
                                String endpointUrl5 = endpointUrl3;
                                errorMsg = "HTTP error code: " + response.code() + " - " + response.message();
                                DebugLog debugLog3 = DebugLog.INSTANCE;
                                int iCode2 = response.code();
                                responseBodyErrorBody = response.errorBody();
                                if (responseBodyErrorBody != null) {
                                    str = strTake;
                                }
                                debugLog3.add("CHECK", "HTTP error " + iCode2 + " errBody=" + str);
                                errorTx2 = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, System.currentTimeMillis(), errorMsg, 119, null);
                                transactionDao2 = this.transactionDao;
                                transactionRepository$checkSessionStatus$1.L$0 = transaction6;
                                transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl5);
                                transactionRepository$checkSessionStatus$1.L$2 = SpillingKt.nullOutSpilledVariable(formattedToken2);
                                transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(request5);
                                transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(response);
                                transactionRepository$checkSessionStatus$1.L$5 = errorMsg;
                                transactionRepository$checkSessionStatus$1.L$6 = SpillingKt.nullOutSpilledVariable(errorTx2);
                                transactionRepository$checkSessionStatus$1.label = 4;
                                if (transactionDao2.updateTransaction(errorTx2, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                formattedToken3 = errorMsg;
                                Result.Companion companion5 = Result.INSTANCE;
                                return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(new IOException(formattedToken3)));
                            }
                            body = (CheckResponse) response.body();
                            DebugLog debugLog4 = DebugLog.INSTANCE;
                            if (body != null) {
                                status = body.getStatus();
                            } else {
                                status = null;
                            }
                            if (body != null) {
                                str2 = "-";
                            } else {
                                str2 = "-";
                            }
                            if (body != null) {
                                str = message3;
                            }
                            request2 = request;
                            endpointUrl2 = endpointUrl3;
                            debugLog4.add("CHECK", "result status=" + status + " cr=" + str2 + " message=" + str);
                            if (body != null) {
                                errorTx3 = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, System.currentTimeMillis(), "Empty response body from server", 119, null);
                                transactionDao3 = this.transactionDao;
                                transactionRepository$checkSessionStatus$1.L$0 = transaction6;
                                transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl2);
                                transactionRepository$checkSessionStatus$1.L$2 = SpillingKt.nullOutSpilledVariable(formattedToken2);
                                transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(request2);
                                transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(response);
                                transactionRepository$checkSessionStatus$1.L$5 = SpillingKt.nullOutSpilledVariable(body);
                                transactionRepository$checkSessionStatus$1.L$6 = "Empty response body from server";
                                transactionRepository$checkSessionStatus$1.L$7 = SpillingKt.nullOutSpilledVariable(errorTx3);
                                transactionRepository$checkSessionStatus$1.label = 3;
                                if (transactionDao3.updateTransaction(errorTx3, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                formattedToken4 = "Empty response body from server";
                                Result.Companion companion6 = Result.INSTANCE;
                                return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(new Exception(formattedToken4)));
                            }
                            if (StringsKt.equals(body.getStatus(), "success", true)) {
                                body2 = body;
                                if (StringsKt.equals(body2.getStatus(), "error", true)) {
                                    long jCurrentTimeMillis5 = System.currentTimeMillis();
                                    message2 = body2.getMessage();
                                    if (message2 == null) {
                                        message2 = "Server reported error status";
                                    }
                                    updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, jCurrentTimeMillis5, message2, 119, null);
                                } else {
                                    long jCurrentTimeMillis6 = System.currentTimeMillis();
                                    message = body2.getMessage();
                                    if (message == null) {
                                        message = "Session is still pending";
                                    }
                                    updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Pending", null, false, 0L, jCurrentTimeMillis6, message, 119, null);
                                }
                            } else {
                                cr = body.getCr();
                                if (cr != null) {
                                    z = true;
                                } else {
                                    z = true;
                                }
                                if (z) {
                                    body2 = body;
                                    updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Success", body.getCr(), false, 0L, System.currentTimeMillis(), null, 103, null);
                                } else {
                                    body2 = body;
                                    if (StringsKt.equals(body2.getStatus(), "error", true)) {
                                        long jCurrentTimeMillis7 = System.currentTimeMillis();
                                        message2 = body2.getMessage();
                                        if (message2 == null) {
                                            message2 = "Server reported error status";
                                        }
                                        updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Error", null, false, 0L, jCurrentTimeMillis7, message2, 119, null);
                                    } else {
                                        long jCurrentTimeMillis8 = System.currentTimeMillis();
                                        message = body2.getMessage();
                                        if (message == null) {
                                            message = "Session is still pending";
                                        }
                                        updatedTransaction = Transaction.copy$default(transaction6, 0, null, null, "Pending", null, false, 0L, jCurrentTimeMillis8, message, 119, null);
                                    }
                                }
                            }
                            transactionDao4 = this.transactionDao;
                            transactionRepository$checkSessionStatus$1.L$0 = transaction6;
                            transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl2);
                            transactionRepository$checkSessionStatus$1.L$2 = SpillingKt.nullOutSpilledVariable(formattedToken2);
                            transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(request2);
                            transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(response);
                            transactionRepository$checkSessionStatus$1.L$5 = body2;
                            transactionRepository$checkSessionStatus$1.L$6 = SpillingKt.nullOutSpilledVariable(updatedTransaction);
                            transactionRepository$checkSessionStatus$1.label = 2;
                            if (transactionDao4.updateTransaction(updatedTransaction, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            body3 = body2;
                            Result.Companion companion7 = Result.INSTANCE;
                            return Result.m٨٨٠٩constructorimpl(body3);
                        } catch (Exception e7) {
                            e = e7;
                            transaction3 = transaction7;
                        }
                        e = e;
                        localizedMessage = e.getLocalizedMessage();
                        if (localizedMessage == null) {
                            localizedMessage = "Network call failed";
                        }
                        String errorMsg3 = localizedMessage;
                        DebugLog.INSTANCE.add("CHECK", "exception " + e.getClass().getSimpleName() + ": " + errorMsg3);
                        errorTx = Transaction.copy$default(transaction3, 0, null, null, "Error", null, false, 0L, System.currentTimeMillis(), errorMsg3, 119, null);
                        transactionDao = this.transactionDao;
                        transactionRepository$checkSessionStatus$1.L$0 = SpillingKt.nullOutSpilledVariable(transaction3);
                        transactionRepository$checkSessionStatus$1.L$1 = SpillingKt.nullOutSpilledVariable(endpointUrl3);
                        transactionRepository$checkSessionStatus$1.L$2 = e;
                        transactionRepository$checkSessionStatus$1.L$3 = SpillingKt.nullOutSpilledVariable(errorMsg3);
                        transactionRepository$checkSessionStatus$1.L$4 = SpillingKt.nullOutSpilledVariable(errorTx);
                        transactionRepository$checkSessionStatus$1.L$5 = null;
                        transactionRepository$checkSessionStatus$1.L$6 = null;
                        transactionRepository$checkSessionStatus$1.L$7 = null;
                        transactionRepository$checkSessionStatus$1.label = 5;
                        if (transactionDao.updateTransaction(errorTx, transactionRepository$checkSessionStatus$1) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        transaction5 = transaction3;
                        Result.Companion companion8 = Result.INSTANCE;
                        return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(e));
                    case 2:
                        body3 = (CheckResponse) transactionRepository$checkSessionStatus$1.L$5;
                        ResultKt.throwOnFailure($result);
                        Result.Companion companion9 = Result.INSTANCE;
                        return Result.m٨٨٠٩constructorimpl(body3);
                    case 3:
                        formattedToken4 = (String) transactionRepository$checkSessionStatus$1.L$6;
                        endpointUrl3 = (String) transactionRepository$checkSessionStatus$1.L$1;
                        Transaction transaction8 = (Transaction) transactionRepository$checkSessionStatus$1.L$0;
                        try {
                            ResultKt.throwOnFailure($result);
                            Result.Companion companion10 = Result.INSTANCE;
                            return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(new Exception(formattedToken4)));
                        } catch (Exception e8) {
                            e = e8;
                            transaction3 = transaction8;
                        }
                        break;
                    case 4:
                        formattedToken3 = (String) transactionRepository$checkSessionStatus$1.L$5;
                        ResultKt.throwOnFailure($result);
                        Result.Companion companion11 = Result.INSTANCE;
                        return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(new IOException(formattedToken3)));
                    case 5:
                        e = (Exception) transactionRepository$checkSessionStatus$1.L$2;
                        transaction5 = (Transaction) transactionRepository$checkSessionStatus$1.L$0;
                        ResultKt.throwOnFailure($result);
                        Result.Companion companion12 = Result.INSTANCE;
                        return Result.m٨٨٠٩constructorimpl(ResultKt.createFailure(e));
                    default:
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
            } catch (Exception e9) {
                e = e9;
                transaction3 = transaction4;
            }
        } catch (Exception e10) {
            e = e10;
            transaction3 = transaction2;
        }
    }
}
