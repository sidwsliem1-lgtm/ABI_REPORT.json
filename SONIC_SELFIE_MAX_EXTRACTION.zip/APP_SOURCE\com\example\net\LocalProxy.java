package com.example.net;

import android.content.Context;
import com.example.CR;
import com.example.p٠١٩ui.screens.Spoof;
import com.example.util.DebugLog;
import com.google.firebase.p٠٢٠ai.common.util.KtorKt;
import io.ktor.sse.ServerSentEventKt;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.SetsKt;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.p٠٢٢io.CloseableKt;
import kotlin.text.Charsets;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/* JADX INFO: compiled from: LocalProxy.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0004\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012J\u0010\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0006\u0010\u0017\u001a\u00020\u0007J\u0006\u0010\u0018\u001a\u00020\u0010J\u0010\u0010\u0019\u001a\u00020\u00102\u0006\u0010\u001a\u001a\u00020\u001bH\u0002J\u0018\u0010\u001c\u001a\u00020\u00102\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u0015\u001a\u00020\u0016H\u0002J\u0012\u0010\u001d\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u001e\u001a\u00020\u0016H\u0002J\u0018\u0010\u001f\u001a\u00020\u00102\u0006\u0010 \u001a\u00020\u001b2\u0006\u0010!\u001a\u00020\u001bH\u0002J\u0018\u0010\"\u001a\u00020\u00102\u0006\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020&H\u0002J\u0018\u0010'\u001a\u00020(2\u0006\u0010#\u001a\u00020$2\u0006\u0010)\u001a\u00020\u0007H\u0002J\u0010\u0010*\u001a\u00020(2\u0006\u0010#\u001a\u00020$H\u0002J\u0012\u0010+\u001a\u0004\u0018\u00010\u00162\u0006\u0010#\u001a\u00020$H\u0002R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006,"}, m٨٧٩٩d2 = {"Lcom/example/net/LocalProxy;", "", "<init>", "()V", "server", "Ljava/net/ServerSocket;", "value", "", "port", "getPort", "()I", "sslContext", "Ljavax/net/ssl/SSLContext;", "upstream", "Lokhttp3/OkHttpClient;", "init", "", "context", "Landroid/content/Context;", "needsMitm", "", "host", "", "start", "stop", "handle", "client", "Ljava/net/Socket;", "mitm", "directConnect", "target", "pump", "a", "b", "copy", "i", "Ljava/io/InputStream;", "o", "Ljava/io/OutputStream;", "readN", "", "n", "readChunked", "readLine", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class LocalProxy {
    private static volatile int port;
    private static volatile ServerSocket server;
    private static volatile SSLContext sslContext;
    public static final LocalProxy INSTANCE = new LocalProxy();
    private static final OkHttpClient upstream = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(60, TimeUnit.SECONDS).followRedirects(false).build();
    public static final int $stable = 8;

    private LocalProxy() {
    }

    public final int getPort() {
        return port;
    }

    public final void init(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        if (sslContext != null) {
            return;
        }
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            InputStream inputStreamOpenRawResource = context.getResources().openRawResource(CR.raw.mitm);
            try {
                char[] charArray = "teslamitm".toCharArray();
                Intrinsics.checkNotNullExpressionValue(charArray, "toCharArray(...)");
                ks.load(inputStreamOpenRawResource, charArray);
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(inputStreamOpenRawResource, null);
                KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
                char[] charArray2 = "teslamitm".toCharArray();
                Intrinsics.checkNotNullExpressionValue(charArray2, "toCharArray(...)");
                kmf.init(ks, charArray2);
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(kmf.getKeyManagers(), null, null);
                sslContext = ctx;
                DebugLog.INSTANCE.add("PROXY", "MITM keystore loaded");
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    CloseableKt.closeFinally(inputStreamOpenRawResource, th);
                    throw th2;
                }
            }
        } catch (Exception e) {
            DebugLog.INSTANCE.add("PROXY", "MITM keystore load FAILED: " + e.getMessage());
        }
    }

    private final boolean needsMitm(String host) {
        String h = StringsKt.substringBefore$default(host, ServerSentEventKt.COLON, (String) null, 2, (Object) null);
        return ((Spoof.INSTANCE.getOzHost().length() > 0) && Intrinsics.areEqual(h, Spoof.INSTANCE.getOzHost())) || StringsKt.contains((CharSequence) h, (CharSequence) "ozforensics", true);
    }

    public final int start() throws IOException {
        if (server != null) {
            return port;
        }
        final ServerSocket ss = new ServerSocket();
        ss.bind(new InetSocketAddress("127.0.0.1", 0));
        server = ss;
        port = ss.getLocalPort();
        DebugLog.INSTANCE.add("PROXY", "local proxy on 127.0.0.1:" + port + " (mitm=" + (sslContext != null) + ")");
        ThreadsKt.thread$default(false, true, null, "local-proxy", 0, new Function0() { // from class: com.example.net.LocalProxy$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return LocalProxy.start$lambda$3(ss);
            }
        }, 21, null);
        return port;
    }

    static final Unit start$lambda$3(ServerSocket $ss) {
        while (!$ss.isClosed()) {
            try {
                final Socket c = $ss.accept();
                ThreadsKt.thread$default(false, true, null, null, 0, new Function0() { // from class: com.example.net.LocalProxy$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return LocalProxy.start$lambda$3$lambda$2(c);
                    }
                }, 29, null);
            } catch (Exception e) {
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit start$lambda$3$lambda$2(Socket $c) {
        LocalProxy localProxy = INSTANCE;
        Intrinsics.checkNotNull($c);
        localProxy.handle($c);
        return Unit.INSTANCE;
    }

    public final void stop() {
        try {
            ServerSocket serverSocket = server;
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (Exception e) {
        }
        server = null;
    }

    private final void handle(Socket client) {
        String l;
        try {
            try {
                try {
                    InputStream cin = client.getInputStream();
                    OutputStream cout = client.getOutputStream();
                    Intrinsics.checkNotNull(cin);
                    String line = readLine(cin);
                    if (line == null) {
                        try {
                            client.close();
                            return;
                        } catch (Exception e) {
                            return;
                        }
                    }
                    do {
                        l = readLine(cin);
                        if (l == null) {
                            break;
                        }
                    } while (!(l.length() == 0));
                    List parts = StringsKt.split$default((CharSequence) line, new String[]{ServerSentEventKt.SPACE}, false, 0, 6, (Object) null);
                    if (parts.size() < 2) {
                        try {
                            client.close();
                            return;
                        } catch (Exception e2) {
                            return;
                        }
                    }
                    String method = (String) parts.get(0);
                    String target = (String) parts.get(1);
                    if (!StringsKt.equals(method, "CONNECT", true)) {
                        Socket srv = directConnect(target + ":80");
                        if (srv == null) {
                            try {
                                client.close();
                                return;
                            } catch (Exception e3) {
                                return;
                            }
                        }
                        OutputStream outputStream = srv.getOutputStream();
                        byte[] bytes = (line + KtorKt.SSE_SEPARATOR).getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                        outputStream.write(bytes);
                        srv.getOutputStream().flush();
                        pump(client, srv);
                    } else if (!needsMitm(target) || sslContext == null) {
                        Socket srv2 = directConnect(target);
                        if (srv2 == null) {
                            byte[] bytes2 = "HTTP/1.1 502 Bad Gateway\r\n\r\n".getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
                            cout.write(bytes2);
                            try {
                                client.close();
                                return;
                            } catch (Exception e4) {
                                return;
                            }
                        }
                        byte[] bytes3 = "HTTP/1.1 200 Connection Established\r\n\r\n".getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes3, "getBytes(...)");
                        cout.write(bytes3);
                        cout.flush();
                        pump(client, srv2);
                    } else {
                        byte[] bytes4 = "HTTP/1.1 200 Connection Established\r\n\r\n".getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(bytes4, "getBytes(...)");
                        cout.write(bytes4);
                        cout.flush();
                        mitm(client, StringsKt.substringBefore$default(target, ServerSentEventKt.COLON, (String) null, 2, (Object) null));
                    }
                    client.close();
                } catch (Throwable th) {
                    try {
                        client.close();
                        throw th;
                    } catch (Exception e5) {
                        throw th;
                    }
                }
            } catch (Exception e6) {
                DebugLog.INSTANCE.add("PROXY", "handle error: " + e6.getMessage());
                client.close();
            }
        } catch (Exception e7) {
        }
    }

    /* JADX WARN: Code duplicated, block: B:238:0x05fb A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:258:0x01af A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:259:0x01a8 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:49:0x0163 A[Catch: Exception -> 0x058f, all -> 0x0593, TRY_ENTER, TryCatch #1 {Exception -> 0x058f, blocks: (B:42:0x0148, B:86:0x021b, B:87:0x024c, B:103:0x02d6, B:109:0x02f4, B:115:0x0312, B:122:0x0340, B:131:0x03ce, B:133:0x03df, B:139:0x03ee, B:149:0x0416, B:150:0x0448, B:161:0x04b2, B:138:0x03ec, B:65:0x01bb, B:66:0x01c9, B:73:0x01f9, B:49:0x0163, B:50:0x0167), top: B:215:0x0148 }] */
    /* JADX WARN: Code duplicated, block: B:52:0x016d A[Catch: Exception -> 0x0161, all -> 0x0593, TRY_ENTER, TryCatch #9 {all -> 0x0593, blocks: (B:18:0x0091, B:19:0x00ac, B:42:0x0148, B:44:0x0156, B:63:0x01b4, B:86:0x021b, B:87:0x024c, B:90:0x025e, B:93:0x028d, B:97:0x02c7, B:100:0x02cc, B:103:0x02d6, B:108:0x02e9, B:109:0x02f4, B:114:0x0307, B:115:0x0312, B:117:0x032f, B:119:0x0335, B:122:0x0340, B:124:0x03ae, B:126:0x03b2, B:128:0x03ba, B:131:0x03ce, B:132:0x03d1, B:133:0x03df, B:135:0x03e5, B:139:0x03ee, B:149:0x0416, B:150:0x0448, B:152:0x044e, B:154:0x047e, B:157:0x0492, B:161:0x04b2, B:163:0x0528, B:138:0x03ec, B:165:0x0545, B:65:0x01bb, B:66:0x01c9, B:68:0x01cf, B:73:0x01f9, B:75:0x01fd, B:77:0x0205, B:79:0x020b, B:82:0x0213, B:49:0x0163, B:50:0x0167, B:52:0x016d, B:54:0x018d, B:22:0x00bb, B:27:0x00cc, B:31:0x00e9, B:34:0x011c), top: B:227:0x0091 }] */
    /* JADX WARN: Code duplicated, block: B:54:0x018d A[Catch: Exception -> 0x0161, all -> 0x0593, TryCatch #9 {all -> 0x0593, blocks: (B:18:0x0091, B:19:0x00ac, B:42:0x0148, B:44:0x0156, B:63:0x01b4, B:86:0x021b, B:87:0x024c, B:90:0x025e, B:93:0x028d, B:97:0x02c7, B:100:0x02cc, B:103:0x02d6, B:108:0x02e9, B:109:0x02f4, B:114:0x0307, B:115:0x0312, B:117:0x032f, B:119:0x0335, B:122:0x0340, B:124:0x03ae, B:126:0x03b2, B:128:0x03ba, B:131:0x03ce, B:132:0x03d1, B:133:0x03df, B:135:0x03e5, B:139:0x03ee, B:149:0x0416, B:150:0x0448, B:152:0x044e, B:154:0x047e, B:157:0x0492, B:161:0x04b2, B:163:0x0528, B:138:0x03ec, B:165:0x0545, B:65:0x01bb, B:66:0x01c9, B:68:0x01cf, B:73:0x01f9, B:75:0x01fd, B:77:0x0205, B:79:0x020b, B:82:0x0213, B:49:0x0163, B:50:0x0167, B:52:0x016d, B:54:0x018d, B:22:0x00bb, B:27:0x00cc, B:31:0x00e9, B:34:0x011c), top: B:227:0x0091 }] */
    /* JADX WARN: Code duplicated, block: B:56:0x01a3  */
    /* JADX WARN: Code duplicated, block: B:57:0x01a5  */
    /* JADX WARN: Code duplicated, block: B:60:0x01aa A[LOOP:2: B:50:0x0167->B:60:0x01aa, LOOP_END] */
    private final void mitm(Socket client, String host) throws Throwable {
        Throwable th;
        String str;
        SSLSocket tls;
        boolean z;
        String str2;
        Object next;
        byte[] n;
        String str3;
        Integer intOrNull;
        String str4;
        byte[] body;
        String str5;
        RequestBody requestBodyCreate$default;
        byte[] rbytes;
        List<String> groupValues;
        Iterator it;
        Map.Entry entry;
        int i;
        Iterator it2;
        boolean z2;
        Object value;
        this = this;
        String str6 = "toUpperCase(...)";
        String str7 = "substring(...)";
        String str8 = "<get-entries>(...)";
        String str9 = ServerSentEventKt.END_OF_LINE;
        String k = "MITM";
        SSLSocket tls2 = null;
        try {
            try {
                SSLContext sSLContext = sslContext;
                Intrinsics.checkNotNull(sSLContext);
                int i2 = 1;
                Socket socketCreateSocket = sSLContext.getSocketFactory().createSocket(client, host, client.getPort(), true);
                Intrinsics.checkNotNull(socketCreateSocket, "null cannot be cast to non-null type javax.net.ssl.SSLSocket");
                tls2 = (SSLSocket) socketCreateSocket;
                try {
                    tls2.setUseClientMode(false);
                    tls2.startHandshake();
                    InputStream din = tls2.getInputStream();
                    int i3 = 0;
                    BufferedOutputStream dout = new BufferedOutputStream(tls2.getOutputStream());
                    while (true) {
                        Intrinsics.checkNotNull(din);
                        String reqLine = this.readLine(din);
                        if (reqLine == null) {
                            tls = tls2;
                            break;
                        }
                        if ((reqLine.length() == 0 ? i2 : i3) == 0) {
                            String str10 = reqLine;
                            String[] strArr = new String[i2];
                            strArr[i3] = ServerSentEventKt.SPACE;
                            List rp = StringsKt.split$default((CharSequence) str10, strArr, false, 0, 6, (Object) null);
                            if (rp.size() < 2) {
                                tls = tls2;
                                break;
                            }
                            tls = tls2;
                            try {
                                try {
                                    String rmethod = (String) rp.get(i3);
                                    String rpath = (String) rp.get(1);
                                    LinkedHashMap hdrs = new LinkedHashMap();
                                    String hostHdr = host;
                                    while (true) {
                                        String hl = this.readLine(din);
                                        if (hl == null) {
                                            break;
                                        }
                                        if (hl.length() == 0) {
                                            break;
                                        }
                                        try {
                                            int idx = StringsKt.indexOf$default((CharSequence) hl, AbstractJsonLexerKt.COLON, 0, false, 6, (Object) null);
                                            if (idx > 0) {
                                                String str11 = k;
                                                BufferedOutputStream dout2 = dout;
                                                String strSubstring = hl.substring(0, idx);
                                                Intrinsics.checkNotNullExpressionValue(strSubstring, str7);
                                                String k2 = StringsKt.trim((CharSequence) strSubstring).toString();
                                                String strSubstring2 = hl.substring(idx + 1);
                                                Intrinsics.checkNotNullExpressionValue(strSubstring2, str7);
                                                String v = StringsKt.trim((CharSequence) strSubstring2).toString();
                                                String str12 = str7;
                                                if (StringsKt.equals(k2, "Host", true)) {
                                                    hostHdr = v;
                                                }
                                                hdrs.put(k2, v);
                                                k = str11;
                                                dout = dout2;
                                                str7 = str12;
                                            }
                                        } catch (Exception e) {
                                            e = e;
                                            k = k;
                                            tls2 = tls;
                                            str = k;
                                            DebugLog.INSTANCE.add(str, "session error: " + e.getMessage());
                                            if (tls2 != null) {
                                                try {
                                                    tls2.close();
                                                    Unit unit = Unit.INSTANCE;
                                                } catch (Exception e2) {
                                                    Unit unit2 = Unit.INSTANCE;
                                                }
                                            }
                                            try {
                                                client.close();
                                                return;
                                            } catch (Exception e3) {
                                                return;
                                            }
                                        }
                                    }
                                    try {
                                        Iterable iterableEntrySet = hdrs.entrySet();
                                        Intrinsics.checkNotNullExpressionValue(iterableEntrySet, str8);
                                        Iterable iterable = iterableEntrySet;
                                        int i4 = 0;
                                        if (!(iterable instanceof Collection)) {
                                            it = iterable.iterator();
                                            while (true) {
                                                if (it.hasNext()) {
                                                    z = false;
                                                    break;
                                                }
                                                entry = (Map.Entry) it.next();
                                                i = i4;
                                                it2 = it;
                                                if (StringsKt.equals((String) entry.getKey(), "Transfer-Encoding", true)) {
                                                    value = entry.getValue();
                                                    Intrinsics.checkNotNullExpressionValue(value, "<get-value>(...)");
                                                    if (StringsKt.contains((CharSequence) value, (CharSequence) "chunked", true)) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
                                                } else {
                                                    z2 = false;
                                                }
                                                if (z2) {
                                                    z = true;
                                                    break;
                                                } else {
                                                    it = it2;
                                                    i4 = i;
                                                }
                                            }
                                        } else {
                                            try {
                                                if (!((Collection) iterable).isEmpty()) {
                                                    it = iterable.iterator();
                                                    while (true) {
                                                        if (it.hasNext()) {
                                                            z = false;
                                                            break;
                                                        }
                                                        entry = (Map.Entry) it.next();
                                                        i = i4;
                                                        it2 = it;
                                                        if (StringsKt.equals((String) entry.getKey(), "Transfer-Encoding", true)) {
                                                            value = entry.getValue();
                                                            Intrinsics.checkNotNullExpressionValue(value, "<get-value>(...)");
                                                            if (StringsKt.contains((CharSequence) value, (CharSequence) "chunked", true)) {
                                                                z2 = true;
                                                            } else {
                                                                z2 = false;
                                                            }
                                                        } else {
                                                            z2 = false;
                                                        }
                                                        if (z2) {
                                                            z = true;
                                                            break;
                                                        } else {
                                                            it = it2;
                                                            i4 = i;
                                                        }
                                                    }
                                                } else {
                                                    z = false;
                                                }
                                            } catch (Exception e4) {
                                                e = e4;
                                                tls2 = tls;
                                                str = k;
                                                DebugLog.INSTANCE.add(str, "session error: " + e.getMessage());
                                                if (tls2 != null) {
                                                    tls2.close();
                                                    Unit unit3 = Unit.INSTANCE;
                                                }
                                                client.close();
                                                return;
                                            }
                                        }
                                        if (z) {
                                            n = this.readChunked(din);
                                            str2 = str8;
                                        } else {
                                            Iterable iterableEntrySet2 = hdrs.entrySet();
                                            Intrinsics.checkNotNullExpressionValue(iterableEntrySet2, str8);
                                            int i5 = 0;
                                            Iterator it3 = iterableEntrySet2.iterator();
                                            while (true) {
                                                if (!it3.hasNext()) {
                                                    str2 = str8;
                                                    next = null;
                                                    break;
                                                }
                                                next = it3.next();
                                                str2 = str8;
                                                int i6 = i5;
                                                if (StringsKt.equals((String) ((Map.Entry) next).getKey(), "Content-Length", true)) {
                                                    break;
                                                }
                                                str8 = str2;
                                                i5 = i6;
                                            }
                                            Map.Entry entry2 = (Map.Entry) next;
                                            int cl = (entry2 == null || (str3 = (String) entry2.getValue()) == null || (intOrNull = StringsKt.toIntOrNull(str3)) == null) ? 0 : intOrNull.intValue();
                                            n = cl > 0 ? this.readN(din, cl) : null;
                                        }
                                        byte[] body2 = n;
                                        String url = "https://" + hostHdr + rpath;
                                        Request.Builder b = new Request.Builder().url(url);
                                        Iterator it4 = hdrs.entrySet().iterator();
                                        String contentType = "application/octet-stream";
                                        while (true) {
                                            str4 = "toLowerCase(...)";
                                            body = body2;
                                            if (!it4.hasNext()) {
                                                break;
                                            }
                                            Map.Entry entry3 = (Map.Entry) it4.next();
                                            String k3 = (String) entry3.getKey();
                                            String v2 = (String) entry3.getValue();
                                            String kl = k3.toLowerCase(Locale.ROOT);
                                            Intrinsics.checkNotNullExpressionValue(kl, "toLowerCase(...)");
                                            if (Intrinsics.areEqual(kl, "content-type")) {
                                                contentType = v2;
                                            }
                                            if (!SetsKt.setOf((Object[]) new String[]{"host", "content-length", "connection", "proxy-connection", "transfer-encoding", "accept-encoding", "x-forwarded-for", "user-agent"}).contains(kl)) {
                                                try {
                                                    b.header(k3, v2);
                                                } catch (Exception e5) {
                                                    Unit unit4 = Unit.INSTANCE;
                                                }
                                            }
                                            body2 = body;
                                        }
                                        if (Spoof.INSTANCE.getIp().length() > 0) {
                                            b.header("X-Forwarded-For", Spoof.INSTANCE.getIp());
                                        }
                                        if (Spoof.INSTANCE.getFakeUa().length() > 0) {
                                            b.header("User-Agent", Spoof.INSTANCE.getFakeUa());
                                        }
                                        MatchResult matchResultFind$default = Regex.find$default(new Regex("Chrome/(\\d+)"), Spoof.INSTANCE.getFakeUa(), 0, 2, null);
                                        if (matchResultFind$default == null || (groupValues = matchResultFind$default.getGroupValues()) == null || (str5 = groupValues.get(1)) == null) {
                                            str5 = "148";
                                        }
                                        String cv = str5;
                                        b.header("sec-ch-ua", "\"Chromium\";v=\"" + cv + "\", \"Google Chrome\";v=\"" + cv + "\", \"Not.A/Brand\";v=\"99\"");
                                        b.header("sec-ch-ua-platform", "\"Windows\"");
                                        b.header("sec-ch-ua-mobile", "?0");
                                        Set of = SetsKt.setOf((Object[]) new String[]{"POST", "PUT", "PATCH", "DELETE"});
                                        String upperCase = rmethod.toUpperCase(Locale.ROOT);
                                        Intrinsics.checkNotNullExpressionValue(upperCase, str6);
                                        boolean hasBody = of.contains(upperCase);
                                        String upperCase2 = rmethod.toUpperCase(Locale.ROOT);
                                        Intrinsics.checkNotNullExpressionValue(upperCase2, str6);
                                        if (hasBody) {
                                            requestBodyCreate$default = RequestBody.Companion.create$default(RequestBody.INSTANCE, body == null ? new byte[0] : body, MediaType.INSTANCE.parse(contentType), 0, 0, 6, (Object) null);
                                        } else {
                                            requestBodyCreate$default = null;
                                        }
                                        b.method(upperCase2, requestBodyCreate$default);
                                        try {
                                            Response resp = upstream.newCall(b.build()).execute();
                                            ResponseBody responseBodyBody = resp.body();
                                            if (responseBodyBody == null || (rbytes = responseBodyBody.bytes()) == null) {
                                                rbytes = new byte[0];
                                            }
                                            int iCode = resp.code();
                                            String strMessage = resp.message();
                                            StringBuilder sb = new StringBuilder("HTTP/1.1 " + iCode + ServerSentEventKt.SPACE + ((Object) (strMessage.length() == 0 ? "OK" : strMessage)) + str9);
                                            Iterator<String> it5 = resp.headers().names().iterator();
                                            while (it5.hasNext()) {
                                                String n2 = it5.next();
                                                String nl = n2.toLowerCase(Locale.ROOT);
                                                Intrinsics.checkNotNullExpressionValue(nl, str4);
                                                str4 = str4;
                                                it5 = it5;
                                                if (SetsKt.setOf((Object[]) new String[]{"content-length", "transfer-encoding", "content-encoding", "connection"}).contains(nl)) {
                                                    b = b;
                                                } else {
                                                    StringBuilder sbAppend = sb.append(n2).append(": ");
                                                    Request.Builder b2 = b;
                                                    String strHeader$default = Response.header$default(resp, n2, null, 2, null);
                                                    if (strHeader$default == null) {
                                                        strHeader$default = "";
                                                    }
                                                    sbAppend.append(strHeader$default).append(str9);
                                                    b = b2;
                                                }
                                            }
                                            i3 = 0;
                                            sb.append("Content-Length: ").append(rbytes.length).append(str9);
                                            sb.append("Connection: keep-alive\r\n\r\n");
                                            String string = sb.toString();
                                            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                                            byte[] bytes = string.getBytes(Charsets.UTF_8);
                                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                            BufferedOutputStream dout3 = dout;
                                            dout3.write(bytes);
                                            dout3.write(rbytes);
                                            dout3.flush();
                                            String str13 = str9;
                                            str = k;
                                            try {
                                                DebugLog.INSTANCE.add(str, rmethod + ServerSentEventKt.SPACE + rpath + " -> " + resp.code() + " (" + rbytes.length + "b) xff=" + Spoof.INSTANCE.getIp());
                                                resp.close();
                                                dout = dout3;
                                                k = str;
                                                tls2 = tls;
                                                i2 = 1;
                                                str7 = str7;
                                                str9 = str13;
                                                str8 = str2;
                                                str6 = str6;
                                            } catch (Exception e6) {
                                                e = e6;
                                                tls2 = tls;
                                                DebugLog.INSTANCE.add(str, "session error: " + e.getMessage());
                                                if (tls2 != null) {
                                                    tls2.close();
                                                    Unit unit5 = Unit.INSTANCE;
                                                }
                                                client.close();
                                                return;
                                            }
                                        } catch (Exception e7) {
                                            str = k;
                                            BufferedOutputStream dout4 = dout;
                                            DebugLog.INSTANCE.add(str, "upstream err " + rmethod + ServerSentEventKt.SPACE + rpath + ": " + e7.getMessage());
                                            byte[] bytes2 = "HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes(Charsets.UTF_8);
                                            Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
                                            dout4.write(bytes2);
                                            dout4.flush();
                                            tls.close();
                                            Unit unit6 = Unit.INSTANCE;
                                            client.close();
                                        }
                                    } catch (Exception e8) {
                                        e = e8;
                                        str = k;
                                    }
                                } catch (Throwable th2) {
                                    th = th2;
                                    tls2 = tls;
                                    if (tls2 != null) {
                                        try {
                                            tls2.close();
                                            Unit unit7 = Unit.INSTANCE;
                                        } catch (Exception e9) {
                                            Unit unit8 = Unit.INSTANCE;
                                        }
                                    }
                                    try {
                                        client.close();
                                        throw th;
                                    } catch (Exception e10) {
                                        throw th;
                                    }
                                }
                            } catch (Exception e11) {
                                e = e11;
                                str = k;
                            }
                        } else {
                            str8 = str8;
                            str6 = str6;
                        }
                    }
                    try {
                        tls.close();
                        Unit unit9 = Unit.INSTANCE;
                    } catch (Exception e12) {
                        Unit unit10 = Unit.INSTANCE;
                    }
                    try {
                        client.close();
                    } catch (Exception e13) {
                    }
                } catch (Exception e14) {
                    e = e14;
                    str = k;
                } catch (Throwable th3) {
                    th = th3;
                }
            } catch (Exception e15) {
                e = e15;
                str = "MITM";
            }
        } catch (Throwable th4) {
            th = th4;
        }
    }

    private final Socket directConnect(String target) {
        try {
            String h = StringsKt.substringBefore$default(target, ServerSentEventKt.COLON, (String) null, 2, (Object) null);
            int p = Integer.parseInt(StringsKt.substringAfter(target, ServerSentEventKt.COLON, "443"));
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(h, p), 15000);
            return socket;
        } catch (Exception e) {
            return null;
        }
    }

    private final void pump(final Socket a, final Socket b) throws InterruptedException, IOException {
        Thread t = ThreadsKt.thread$default(false, true, null, null, 0, new Function0() { // from class: com.example.net.LocalProxy$$ExternalSyntheticLambda2
            @Override // kotlin.jvm.functions.Function0
            public final Object invoke() {
                return LocalProxy.pump$lambda$8(a, b);
            }
        }, 29, null);
        InputStream inputStream = b.getInputStream();
        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
        OutputStream outputStream = a.getOutputStream();
        Intrinsics.checkNotNullExpressionValue(outputStream, "getOutputStream(...)");
        copy(inputStream, outputStream);
        t.join(2000L);
        try {
            a.close();
        } catch (Exception e) {
        }
        try {
            b.close();
        } catch (Exception e2) {
        }
    }

    static final Unit pump$lambda$8(Socket $a, Socket $b) throws IOException {
        LocalProxy localProxy = INSTANCE;
        InputStream inputStream = $a.getInputStream();
        Intrinsics.checkNotNullExpressionValue(inputStream, "getInputStream(...)");
        OutputStream outputStream = $b.getOutputStream();
        Intrinsics.checkNotNullExpressionValue(outputStream, "getOutputStream(...)");
        localProxy.copy(inputStream, outputStream);
        return Unit.INSTANCE;
    }

    private final void copy(InputStream i, OutputStream o) {
        byte[] buf = new byte[16384];
        while (true) {
            try {
                int n = i.read(buf);
                if (n < 0) {
                    return;
                }
                o.write(buf, 0, n);
                o.flush();
            } catch (Exception e) {
                return;
            }
        }
    }

    private final byte[] readN(InputStream i, int n) throws IOException {
        byte[] out = new byte[n];
        int off = 0;
        while (off < n) {
            int r = i.read(out, off, n - off);
            if (r < 0) {
                break;
            }
            off += r;
        }
        if (off == n) {
            return out;
        }
        byte[] bArrCopyOf = Arrays.copyOf(out, off);
        Intrinsics.checkNotNullExpressionValue(bArrCopyOf, "copyOf(...)");
        return bArrCopyOf;
    }

    private final byte[] readChunked(InputStream i) throws IOException {
        Integer intOrNull;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        while (true) {
            String sizeLine = readLine(i);
            if (sizeLine == null || (intOrNull = StringsKt.toIntOrNull(StringsKt.substringBefore$default(StringsKt.trim((CharSequence) sizeLine).toString(), ';', (String) null, 2, (Object) null), 16)) == null) {
                break;
            }
            int size = intOrNull.intValue();
            if (size == 0) {
                readLine(i);
                break;
            }
            out.write(readN(i, size));
            readLine(i);
        }
        byte[] byteArray = out.toByteArray();
        Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
        return byteArray;
    }

    private final String readLine(InputStream i) throws IOException {
        StringBuilder sb = new StringBuilder();
        while (true) {
            int c = i.read();
            if (c < 0) {
                if (sb.length() == 0) {
                    return null;
                }
                return sb.toString();
            }
            if (c == 10) {
                String string = sb.toString();
                Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                return StringsKt.trimEnd(string, '\r');
            }
            sb.append((char) c);
        }
    }
}
