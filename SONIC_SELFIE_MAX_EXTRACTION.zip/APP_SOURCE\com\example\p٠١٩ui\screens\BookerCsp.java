package com.example.p٠١٩ui.screens;

import android.net.Uri;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import com.example.util.DebugLog;
import java.io.ByteArrayInputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.RegexOption;
import kotlin.text.StringsKt;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/* JADX INFO: compiled from: BookerBridge.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\"\u0010\f\u001a\u0014\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\r2\u0006\u0010\u000e\u001a\u00020\bH\u0002J\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0013"}, m٨٧٩٩d2 = {"Lcom/example/ui/screens/BookerCsp;", "", "<init>", "()V", "client", "Lokhttp3/OkHttpClient;", "STRIPPED", "", "", "BLS_HOSTS", "", "LOGO_PATH", "clientHintsFor", "Lkotlin/Triple;", "ua", "intercept", "Landroid/webkit/WebResourceResponse;", "request", "Landroid/webkit/WebResourceRequest;", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class BookerCsp {
    private static final String LOGO_PATH = "/assets/images/logo.png";
    public static final BookerCsp INSTANCE = new BookerCsp();
    private static final OkHttpClient client = new OkHttpClient.Builder().followRedirects(true).followSslRedirects(true).connectTimeout(20, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build();
    private static final Set<String> STRIPPED = SetsKt.setOf((Object[]) new String[]{"content-security-policy", "content-security-policy-report-only", "x-frame-options", "content-encoding", "content-length", "transfer-encoding", "connection"});
    private static final List<String> BLS_HOSTS = CollectionsKt.listOf((Object[]) new String[]{"blsappointment.com", "blsspainglobal.com", "blsspainmorocco.net", "blsportugal.com", "thespainvisa.com", "theitalyvisa.com"});
    public static final int $stable = 8;

    private BookerCsp() {
    }

    private final Triple<String, String, String> clientHintsFor(String ua) {
        String version;
        List<String> groupValues;
        MatchResult matchResultFind$default = Regex.find$default(new Regex("Chrome/(\\d+)"), ua, 0, 2, null);
        if (matchResultFind$default == null || (groupValues = matchResultFind$default.getGroupValues()) == null || (version = groupValues.get(1)) == null) {
            version = "0";
        }
        String platform = "Windows";
        if (!StringsKt.contains$default((CharSequence) ua, (CharSequence) "Windows", false, 2, (Object) null)) {
            if (StringsKt.contains$default((CharSequence) ua, (CharSequence) "Mac", false, 2, (Object) null)) {
                platform = "macOS";
            } else if (StringsKt.contains$default((CharSequence) ua, (CharSequence) "Linux", false, 2, (Object) null)) {
                platform = "Linux";
            } else if (StringsKt.contains$default((CharSequence) ua, (CharSequence) "Android", false, 2, (Object) null)) {
                platform = "Android";
            } else if (StringsKt.contains$default((CharSequence) ua, (CharSequence) "iPhone", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) ua, (CharSequence) "iPad", false, 2, (Object) null)) {
                platform = "iOS";
            }
        }
        String mobile = new Regex("Mobile|Android|iPhone|iPad").containsMatchIn(ua) ? "?1" : "?0";
        String secChUa = "\"Chromium\";v=\"" + version + "\", \"Google Chrome\";v=\"" + version + "\", \"Not.A/Brand\";v=\"99\"";
        return new Triple<>(secChUa, "\"" + platform + "\"", mobile);
    }

    /* JADX WARN: Code duplicated, block: B:174:0x0332  */
    /* JADX WARN: Code duplicated, block: B:175:0x0334  */
    /* JADX WARN: Code duplicated, block: B:177:0x0337  */
    /* JADX WARN: Code duplicated, block: B:183:0x0359  */
    /* JADX WARN: Code duplicated, block: B:185:0x035c  */
    /* JADX WARN: Code duplicated, block: B:187:0x035f  */
    /* JADX WARN: Code duplicated, block: B:189:0x0363 A[Catch: Exception -> 0x02a5, TRY_ENTER, TRY_LEAVE, TryCatch #7 {Exception -> 0x02a5, blocks: (B:137:0x0278, B:139:0x0289, B:143:0x0299, B:163:0x0300, B:165:0x0307, B:167:0x0310, B:189:0x0363), top: B:225:0x0278 }] */
    /* JADX WARN: Code duplicated, block: B:191:0x036a  */
    /* JADX WARN: Code duplicated, block: B:51:0x00b9  */
    /* JADX WARN: Code duplicated, block: B:97:0x01b7 A[Catch: Exception -> 0x0177, TRY_LEAVE, TryCatch #5 {Exception -> 0x0177, blocks: (B:79:0x0151, B:90:0x0198, B:95:0x01ab, B:97:0x01b7, B:100:0x01c9, B:106:0x01d5, B:112:0x01f7, B:114:0x0206, B:121:0x0225, B:126:0x0243), top: B:222:0x0151 }] */
    public final WebResourceResponse intercept(WebResourceRequest request) {
        Uri url;
        String host;
        String path;
        String url2;
        boolean z;
        byte[] bodyBytes;
        boolean z2;
        String charset;
        String strMessage;
        boolean z3;
        String str;
        String ip;
        List<String> groupValues;
        String string;
        boolean z4;
        if (request != null && StringsKt.equals("GET", request.getMethod(), true) && (url = request.getUrl()) != null && (host = url.getHost()) != null) {
            String host2 = host;
            Uri url3 = request.getUrl();
            String str2 = "";
            if (url3 == null || (path = url3.getPath()) == null) {
                path = "";
            }
            String path2 = path;
            Uri url4 = request.getUrl();
            if (url4 != null && (url2 = url4.toString()) != null) {
                if (!StringsKt.startsWith$default(url2, "http://", false, 2, (Object) null) && !StringsKt.startsWith$default(url2, "https://", false, 2, (Object) null)) {
                    return null;
                }
                if (request.isForMainFrame()) {
                    Iterable iterable = BLS_HOSTS;
                    if (!(iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
                        Iterator it = iterable.iterator();
                        while (true) {
                            if (!it.hasNext()) {
                                z4 = false;
                                break;
                            }
                            String str3 = (String) it.next();
                            if (Intrinsics.areEqual(host2, str3) || StringsKt.endsWith$default(host2, new StringBuilder().append(".").append(str3).toString(), false, 2, (Object) null)) {
                                z4 = true;
                                break;
                            }
                        }
                    } else {
                        z4 = false;
                    }
                    if (z4) {
                        z = true;
                    } else {
                        z = false;
                    }
                } else {
                    z = false;
                }
                boolean isBlsMainHtml = z;
                boolean isLogo = Intrinsics.areEqual(path2, LOGO_PATH);
                if (!isBlsMainHtml && !isLogo) {
                    return null;
                }
                try {
                    Request.Builder builder = new Request.Builder().url(url2).get();
                    Map<String, String> requestHeaders = request.getRequestHeaders();
                    if (requestHeaders != null) {
                        try {
                            for (Map.Entry<String, String> entry : requestHeaders.entrySet()) {
                                String key = entry.getKey();
                                String value = entry.getValue();
                                if (!StringsKt.equals(key, "Accept-Encoding", true)) {
                                    Intrinsics.checkNotNull(key);
                                    Intrinsics.checkNotNull(value);
                                    builder.header(key, value);
                                }
                            }
                        } catch (Exception e) {
                            e = e;
                            DebugLog.INSTANCE.add("CSP", "intercept error for " + url2 + ": " + e.getMessage());
                            return null;
                        }
                    }
                    if (Spoof.INSTANCE.getFakeUa().length() > 0) {
                        builder.header("User-Agent", Spoof.INSTANCE.getFakeUa());
                        try {
                            Triple<String, String, String> tripleClientHintsFor = clientHintsFor(Spoof.INSTANCE.getFakeUa());
                            String secChUa = tripleClientHintsFor.component1();
                            String secChUaPlatform = tripleClientHintsFor.component2();
                            String secChUaMobile = tripleClientHintsFor.component3();
                            builder.header("sec-ch-ua", secChUa);
                            builder.header("sec-ch-ua-platform", secChUaPlatform);
                            builder.header("sec-ch-ua-mobile", secChUaMobile);
                        } catch (Exception e2) {
                            e = e2;
                            DebugLog.INSTANCE.add("CSP", "intercept error for " + url2 + ": " + e.getMessage());
                            return null;
                        }
                    }
                    try {
                        String spoofIp = Spoof.INSTANCE.getIp();
                        if (spoofIp.length() > 0) {
                            if (isLogo) {
                                builder.header("X-Forwarded-For", spoofIp);
                            } else if ((Spoof.INSTANCE.getOzHost().length() > 0) && Intrinsics.areEqual(host2, Spoof.INSTANCE.getOzHost())) {
                                builder.header("X-Forwarded-For", spoofIp);
                            }
                        }
                        String cookie = CookieManager.getInstance().getCookie(url2);
                        String str4 = cookie;
                        if (!(str4 == null || str4.length() == 0)) {
                            builder.header("Cookie", cookie);
                        }
                        Response response = client.newCall(builder.build()).execute();
                        String contentType = Response.header$default(response, "Content-Type", null, 2, null);
                        if (contentType == null) {
                            contentType = "";
                        }
                        if (!isLogo && !StringsKt.contains((CharSequence) contentType, (CharSequence) "text/html", true)) {
                            response.close();
                            return null;
                        }
                        CookieManager cm = CookieManager.getInstance();
                        Iterator it2 = response.headers("Set-Cookie").iterator();
                        while (it2.hasNext()) {
                            String spoofIp2 = spoofIp;
                            cm.setCookie(url2, (String) it2.next());
                            spoofIp = spoofIp2;
                        }
                        ResponseBody responseBodyBody = response.body();
                        if (responseBodyBody == null || (bodyBytes = responseBodyBody.bytes()) == null) {
                            bodyBytes = new byte[0];
                        }
                        HashMap cleanHeaders = new HashMap();
                        for (String name : response.headers().names()) {
                            try {
                                CookieManager cm2 = cm;
                                Set<String> set = STRIPPED;
                                String host3 = host2;
                                try {
                                    boolean isBlsMainHtml2 = isBlsMainHtml;
                                    try {
                                        String lowerCase = name.toLowerCase(Locale.ROOT);
                                        String str5 = str2;
                                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                        if (!set.contains(lowerCase)) {
                                            HashMap map = cleanHeaders;
                                            String strHeader$default = Response.header$default(response, name, null, 2, null);
                                            map.put(name, strHeader$default == null ? str5 : strHeader$default);
                                        }
                                        cm = cm2;
                                        str2 = str5;
                                        host2 = host3;
                                        isBlsMainHtml = isBlsMainHtml2;
                                    } catch (Exception e3) {
                                        e = e3;
                                        DebugLog.INSTANCE.add("CSP", "intercept error for " + url2 + ": " + e.getMessage());
                                        return null;
                                    }
                                } catch (Exception e4) {
                                    e = e4;
                                    DebugLog.INSTANCE.add("CSP", "intercept error for " + url2 + ": " + e.getMessage());
                                    return null;
                                }
                            } catch (Exception e5) {
                                e = e5;
                            }
                        }
                        try {
                            String string2 = StringsKt.trim((CharSequence) StringsKt.substringBefore$default(contentType, ";", (String) null, 2, (Object) null)).toString();
                            if (string2.length() == 0) {
                                string2 = isLogo ? "application/octet-stream" : "text/html";
                            }
                            String mime = string2;
                            MatchResult matchResultFind$default = Regex.find$default(new Regex("charset=([^;]+)", RegexOption.IGNORE_CASE), contentType, 0, 2, null);
                            try {
                                if (matchResultFind$default != null && (groupValues = matchResultFind$default.getGroupValues()) != null) {
                                    z2 = true;
                                    String str6 = groupValues.get(1);
                                    if (str6 != null && (string = StringsKt.trim((CharSequence) str6).toString()) != null) {
                                        charset = string;
                                    }
                                    strMessage = response.message();
                                    if (strMessage.length() == 0) {
                                        z3 = z2;
                                    } else {
                                        z3 = false;
                                    }
                                    if (z3) {
                                        strMessage = "OK";
                                    }
                                    String reason = strMessage;
                                    int code = response.code();
                                    response.close();
                                    DebugLog debugLog = DebugLog.INSTANCE;
                                    if (Spoof.INSTANCE.getFakeUa().length() <= 0) {
                                        z2 = false;
                                    }
                                    if (z2) {
                                        str = "spoof";
                                    } else {
                                        str = "default";
                                    }
                                    if (isLogo) {
                                        ip = Spoof.INSTANCE.getIp();
                                    } else {
                                        ip = "-";
                                    }
                                    debugLog.add("CSP", "re-served " + url2 + " (" + code + ") mime=" + mime + " ua=" + str + " xff=" + ip);
                                    return new WebResourceResponse(mime, charset, code, reason, cleanHeaders, new ByteArrayInputStream(bodyBytes));
                                }
                                z2 = true;
                                debugLog.add("CSP", "re-served " + url2 + " (" + code + ") mime=" + mime + " ua=" + str + " xff=" + ip);
                                return new WebResourceResponse(mime, charset, code, reason, cleanHeaders, new ByteArrayInputStream(bodyBytes));
                            } catch (Exception e6) {
                                e = e6;
                                DebugLog.INSTANCE.add("CSP", "intercept error for " + url2 + ": " + e.getMessage());
                                return null;
                            }
                            charset = "utf-8";
                            strMessage = response.message();
                            if (strMessage.length() == 0) {
                                z3 = z2;
                            } else {
                                z3 = false;
                            }
                            if (z3) {
                                strMessage = "OK";
                            }
                            String reason2 = strMessage;
                            int code2 = response.code();
                            response.close();
                            DebugLog debugLog2 = DebugLog.INSTANCE;
                            if (Spoof.INSTANCE.getFakeUa().length() <= 0) {
                                z2 = false;
                            }
                            if (z2) {
                                str = "spoof";
                            } else {
                                str = "default";
                            }
                            if (isLogo) {
                                ip = Spoof.INSTANCE.getIp();
                            } else {
                                ip = "-";
                            }
                        } catch (Exception e7) {
                            e = e7;
                        }
                    } catch (Exception e8) {
                        e = e8;
                        DebugLog.INSTANCE.add("CSP", "intercept error for " + url2 + ": " + e.getMessage());
                        return null;
                    }
                } catch (Exception e9) {
                    e = e9;
                }
            }
            return null;
        }
        return null;
    }
}
