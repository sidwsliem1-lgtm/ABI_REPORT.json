package com.example.p٠١٩ui.screens;

import android.content.Context;
import android.webkit.WebView;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.State;
import androidx.compose.runtime.snapshots.SnapshotStateList;
import com.example.p٠١٩ui.viewmodel.TransactionViewModel;
import com.example.util.DebugLog;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: BrowserScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
@DebugMetadata(m١٠٠٢٥c = "com.example.ui.screens.BrowserScreenKt$BrowserScreen$1$1", m١٠٠٢٦f = "BrowserScreen.kt", m١٠٠٢٧i = {}, m١٠٠٢٨l = {}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {}, m١٠٠٣١s = {})
final class BrowserScreenKt$BrowserScreen$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ SnapshotStateList<String> $consoleLogs;
    final /* synthetic */ Context $context;
    final /* synthetic */ MutableState<String> $currentUrl$delegate;
    final /* synthetic */ State<String> $pendingLaunchUrl$delegate;
    final /* synthetic */ MutableState<String> $urlInputText$delegate;
    final /* synthetic */ TransactionViewModel $viewModel;
    final /* synthetic */ MutableState<WebView> $webViewInstance$delegate;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    BrowserScreenKt$BrowserScreen$1$1(TransactionViewModel transactionViewModel, Context context, SnapshotStateList<String> snapshotStateList, State<String> state, MutableState<String> mutableState, MutableState<String> mutableState2, MutableState<WebView> mutableState3, Continuation<? super BrowserScreenKt$BrowserScreen$1$1> continuation) {
        super(2, continuation);
        this.$viewModel = transactionViewModel;
        this.$context = context;
        this.$consoleLogs = snapshotStateList;
        this.$pendingLaunchUrl$delegate = state;
        this.$currentUrl$delegate = mutableState;
        this.$urlInputText$delegate = mutableState2;
        this.$webViewInstance$delegate = mutableState3;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new BrowserScreenKt$BrowserScreen$1$1(this.$viewModel, this.$context, this.$consoleLogs, this.$pendingLaunchUrl$delegate, this.$currentUrl$delegate, this.$urlInputText$delegate, this.$webViewInstance$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((BrowserScreenKt$BrowserScreen$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) throws Throwable {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                String strBrowserScreen$lambda$25 = BrowserScreenKt.BrowserScreen$lambda$25(this.$pendingLaunchUrl$delegate);
                String requested = strBrowserScreen$lambda$25 != null ? StringsKt.trim((CharSequence) strBrowserScreen$lambda$25).toString() : null;
                if (requested == null) {
                    requested = "";
                }
                if (requested.length() > 0) {
                    String target = requested;
                    if (!StringsKt.startsWith$default(target, "http://", false, 2, (Object) null) && !StringsKt.startsWith$default(target, "https://", false, 2, (Object) null)) {
                        target = "https://" + target;
                    }
                    BrowserScreenKt.registerCodeToMonitor(target, this.$viewModel, this.$context);
                    this.$currentUrl$delegate.setValue(target);
                    this.$urlInputText$delegate.setValue(target);
                    this.$consoleLogs.add("🚀 START: launching booker flow → " + target);
                    DebugLog.INSTANCE.add("START", "loading " + target);
                    WebView webViewBrowserScreen$lambda$1 = BrowserScreenKt.BrowserScreen$lambda$1(this.$webViewInstance$delegate);
                    if (webViewBrowserScreen$lambda$1 != null) {
                        webViewBrowserScreen$lambda$1.loadUrl(target);
                    }
                    this.$viewModel.clearPendingLaunch();
                }
                return Unit.INSTANCE;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
