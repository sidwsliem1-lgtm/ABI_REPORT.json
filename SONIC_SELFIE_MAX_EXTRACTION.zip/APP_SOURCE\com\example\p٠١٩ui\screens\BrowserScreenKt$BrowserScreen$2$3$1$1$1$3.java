package com.example.p٠١٩ui.screens;

import android.content.Context;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.snapshots.SnapshotStateList;
import androidx.core.app.NotificationCompat;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;
import com.example.net.LocalProxy;
import com.example.p٠١٩ui.viewmodel.TransactionViewModel;
import com.example.util.DebugLog;
import com.google.android.gms.common.internal.ImagesContract;
import io.ktor.sse.ServerSentEventKt;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.collections.SetsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: BrowserScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\u0019\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0012*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0007J\u0018\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0005H\u0007J0\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u00052\u0006\u0010\f\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u0005H\u0007J\u0018\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u0005H\u0007J(\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u00052\u0006\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u0016\u001a\u00020\u0005H\u0007¨\u0006\u0017"}, m٨٧٩٩d2 = {"com/example/ui/screens/BrowserScreenKt$BrowserScreen$2$3$1$1$1$3", "", "logFromJS", "", "message", "", "onSessionParsed", "sess", "token", "saveSpoof", "ip", "ozPlugin", "ua", "blsHost", "proxyline", "onBookerResult", "link", "livenessId", "ozRelay", "method", ImagesContract.URL, "headersJson", "bodyB64", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class BrowserScreenKt$BrowserScreen$2$3$1$1$1$3 {
    final /* synthetic */ SnapshotStateList<String> $consoleLogs;
    final /* synthetic */ Context $context;
    final /* synthetic */ WebView $this_apply;
    final /* synthetic */ TransactionViewModel $viewModel;
    final /* synthetic */ MutableState<WebView> $webViewInstance$delegate;

    BrowserScreenKt$BrowserScreen$2$3$1$1$1$3(WebView $receiver, SnapshotStateList<String> snapshotStateList, TransactionViewModel $viewModel, Context $context, MutableState<WebView> mutableState) {
        this.$this_apply = $receiver;
        this.$consoleLogs = snapshotStateList;
        this.$viewModel = $viewModel;
        this.$context = $context;
        this.$webViewInstance$delegate = mutableState;
    }

    @JavascriptInterface
    public final void logFromJS(final String message) {
        Intrinsics.checkNotNullParameter(message, "message");
        WebView webView = this.$this_apply;
        final SnapshotStateList<String> snapshotStateList = this.$consoleLogs;
        webView.post(new Runnable() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$3$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                BrowserScreenKt$BrowserScreen$2$3$1$1$1$3.logFromJS$lambda$0(snapshotStateList, message);
            }
        });
    }

    static final void logFromJS$lambda$0(SnapshotStateList $consoleLogs, String $message) throws Throwable {
        $consoleLogs.add($message);
        if ($consoleLogs.size() > 80) {
            $consoleLogs.remove(0);
        }
    }

    @JavascriptInterface
    public final void onSessionParsed(final String sess, final String token) {
        Intrinsics.checkNotNullParameter(sess, "sess");
        Intrinsics.checkNotNullParameter(token, "token");
        WebView webView = this.$this_apply;
        final SnapshotStateList<String> snapshotStateList = this.$consoleLogs;
        final TransactionViewModel transactionViewModel = this.$viewModel;
        final Context context = this.$context;
        webView.post(new Runnable() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$3$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                BrowserScreenKt$BrowserScreen$2$3$1$1$1$3.onSessionParsed$lambda$1(snapshotStateList, sess, token, transactionViewModel, context);
            }
        });
    }

    static final void onSessionParsed$lambda$1(SnapshotStateList $consoleLogs, String $sess, String $token, TransactionViewModel $viewModel, Context $context) throws Throwable {
        $consoleLogs.add("📱 Bridge: Extracted Session: " + $sess + ", Token: " + $token);
        $viewModel.addTransaction($sess, $token, true);
        Toast.makeText($context, "Parsed Token Added to Background Monitor!", 1).show();
    }

    @JavascriptInterface
    public final void saveSpoof(final String ip, String ozPlugin, final String ua, String blsHost, String proxyline) {
        Intrinsics.checkNotNullParameter(ip, "ip");
        Intrinsics.checkNotNullParameter(ozPlugin, "ozPlugin");
        Intrinsics.checkNotNullParameter(ua, "ua");
        Intrinsics.checkNotNullParameter(blsHost, "blsHost");
        Intrinsics.checkNotNullParameter(proxyline, "proxyline");
        Spoof.INSTANCE.save(ip, ozPlugin, ua, blsHost, proxyline);
        if (!StringsKt.isBlank(ua)) {
            WebView webView = this.$this_apply;
            final SnapshotStateList<String> snapshotStateList = this.$consoleLogs;
            final MutableState<WebView> mutableState = this.$webViewInstance$delegate;
            webView.post(new Runnable() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$3$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    BrowserScreenKt$BrowserScreen$2$3$1$1$1$3.saveSpoof$lambda$2(ua, snapshotStateList, ip, mutableState);
                }
            });
        }
        WebView webView2 = this.$this_apply;
        final MutableState<WebView> mutableState2 = this.$webViewInstance$delegate;
        webView2.post(new Runnable() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$3$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                BrowserScreenKt$BrowserScreen$2$3$1$1$1$3.saveSpoof$lambda$6(mutableState2);
            }
        });
    }

    static final void saveSpoof$lambda$2(String $ua, SnapshotStateList $consoleLogs, String $ip, MutableState $webViewInstance$delegate) throws Throwable {
        WebSettings settings;
        try {
            WebView webViewBrowserScreen$lambda$1 = BrowserScreenKt.BrowserScreen$lambda$1($webViewInstance$delegate);
            if (webViewBrowserScreen$lambda$1 != null && (settings = webViewBrowserScreen$lambda$1.getSettings()) != null) {
                settings.setUserAgentString($ua);
            }
            $consoleLogs.add("🕵 Spoof set: UA→" + StringsKt.take($ua, 30) + "…  XFF→" + $ip);
        } catch (Exception e) {
            DebugLog.INSTANCE.add("SPOOF", "UA set failed: " + e.getMessage());
        }
    }

    static final void saveSpoof$lambda$6(MutableState $webViewInstance$delegate) {
        Context context;
        Context applicationContext;
        try {
            WebView webViewBrowserScreen$lambda$1 = BrowserScreenKt.BrowserScreen$lambda$1($webViewInstance$delegate);
            if (webViewBrowserScreen$lambda$1 != null && (context = webViewBrowserScreen$lambda$1.getContext()) != null && (applicationContext = context.getApplicationContext()) != null) {
                LocalProxy.INSTANCE.init(applicationContext);
            }
            final int p = LocalProxy.INSTANCE.start();
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                DebugLog.INSTANCE.add("PROXY", "PROXY_OVERRIDE unsupported on this WebView");
                return;
            }
            ProxyConfig cfg = new ProxyConfig.Builder().addProxyRule("127.0.0.1:" + p).addDirect().build();
            Intrinsics.checkNotNullExpressionValue(cfg, "build(...)");
            ProxyController.getInstance().setProxyOverride(cfg, new Executor() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$3$$ExternalSyntheticLambda0
                @Override // java.util.concurrent.Executor
                public final void execute(Runnable runnable) {
                    runnable.run();
                }
            }, new Runnable() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$3$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    DebugLog.INSTANCE.add("PROXY", "override active :" + p + " (MITM)");
                }
            });
        } catch (Exception e) {
            DebugLog.INSTANCE.add("PROXY", "proxy setup failed: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public final void onBookerResult(final String link, final String livenessId) {
        Intrinsics.checkNotNullParameter(link, "link");
        Intrinsics.checkNotNullParameter(livenessId, "livenessId");
        WebView webView = this.$this_apply;
        final SnapshotStateList<String> snapshotStateList = this.$consoleLogs;
        final TransactionViewModel transactionViewModel = this.$viewModel;
        webView.post(new Runnable() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$3$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                BrowserScreenKt$BrowserScreen$2$3$1$1$1$3.onBookerResult$lambda$7(link, livenessId, snapshotStateList, transactionViewModel);
            }
        });
    }

    static final void onBookerResult$lambda$7(String $link, String $livenessId, SnapshotStateList $consoleLogs, TransactionViewModel $viewModel) throws Throwable {
        DebugLog.INSTANCE.add("BOOKER", "panel link=" + StringsKt.take($link, ComposerKt.invocationKey) + " livenessId=" + $livenessId);
        if ($link.length() > 0) {
            $consoleLogs.add("🔗 Booker link: " + $link);
            TransactionViewModel.ParseResult pr = $viewModel.parseInputText($link);
            if (pr.getSuccess()) {
                if (pr.getSess().length() > 0) {
                    if (pr.getToken().length() > 0) {
                        $viewModel.addTransaction(pr.getSess(), pr.getToken(), true);
                    }
                }
            }
        }
        if ($livenessId.length() > 0) {
            $consoleLogs.add("✅ Liveness / Client ID: " + $livenessId);
        }
        if ($consoleLogs.size() > 80) {
            $consoleLogs.remove(0);
        }
    }

    @JavascriptInterface
    public final String ozRelay(String method, String url, String headersJson, String bodyB64) throws JSONException {
        String cm;
        RequestBody reqBody;
        byte[] respBytes;
        List<String> groupValues;
        String contentType;
        Intrinsics.checkNotNullParameter(method, "method");
        Intrinsics.checkNotNullParameter(url, "url");
        Intrinsics.checkNotNullParameter(headersJson, "headersJson");
        Intrinsics.checkNotNullParameter(bodyB64, "bodyB64");
        try {
            byte[] bodyBytes = bodyB64.length() > 0 ? Base64.decode(bodyB64, 2) : new byte[0];
            JSONObject hdrs = new JSONObject(headersJson);
            String contentType2 = "application/octet-stream";
            OkHttpClient client = new OkHttpClient.Builder().connectTimeout(30L, TimeUnit.SECONDS).readTimeout(60L, TimeUnit.SECONDS).writeTimeout(60L, TimeUnit.SECONDS).build();
            Request.Builder b = new Request.Builder().url(url);
            Iterator<String> itKeys = hdrs.keys();
            while (itKeys.hasNext()) {
                String k = itKeys.next();
                String v = hdrs.getString(k);
                if (StringsKt.equals(k, "content-type", true)) {
                    Intrinsics.checkNotNull(v);
                    contentType2 = v;
                }
                String contentType3 = contentType2;
                Intrinsics.checkNotNull(k);
                String kl = k.toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(kl, "toLowerCase(...)");
                if (SetsKt.setOf((Object[]) new String[]{"host", "content-length", "connection", "accept-encoding", "x-forwarded-for", "user-agent"}).contains(kl)) {
                    contentType = contentType3;
                } else {
                    try {
                        Intrinsics.checkNotNull(v);
                        contentType = contentType3;
                        try {
                            b.header(k, v);
                        } catch (Exception e) {
                        }
                    } catch (Exception e2) {
                        contentType = contentType3;
                    }
                }
                contentType2 = contentType;
            }
            if (Spoof.INSTANCE.getIp().length() > 0) {
                b.header("X-Forwarded-For", Spoof.INSTANCE.getIp());
            }
            if (Spoof.INSTANCE.getFakeUa().length() > 0) {
                b.header("User-Agent", Spoof.INSTANCE.getFakeUa());
            }
            MatchResult matchResultFind$default = Regex.find$default(new Regex("Chrome/(\\d+)"), Spoof.INSTANCE.getFakeUa(), 0, 2, null);
            if (matchResultFind$default == null || (groupValues = matchResultFind$default.getGroupValues()) == null || (cm = groupValues.get(1)) == null) {
                cm = "148";
            }
            b.header("sec-ch-ua", "\"Chromium\";v=\"" + cm + "\", \"Google Chrome\";v=\"" + cm + "\", \"Not.A/Brand\";v=\"99\"");
            b.header("sec-ch-ua-platform", "\"Windows\"");
            b.header("sec-ch-ua-mobile", "?0");
            Set of = SetsKt.setOf((Object[]) new String[]{"POST", "PUT", "PATCH", "DELETE"});
            String upperCase = method.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
            boolean hasBody = of.contains(upperCase);
            if (hasBody) {
                RequestBody.Companion companion = RequestBody.INSTANCE;
                Intrinsics.checkNotNull(bodyBytes);
                reqBody = RequestBody.Companion.create$default(companion, bodyBytes, MediaType.INSTANCE.parse(contentType2), 0, 0, 6, (Object) null);
            } else {
                reqBody = null;
            }
            String upperCase2 = method.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upperCase2, "toUpperCase(...)");
            b.method(upperCase2, reqBody);
            Response resp = client.newCall(b.build()).execute();
            ResponseBody responseBodyBody = resp.body();
            if (responseBodyBody == null || (respBytes = responseBodyBody.bytes()) == null) {
                respBytes = new byte[0];
            }
            JSONObject respHeaders = new JSONObject();
            for (String n : resp.headers().names()) {
                String cm2 = cm;
                boolean hasBody2 = hasBody;
                OkHttpClient client2 = client;
                String strHeader$default = Response.header$default(resp, n, null, 2, null);
                if (strHeader$default == null) {
                    strHeader$default = "";
                }
                respHeaders.put(n, strHeader$default);
                hasBody = hasBody2;
                cm = cm2;
                client = client2;
            }
            DebugLog.INSTANCE.add("OZRELAY", method + ServerSentEventKt.SPACE + StringsKt.take(url, 80) + " -> " + resp.code() + " (" + respBytes.length + "b) xff=" + Spoof.INSTANCE.getIp());
            JSONObject out = new JSONObject();
            out.put(NotificationCompat.CATEGORY_STATUS, resp.code());
            out.put("headers", respHeaders);
            out.put("bodyB64", Base64.encodeToString(respBytes, 2));
            resp.close();
            String string = out.toString();
            Intrinsics.checkNotNull(string);
            return string;
        } catch (Exception e3) {
            DebugLog.INSTANCE.add("OZRELAY", "error " + method + ServerSentEventKt.SPACE + StringsKt.take(url, 80) + ": " + e3.getMessage());
            JSONObject jSONObjectPut = new JSONObject().put(NotificationCompat.CATEGORY_STATUS, 0);
            String message = e3.getMessage();
            if (message == null) {
                message = NotificationCompat.CATEGORY_ERROR;
            }
            String string2 = jSONObjectPut.put("error", message).toString();
            Intrinsics.checkNotNull(string2);
            return string2;
        }
    }
}
