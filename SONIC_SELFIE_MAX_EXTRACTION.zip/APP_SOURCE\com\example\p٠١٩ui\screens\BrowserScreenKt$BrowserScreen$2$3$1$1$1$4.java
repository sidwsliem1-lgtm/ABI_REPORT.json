package com.example.p٠١٩ui.screens;

import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.snapshots.SnapshotStateList;
import com.example.util.DebugLog;
import io.ktor.sse.ServerSentEventKt;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: BrowserScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u00001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u001a\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0016J\u0012\u0010\f\u001a\u00020\u00032\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016¨\u0006\u000f"}, m٨٧٩٩d2 = {"com/example/ui/screens/BrowserScreenKt$BrowserScreen$2$3$1$1$1$4", "Landroid/webkit/WebChromeClient;", "onProgressChanged", "", "view", "Landroid/webkit/WebView;", "newProgress", "", "onConsoleMessage", "", "consoleMessage", "Landroid/webkit/ConsoleMessage;", "onPermissionRequest", "request", "Landroid/webkit/PermissionRequest;", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class BrowserScreenKt$BrowserScreen$2$3$1$1$1$4 extends WebChromeClient {
    final /* synthetic */ SnapshotStateList<String> $consoleLogs;
    final /* synthetic */ MutableState<Integer> $progress$delegate;
    final /* synthetic */ MutableState<WebView> $webViewInstance$delegate;

    BrowserScreenKt$BrowserScreen$2$3$1$1$1$4(MutableState<Integer> mutableState, SnapshotStateList<String> snapshotStateList, MutableState<WebView> mutableState2) {
        this.$progress$delegate = mutableState;
        this.$consoleLogs = snapshotStateList;
        this.$webViewInstance$delegate = mutableState2;
    }

    @Override // android.webkit.WebChromeClient
    public void onProgressChanged(WebView view, int newProgress) {
        BrowserScreenKt.BrowserScreen$lambda$14(this.$progress$delegate, newProgress);
    }

    @Override // android.webkit.WebChromeClient
    public boolean onConsoleMessage(ConsoleMessage consoleMessage) throws Throwable {
        Intrinsics.checkNotNullParameter(consoleMessage, "consoleMessage");
        String msg = consoleMessage.message();
        Intrinsics.checkNotNull(msg);
        if (!StringsKt.isBlank(msg)) {
            this.$consoleLogs.add("JS: " + msg);
            if (this.$consoleLogs.size() > 80) {
                this.$consoleLogs.remove(0);
            }
            DebugLog.INSTANCE.add("JS", consoleMessage.messageLevel() + ServerSentEventKt.SPACE + StringsKt.take(msg, 400) + " @" + consoleMessage.sourceId() + ServerSentEventKt.COLON + consoleMessage.lineNumber());
            return true;
        }
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public void onPermissionRequest(final PermissionRequest request) {
        WebView webViewBrowserScreen$lambda$1;
        if (request != null && (webViewBrowserScreen$lambda$1 = BrowserScreenKt.BrowserScreen$lambda$1(this.$webViewInstance$delegate)) != null) {
            final SnapshotStateList<String> snapshotStateList = this.$consoleLogs;
            webViewBrowserScreen$lambda$1.post(new Runnable() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$4$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    BrowserScreenKt$BrowserScreen$2$3$1$1$1$4.onPermissionRequest$lambda$0(request, snapshotStateList);
                }
            });
        }
    }

    static final void onPermissionRequest$lambda$0(PermissionRequest $request, SnapshotStateList $consoleLogs) throws Throwable {
        try {
            $request.grant($request.getResources());
            String[] resources = $request.getResources();
            Intrinsics.checkNotNullExpressionValue(resources, "getResources(...)");
            $consoleLogs.add("🎥 Granted camera/mic to page: " + ArraysKt.joinToString$default(resources, (CharSequence) null, (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 63, (Object) null));
            DebugLog debugLog = DebugLog.INSTANCE;
            String[] resources2 = $request.getResources();
            Intrinsics.checkNotNullExpressionValue(resources2, "getResources(...)");
            debugLog.add("PERM", "granted " + ArraysKt.joinToString$default(resources2, (CharSequence) null, (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 63, (Object) null) + " to " + $request.getOrigin());
            if ($consoleLogs.size() > 80) {
                $consoleLogs.remove(0);
            }
        } catch (Exception e) {
            $consoleLogs.add("❌ Permission grant failed: " + e.getMessage());
            DebugLog.INSTANCE.add("PERM", "grant failed: " + e.getMessage());
        }
    }
}
