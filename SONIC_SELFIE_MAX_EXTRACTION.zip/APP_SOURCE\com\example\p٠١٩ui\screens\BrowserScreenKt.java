package com.example.p٠١٩ui.screens;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.BorderStrokeKt;
import androidx.compose.foundation.ClickableKt;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.text.KeyboardActionScope;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.CloseKt;
import androidx.compose.material.icons.filled.RefreshKt;
import androidx.compose.material3.CardColors;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.DividerKt;
import androidx.compose.material3.IconButtonColors;
import androidx.compose.material3.IconButtonDefaults;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.OutlinedTextFieldDefaults;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.SurfaceKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.material3.TextKt;
import androidx.compose.p٠١٤ui.Alignment;
import androidx.compose.p٠١٤ui.ComposedModifierKt;
import androidx.compose.p٠١٤ui.Modifier;
import androidx.compose.p٠١٤ui.focus.FocusManager;
import androidx.compose.p٠١٤ui.graphics.Color;
import androidx.compose.p٠١٤ui.graphics.Shape;
import androidx.compose.p٠١٤ui.layout.MeasurePolicy;
import androidx.compose.p٠١٤ui.node.ComposeUiNode;
import androidx.compose.p٠١٤ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.p٠١٤ui.platform.CompositionLocalsKt;
import androidx.compose.p٠١٤ui.platform.TestTagKt;
import androidx.compose.p٠١٤ui.text.TextLayoutResult;
import androidx.compose.p٠١٤ui.text.TextStyle;
import androidx.compose.p٠١٤ui.text.font.FontFamily;
import androidx.compose.p٠١٤ui.text.font.FontStyle;
import androidx.compose.p٠١٤ui.text.font.FontWeight;
import androidx.compose.p٠١٤ui.text.input.ImeAction;
import androidx.compose.p٠١٤ui.text.input.PlatformImeOptions;
import androidx.compose.p٠١٤ui.text.input.VisualTransformation;
import androidx.compose.p٠١٤ui.text.intl.LocaleList;
import androidx.compose.p٠١٤ui.text.style.TextAlign;
import androidx.compose.p٠١٤ui.text.style.TextDecoration;
import androidx.compose.p٠١٤ui.unit.CDp;
import androidx.compose.p٠١٤ui.unit.TextUnitKt;
import androidx.compose.p٠١٤ui.viewinterop.AndroidView_androidKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.snapshots.SnapshotStateList;
import androidx.core.app.NotificationCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.compose.FlowExtKt;
import com.example.p٠١٩ui.theme.ColorKt;
import com.example.p٠١٩ui.viewmodel.TransactionViewModel;
import com.example.util.DebugLog;
import com.google.android.gms.common.internal.ImagesContract;
import java.net.URLDecoder;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: BrowserScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000F\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0003\u001a)\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u000eH\u0007¢\u0006\u0002\u0010\u000f\u001a(\u0010\u0010\u001a\u00020\b2\b\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u0006\u001a\u001e\u0010\u0016\u001a\u00020\b2\u0006\u0010\u0017\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u0018\u001a\u00020\u0019\"\u0017\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004\"\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u001a²\u0006\f\u0010\u001b\u001a\u0004\u0018\u00010\u0012X\u008a\u008e\u0002²\u0006\n\u0010\u001c\u001a\u00020\u0006X\u008a\u008e\u0002²\u0006\n\u0010\u001d\u001a\u00020\u0006X\u008a\u008e\u0002²\u0006\n\u0010\u001e\u001a\u00020\fX\u008a\u008e\u0002²\u0006\n\u0010\u001f\u001a\u00020 X\u008a\u008e\u0002²\u0006\n\u0010!\u001a\u00020\fX\u008a\u008e\u0002²\u0006\n\u0010\"\u001a\u00020\fX\u008a\u008e\u0002²\u0006\f\u0010#\u001a\u0004\u0018\u00010\u0006X\u008a\u0084\u0002"}, m٨٧٩٩d2 = {"BookmarksList", "", "Lcom/example/ui/screens/Bookmark;", "getBookmarksList", "()Ljava/util/List;", "DEFAULT_FAKE_UA", "", "BrowserScreen", "", "viewModel", "Lcom/example/ui/viewmodel/TransactionViewModel;", "showChrome", "", "modifier", "Landroidx/compose/ui/Modifier;", "(Lcom/example/ui/viewmodel/TransactionViewModel;ZLandroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "injectLivenessExtension", "webView", "Landroid/webkit/WebView;", "shimJs", "wafJs", "contentJs", "registerCodeToMonitor", ImagesContract.URL, "context", "Landroid/content/Context;", "app", "webViewInstance", "currentUrl", "urlInputText", "isLoading", NotificationCompat.CATEGORY_PROGRESS, "", "canGoBack", "canGoForward", "pendingLaunchUrl"}, m٨٨٠٠k = 2, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class BrowserScreenKt {
    private static final List<Bookmark> BookmarksList = CollectionsKt.listOf((Object[]) new Bookmark[]{new Bookmark("blsspainglobal", "algeria.blsspainglobal.com"), new Bookmark("blsspainmorocco", "https://www.blsspainmorocco.net/"), new Bookmark("BLS Portugal", "https://morocco.blsportugal.com/"), new Bookmark("Spain visa", "https://appointment.thespainvisa.com/"), new Bookmark("Italy visa", "https://appointment.theitalyvisa.com/"), new Bookmark("Mauritania", "https://mauritania.blsspainglobal.com/")});
    private static final String DEFAULT_FAKE_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36";

    static final Unit BrowserScreen$lambda$67(TransactionViewModel transactionViewModel, boolean z, Modifier modifier, int i, int i2, Composer composer, int i3) {
        BrowserScreen(transactionViewModel, z, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    public static final List<Bookmark> getBookmarksList() {
        return BookmarksList;
    }

    /* JADX WARN: Code duplicated, block: B:145:0x0794  */
    /* JADX WARN: Code duplicated, block: B:148:0x07f9  */
    /* JADX WARN: Code duplicated, block: B:149:0x0807  */
    /* JADX WARN: Code duplicated, block: B:152:0x0833  */
    /* JADX WARN: Code duplicated, block: B:153:0x08c4  */
    /* JADX WARN: Code duplicated, block: B:156:0x08ee  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r18v1 */
    /* JADX WARN: Type inference failed for: r18v2, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r18v5 */
    public static final void BrowserScreen(final TransactionViewModel viewModel, boolean showChrome, Modifier modifier, Composer $composer, final int $changed, final int i) {
        boolean z;
        Modifier modifier2;
        Object objMutableStateOf$default;
        Object objMutableStateOf$default2;
        Object objMutableStateOf$default3;
        ?? r18;
        Object objMutableStateOf$default4;
        Object objMutableStateOf$default5;
        Object objMutableStateOf$default6;
        Object objMutableStateOf$default7;
        Object objMutableStateListOf;
        Object asset;
        Object asset2;
        Object asset3;
        Context context;
        Composer $composer2;
        MutableState currentUrl$delegate;
        MutableState canGoForward$delegate;
        SnapshotStateList consoleLogs;
        MutableState webViewInstance$delegate;
        BrowserScreenKt$BrowserScreen$1$1 browserScreenKt$BrowserScreen$1$1;
        Function0<ComposeUiNode> function0;
        final MutableState canGoBack$delegate;
        Composer composer;
        final MutableState isLoading$delegate;
        MutableState canGoForward$delegate2;
        Context context2;
        Composer composer2;
        TransactionViewModel transactionViewModel;
        final MutableState currentUrl$delegate2;
        final MutableState currentUrl$delegate3;
        int i2;
        Composer composer3;
        Composer composer4;
        final MutableState urlInputText$delegate;
        Composer $composer3;
        boolean zChangedInstance;
        String str;
        final MutableState webViewInstance$delegate2;
        final SnapshotStateList consoleLogs2;
        Object obj;
        String shimJs;
        Object objRememberedValue;
        Object obj2;
        Composer composer5;
        final boolean showChrome2;
        final Modifier modifier3;
        Object obj3;
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Composer $composer4 = $composer.startRestartGroup(-1552625659);
        ComposerKt.sourceInformation($composer4, "C(BrowserScreen)P(2,1)70@2996L7,71@3045L7,73@3081L43,74@3147L66,75@3238L66,76@3326L34,77@3381L30,78@3433L34,79@3492L34,82@3628L41,87@3934L58,88@4009L62,89@4093L61,93@4386L29,94@4453L631,94@4420L664,111@5090L31506:BrowserScreen.kt#2thlc2");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer4.changedInstance(viewModel) ? 4 : 2;
        }
        int i3 = i & 2;
        if (i3 != 0) {
            $dirty |= 48;
            z = showChrome;
        } else if (($changed & 48) == 0) {
            z = showChrome;
            $dirty |= $composer4.changed(z) ? 32 : 16;
        } else {
            z = showChrome;
        }
        int i4 = i & 4;
        if (i4 != 0) {
            $dirty |= 384;
            modifier2 = modifier;
        } else if (($changed & 384) == 0) {
            modifier2 = modifier;
            $dirty |= $composer4.changed(modifier2) ? 256 : 128;
        } else {
            modifier2 = modifier;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 147) == 146 && $composer4.getSkipping()) {
            $composer4.skipToGroupEnd();
            showChrome2 = z;
            $composer3 = $composer4;
            modifier3 = modifier2;
        } else {
            boolean showChrome3 = i3 != 0 ? true : z;
            Modifier modifier4 = i4 != 0 ? Modifier.INSTANCE : modifier2;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1552625659, $dirty2, -1, "com.example.ui.screens.BrowserScreen (BrowserScreen.kt:69)");
            }
            ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer4.consume(localContext);
            ComposerKt.sourceInformationMarkerEnd($composer4);
            Context context3 = (Context) objConsume;
            ProvidableCompositionLocal<FocusManager> localFocusManager = CompositionLocalsKt.getLocalFocusManager();
            ComposerKt.sourceInformationMarkerStart($composer4, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer4.consume(localFocusManager);
            ComposerKt.sourceInformationMarkerEnd($composer4);
            final FocusManager focusManager = (FocusManager) objConsume2;
            ComposerKt.sourceInformationMarkerStart($composer4, -1719595920, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer4.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default);
            } else {
                objMutableStateOf$default = objRememberedValue2;
            }
            MutableState webViewInstance$delegate3 = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719593785, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue3 = $composer4.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("https://algeria.blsspainglobal.com/", null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default2);
            } else {
                objMutableStateOf$default2 = objRememberedValue3;
            }
            MutableState currentUrl$delegate4 = (MutableState) objMutableStateOf$default2;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719590873, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue4 = $composer4.rememberedValue();
            if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default3 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("https://algeria.blsspainglobal.com/", null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default3);
            } else {
                objMutableStateOf$default3 = objRememberedValue4;
            }
            MutableState urlInputText$delegate2 = (MutableState) objMutableStateOf$default3;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719588089, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue5 = $composer4.rememberedValue();
            if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                r18 = 0;
                objMutableStateOf$default4 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default4);
            } else {
                r18 = 0;
                objMutableStateOf$default4 = objRememberedValue5;
            }
            MutableState isLoading$delegate2 = (MutableState) objMutableStateOf$default4;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719586333, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue6 = $composer4.rememberedValue();
            if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default5 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Integer.valueOf((int) r18), null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default5);
            } else {
                objMutableStateOf$default5 = objRememberedValue6;
            }
            final MutableState progress$delegate = (MutableState) objMutableStateOf$default5;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719584665, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue7 = $composer4.rememberedValue();
            if (objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default6 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf((boolean) r18), null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default6);
            } else {
                objMutableStateOf$default6 = objRememberedValue7;
            }
            MutableState canGoBack$delegate2 = (MutableState) objMutableStateOf$default6;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719582777, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue8 = $composer4.rememberedValue();
            if (objRememberedValue8 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default7 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf((boolean) r18), null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default7);
            } else {
                objMutableStateOf$default7 = objRememberedValue8;
            }
            final MutableState canGoForward$delegate3 = (MutableState) objMutableStateOf$default7;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719578418, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue9 = $composer4.rememberedValue();
            if (objRememberedValue9 == Composer.INSTANCE.getEmpty()) {
                objMutableStateListOf = SnapshotStateKt.mutableStateListOf();
                $composer4.updateRememberedValue(objMutableStateListOf);
            } else {
                objMutableStateListOf = objRememberedValue9;
            }
            SnapshotStateList consoleLogs3 = (SnapshotStateList) objMutableStateListOf;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719568609, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue10 = $composer4.rememberedValue();
            if (objRememberedValue10 == Composer.INSTANCE.getEmpty()) {
                asset = BookerBridgeKt.readAsset(context3, "booker/liveness_shim.js");
                $composer4.updateRememberedValue(asset);
            } else {
                asset = objRememberedValue10;
            }
            final String shimJs2 = (String) asset;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719566205, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue11 = $composer4.rememberedValue();
            if (objRememberedValue11 == Composer.INSTANCE.getEmpty()) {
                asset2 = BookerBridgeKt.readAsset(context3, "booker/liveness_wafblock.js");
                $composer4.updateRememberedValue(asset2);
            } else {
                asset2 = objRememberedValue11;
            }
            final String wafJs = (String) asset2;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719563518, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue12 = $composer4.rememberedValue();
            if (objRememberedValue12 == Composer.INSTANCE.getEmpty()) {
                asset3 = BookerBridgeKt.readAsset(context3, "booker/liveness_content.js");
                $composer4.updateRememberedValue(asset3);
            } else {
                asset3 = objRememberedValue12;
            }
            final String livenessJs = (String) asset3;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            State pendingLaunchUrl$delegate = FlowExtKt.collectAsStateWithLifecycle(viewModel.getPendingLaunchUrl(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer4, 0, 7);
            String strBrowserScreen$lambda$25 = BrowserScreen$lambda$25(pendingLaunchUrl$delegate);
            ComposerKt.sourceInformationMarkerStart($composer4, -1719551428, "CC(remember):BrowserScreen.kt#9igjgp");
            boolean zChanged = $composer4.changed(pendingLaunchUrl$delegate) | $composer4.changedInstance(viewModel) | $composer4.changedInstance(context3);
            Object objRememberedValue13 = $composer4.rememberedValue();
            if (zChanged || objRememberedValue13 == Composer.INSTANCE.getEmpty()) {
                context = context3;
                $composer2 = $composer4;
                currentUrl$delegate = currentUrl$delegate4;
                canGoForward$delegate = urlInputText$delegate2;
                consoleLogs = consoleLogs3;
                webViewInstance$delegate = webViewInstance$delegate3;
                browserScreenKt$BrowserScreen$1$1 = new BrowserScreenKt$BrowserScreen$1$1(viewModel, context, consoleLogs3, pendingLaunchUrl$delegate, currentUrl$delegate, canGoForward$delegate, webViewInstance$delegate3, null);
                $composer4.updateRememberedValue(browserScreenKt$BrowserScreen$1$1);
            } else {
                webViewInstance$delegate = webViewInstance$delegate3;
                $composer2 = $composer4;
                currentUrl$delegate = currentUrl$delegate4;
                consoleLogs = consoleLogs3;
                context = context3;
                browserScreenKt$BrowserScreen$1$1 = objRememberedValue13;
                canGoForward$delegate = urlInputText$delegate2;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Composer $composer5 = $composer2;
            EffectsKt.LaunchedEffect(strBrowserScreen$lambda$25, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) browserScreenKt$BrowserScreen$1$1, $composer5, 0);
            Modifier modifier5 = BackgroundKt.m٦٦٧backgroundbw27NRU$default(SizeKt.fillMaxSize$default(modifier4, 0.0f, 1, null), ColorKt.getObsidianDark(), null, 2, null);
            ComposerKt.sourceInformationMarkerStart($composer5, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer5, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            Modifier modifier6 = modifier4;
            ComposerKt.sourceInformationMarkerStart($composer5, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer5, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer5.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer5, modifier5);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            MutableState webViewInstance$delegate4 = webViewInstance$delegate;
            int i5 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer5, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer5.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer5.startReusableNode();
            if ($composer5.getInserting()) {
                function0 = constructor;
                $composer5.createNode(function0);
            } else {
                function0 = constructor;
                $composer5.useNode();
            }
            Composer composer6 = Updater.m٤٤٨٨constructorimpl($composer5);
            final Context context4 = context;
            Updater.m٤٤٩٥setimpl(composer6, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer6, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer6.getInserting() || !Intrinsics.areEqual(composer6.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composer6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composer6.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m٤٤٩٥setimpl(composer6, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i6 = (i5 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer5, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            int i7 = ((0 >> 6) & 112) | 6;
            ColumnScope columnScope = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart($composer5, -750015113, "C279@12547L21339:BrowserScreen.kt#2thlc2");
            if (showChrome3) {
                $composer5.startReplaceGroup(-750758773);
                ComposerKt.sourceInformation($composer5, "119@5343L44,122@5492L6603,118@5303L6792");
                CardColors cardColors = CardDefaults.INSTANCE.m٢٥٨٣cardColorsro_MJ88(ColorKt.getObsidianSurface(), 0L, 0L, 0L, $composer5, (CardDefaults.$stable << 12) | 6, 14);
                canGoBack$delegate = canGoBack$delegate2;
                currentUrl$delegate2 = currentUrl$delegate;
                currentUrl$delegate3 = webViewInstance$delegate4;
                i2 = 1;
                isLoading$delegate = isLoading$delegate2;
                final MutableState urlInputText$delegate3 = canGoForward$delegate;
                composer = $composer5;
                composer2 = $composer5;
                transactionViewModel = viewModel;
                context2 = context4;
                canGoForward$delegate = urlInputText$delegate3;
                canGoForward$delegate2 = canGoForward$delegate3;
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(0)), cardColors, null, null, ComposableLambdaKt.rememberComposableLambda(304828744, true, new Function3() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda15
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46(focusManager, viewModel, context4, canGoBack$delegate, currentUrl$delegate3, canGoForward$delegate3, urlInputText$delegate3, currentUrl$delegate2, isLoading$delegate, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, composer2, 54), composer2, 196614, 24);
            } else {
                canGoBack$delegate = canGoBack$delegate2;
                composer = $composer5;
                isLoading$delegate = isLoading$delegate2;
                canGoForward$delegate2 = canGoForward$delegate3;
                context2 = context4;
                composer2 = $composer5;
                transactionViewModel = viewModel;
                currentUrl$delegate2 = currentUrl$delegate;
                currentUrl$delegate3 = webViewInstance$delegate4;
                i2 = 1;
                composer2.startReplaceGroup(-756221593);
            }
            composer2.endReplaceGroup();
            if (BrowserScreen$lambda$10(isLoading$delegate)) {
                composer2.startReplaceGroup(-744142009);
                ComposerKt.sourceInformation(composer2, "269@12234L19,268@12182L232");
                long goldPrimary = ColorKt.getGoldPrimary();
                long obsidianBorder = ColorKt.getObsidianBorder();
                Modifier modifier7 = SizeKt.m١٢٥٢height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, i2, null), CDp.m٧٩٥٨constructorimpl(2));
                ComposerKt.sourceInformationMarkerStart(composer2, -24002706, "CC(remember):BrowserScreen.kt#9igjgp");
                Composer composer7 = composer2;
                Object objRememberedValue14 = composer7.rememberedValue();
                if (objRememberedValue14 == Composer.INSTANCE.getEmpty()) {
                    obj3 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda16
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return Float.valueOf(BrowserScreenKt.BrowserScreen$lambda$66$lambda$48$lambda$47(progress$delegate));
                        }
                    };
                    composer7.updateRememberedValue(obj3);
                } else {
                    obj3 = objRememberedValue14;
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ProgressIndicatorKt.m٣١٦٣LinearProgressIndicatorGJbTh5U((Function0) obj3, modifier7, goldPrimary, obsidianBorder, 0, 0.0f, null, composer2, 3510, 112);
                composer2.endReplaceGroup();
            } else {
                composer2.startReplaceGroup(-743887778);
                ComposerKt.sourceInformation(composer2, "275@12444L49");
                DividerKt.m٢٨٤٣Divider9IZ8Weo(null, CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder(), composer2, 432, 1);
                composer2.endReplaceGroup();
            }
            Modifier modifierWeight$default = ColumnScope.weight$default(columnScope, SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), 1.0f, false, 2, null);
            Composer composer8 = composer2;
            ComposerKt.sourceInformationMarkerStart(composer8, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            Composer composer9 = composer2;
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            final MutableState canGoBack$delegate3 = canGoBack$delegate;
            ComposerKt.sourceInformationMarkerStart(composer8, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer8, 0);
            CompositionLocalMap currentCompositionLocalMap2 = composer8.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer8, modifierWeight$default);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i8 = ((((0 << 3) & 112) << 6) & 896) | 6;
            MutableState webViewInstance$delegate5 = currentUrl$delegate3;
            ComposerKt.sourceInformationMarkerStart(composer8, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer8.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer8.startReusableNode();
            if (composer8.getInserting()) {
                composer8.createNode(constructor2);
            } else {
                composer8.useNode();
            }
            Composer composer10 = Updater.m٤٤٨٨constructorimpl(composer8);
            Updater.m٤٤٩٥setimpl(composer10, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer10, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer10.getInserting()) {
                composer3 = composer8;
            } else {
                composer3 = composer8;
                if (!Intrinsics.areEqual(composer10.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                }
                Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i9 = (i8 >> 6) & 14;
                composer4 = composer3;
                ComposerKt.sourceInformationMarkerStart(composer4, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                int i10 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer4, 1205492042, "C285@12707L21007,604@33741L70,284@12668L21208:BrowserScreen.kt#2thlc2");
                urlInputText$delegate = canGoForward$delegate;
                Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                ComposerKt.sourceInformationMarkerStart(composer4, 1147266544, "CC(remember):BrowserScreen.kt#9igjgp");
                $composer3 = $composer5;
                zChangedInstance = $composer3.changedInstance(transactionViewModel) | $composer3.changedInstance(context2);
                Object objRememberedValue15 = composer4.rememberedValue();
                if (!zChangedInstance || objRememberedValue15 == Composer.INSTANCE.getEmpty()) {
                    str = "CC(remember):BrowserScreen.kt#9igjgp";
                    final TransactionViewModel transactionViewModel2 = transactionViewModel;
                    final Context context5 = context2;
                    final SnapshotStateList consoleLogs4 = consoleLogs;
                    webViewInstance$delegate2 = webViewInstance$delegate5;
                    final MutableState currentUrl$delegate5 = currentUrl$delegate2;
                    final MutableState canGoForward$delegate4 = canGoForward$delegate2;
                    Function1 function1 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$56$lambda$53$lambda$52(webViewInstance$delegate2, consoleLogs4, transactionViewModel2, context5, progress$delegate, shimJs2, wafJs, livenessJs, isLoading$delegate, currentUrl$delegate5, urlInputText$delegate, canGoBack$delegate3, canGoForward$delegate4, (Context) obj4);
                        }
                    };
                    consoleLogs2 = consoleLogs4;
                    obj = function1;
                    shimJs = shimJs2;
                    composer4.updateRememberedValue(obj);
                } else {
                    shimJs = shimJs2;
                    webViewInstance$delegate2 = webViewInstance$delegate5;
                    str = "CC(remember):BrowserScreen.kt#9igjgp";
                    consoleLogs2 = consoleLogs;
                    obj = objRememberedValue15;
                }
                Function1 function2 = (Function1) obj;
                ComposerKt.sourceInformationMarkerEnd(r4);
                ComposerKt.sourceInformationMarkerStart(composer4, 1147918695, str);
                objRememberedValue = composer4.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    obj2 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$56$lambda$55$lambda$54(webViewInstance$delegate2, (WebView) obj4);
                        }
                    };
                    composer4.updateRememberedValue(obj2);
                } else {
                    obj2 = objRememberedValue;
                }
                ComposerKt.sourceInformationMarkerEnd(composer4);
                AndroidView_androidKt.AndroidView(function2, modifierFillMaxSize$default, (Function1) obj2, composer4, 432, 0);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                if (showChrome3) {
                    composer5 = composer9;
                    composer5.startReplaceGroup(-722432492);
                    ComposerKt.sourceInformation(composer5, "614@34029L44,620@34312L2268,613@33989L2591");
                    CardKt.Card(SizeKt.m١٢٥٢height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), CDp.m٧٩٥٨constructorimpl(130)), RoundedCornerShapeKt.m١٥٧٣RoundedCornerShapea9UjIt4$default(CDp.m٧٩٥٨constructorimpl(12), CDp.m٧٩٥٨constructorimpl(12), 0.0f, 0.0f, 12, null), CardDefaults.INSTANCE.m٢٥٨٣cardColorsro_MJ88(ColorKt.getObsidianSurface(), 0L, 0L, 0L, composer9, (CardDefaults.$stable << 12) | 6, 14), null, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder()), ComposableLambdaKt.rememberComposableLambda(-500878464, true, new Function3() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj4, Object obj5, Object obj6) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$65(consoleLogs2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                        }
                    }, composer5, 54), composer5, 221190, 8);
                } else {
                    composer5 = composer9;
                    composer5.startReplaceGroup(-756221593);
                }
                composer5.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer);
                r7.endNode();
                ComposerKt.sourceInformationMarkerEnd(r7);
                ComposerKt.sourceInformationMarkerEnd(r7);
                ComposerKt.sourceInformationMarkerEnd($composer5);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                showChrome2 = showChrome3;
                modifier3 = modifier6;
            }
            composer10.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composer10.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
            Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i11 = (i8 >> 6) & 14;
            composer4 = composer3;
            ComposerKt.sourceInformationMarkerStart(composer4, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
            int i12 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer4, 1205492042, "C285@12707L21007,604@33741L70,284@12668L21208:BrowserScreen.kt#2thlc2");
            urlInputText$delegate = canGoForward$delegate;
            Modifier modifierFillMaxSize$default2 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart(composer4, 1147266544, "CC(remember):BrowserScreen.kt#9igjgp");
            $composer3 = $composer5;
            zChangedInstance = $composer3.changedInstance(transactionViewModel) | $composer3.changedInstance(context2);
            Object objRememberedValue16 = composer4.rememberedValue();
            if (zChangedInstance) {
                str = "CC(remember):BrowserScreen.kt#9igjgp";
                final TransactionViewModel transactionViewModel3 = transactionViewModel;
                final Context context6 = context2;
                final SnapshotStateList consoleLogs5 = consoleLogs;
                webViewInstance$delegate2 = webViewInstance$delegate5;
                final MutableState currentUrl$delegate6 = currentUrl$delegate2;
                final MutableState canGoForward$delegate5 = canGoForward$delegate2;
                Function1 function3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj4) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$56$lambda$53$lambda$52(webViewInstance$delegate2, consoleLogs5, transactionViewModel3, context6, progress$delegate, shimJs2, wafJs, livenessJs, isLoading$delegate, currentUrl$delegate6, urlInputText$delegate, canGoBack$delegate3, canGoForward$delegate5, (Context) obj4);
                    }
                };
                consoleLogs2 = consoleLogs5;
                obj = function3;
                shimJs = shimJs2;
                composer4.updateRememberedValue(obj);
            } else {
                str = "CC(remember):BrowserScreen.kt#9igjgp";
                final TransactionViewModel transactionViewModel4 = transactionViewModel;
                final Context context7 = context2;
                final SnapshotStateList consoleLogs6 = consoleLogs;
                webViewInstance$delegate2 = webViewInstance$delegate5;
                final MutableState currentUrl$delegate7 = currentUrl$delegate2;
                final MutableState canGoForward$delegate6 = canGoForward$delegate2;
                Function1 function4 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj4) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$56$lambda$53$lambda$52(webViewInstance$delegate2, consoleLogs6, transactionViewModel4, context7, progress$delegate, shimJs2, wafJs, livenessJs, isLoading$delegate, currentUrl$delegate7, urlInputText$delegate, canGoBack$delegate3, canGoForward$delegate6, (Context) obj4);
                    }
                };
                consoleLogs2 = consoleLogs6;
                obj = function4;
                shimJs = shimJs2;
                composer4.updateRememberedValue(obj);
            }
            Function1 function5 = (Function1) obj;
            ComposerKt.sourceInformationMarkerEnd(r4);
            ComposerKt.sourceInformationMarkerStart(composer4, 1147918695, str);
            objRememberedValue = composer4.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                obj2 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj4) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$56$lambda$55$lambda$54(webViewInstance$delegate2, (WebView) obj4);
                    }
                };
                composer4.updateRememberedValue(obj2);
            } else {
                obj2 = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd(composer4);
            AndroidView_androidKt.AndroidView(function5, modifierFillMaxSize$default2, (Function1) obj2, composer4, 432, 0);
            ComposerKt.sourceInformationMarkerEnd(composer4);
            ComposerKt.sourceInformationMarkerEnd(composer4);
            composer3.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            if (showChrome3) {
                composer5 = composer9;
                composer5.startReplaceGroup(-722432492);
                ComposerKt.sourceInformation(composer5, "614@34029L44,620@34312L2268,613@33989L2591");
                CardKt.Card(SizeKt.m١٢٥٢height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), CDp.m٧٩٥٨constructorimpl(130)), RoundedCornerShapeKt.m١٥٧٣RoundedCornerShapea9UjIt4$default(CDp.m٧٩٥٨constructorimpl(12), CDp.m٧٩٥٨constructorimpl(12), 0.0f, 0.0f, 12, null), CardDefaults.INSTANCE.m٢٥٨٣cardColorsro_MJ88(ColorKt.getObsidianSurface(), 0L, 0L, 0L, composer9, (CardDefaults.$stable << 12) | 6, 14), null, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder()), ComposableLambdaKt.rememberComposableLambda(-500878464, true, new Function3() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$65(consoleLogs2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, composer5, 54), composer5, 221190, 8);
            } else {
                composer5 = composer9;
                composer5.startReplaceGroup(-756221593);
            }
            composer5.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer5);
            ComposerKt.sourceInformationMarkerEnd(composer);
            r7.endNode();
            ComposerKt.sourceInformationMarkerEnd(r7);
            ComposerKt.sourceInformationMarkerEnd(r7);
            ComposerKt.sourceInformationMarkerEnd($composer5);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            showChrome2 = showChrome3;
            modifier3 = modifier6;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer3.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj4, Object obj5) {
                    return BrowserScreenKt.BrowserScreen$lambda$67(viewModel, showChrome2, modifier3, $changed, i, (Composer) obj4, ((Integer) obj5).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final WebView BrowserScreen$lambda$1(MutableState<WebView> mutableState) {
        return mutableState.getValue();
    }

    private static final String BrowserScreen$lambda$4(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    private static final String BrowserScreen$lambda$7(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    private static final boolean BrowserScreen$lambda$10(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void BrowserScreen$lambda$11(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final int BrowserScreen$lambda$13(MutableState<Integer> mutableState) {
        return mutableState.getValue().intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void BrowserScreen$lambda$14(MutableState<Integer> mutableState, int i) {
        mutableState.setValue(Integer.valueOf(i));
    }

    private static final boolean BrowserScreen$lambda$16(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void BrowserScreen$lambda$17(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final boolean BrowserScreen$lambda$19(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void BrowserScreen$lambda$20(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String BrowserScreen$lambda$25(State<String> state) {
        return (String) state.getValue();
    }

    /* JADX WARN: Code duplicated, block: B:28:0x01e8  */
    /* JADX WARN: Code duplicated, block: B:31:0x01f4  */
    /* JADX WARN: Code duplicated, block: B:32:0x01f8  */
    /* JADX WARN: Code duplicated, block: B:43:0x02e9  */
    /* JADX WARN: Code duplicated, block: B:44:0x02f7  */
    /* JADX WARN: Code duplicated, block: B:47:0x0377  */
    /* JADX WARN: Code duplicated, block: B:48:0x0385  */
    /* JADX WARN: Code duplicated, block: B:51:0x046d  */
    /* JADX WARN: Code duplicated, block: B:54:0x0478  */
    /* JADX WARN: Code duplicated, block: B:55:0x0487  */
    /* JADX WARN: Code duplicated, block: B:59:0x0512  */
    /* JADX WARN: Code duplicated, block: B:60:0x0520  */
    /* JADX WARN: Code duplicated, block: B:63:0x05ad  */
    /* JADX WARN: Code duplicated, block: B:67:0x05bf  */
    /* JADX WARN: Code duplicated, block: B:70:0x0638  */
    /* JADX WARN: Code duplicated, block: B:71:0x0646  */
    /* JADX WARN: Code duplicated, block: B:74:0x06d3  */
    /* JADX WARN: Code duplicated, block: B:78:0x06e0  */
    /* JADX WARN: Code duplicated, block: B:81:0x0728  */
    static final Unit BrowserScreen$lambda$66$lambda$46(final FocusManager $focusManager, final TransactionViewModel $viewModel, final Context $context, MutableState $canGoBack$delegate, final MutableState $webViewInstance$delegate, MutableState $canGoForward$delegate, final MutableState $urlInputText$delegate, final MutableState $currentUrl$delegate, final MutableState $isLoading$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Composer composer3;
        Object objRememberedValue;
        Object objRememberedValue2;
        boolean zChangedInstance;
        Object objRememberedValue3;
        Composer composer4;
        FocusManager focusManager;
        Composer composer5;
        Object objRememberedValue4;
        Object obj;
        boolean zChangedInstance2;
        Object objRememberedValue5;
        final MutableState mutableState;
        final MutableState mutableState2;
        final FocusManager focusManager2;
        Object objRememberedValue6;
        Object obj2;
        boolean zChangedInstance3;
        Object obj3;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C123@5506L6579:BrowserScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(304828744, $changed, -1, "com.example.ui.screens.BrowserScreen.<anonymous>.<anonymous> (BrowserScreen.kt:123)");
            }
            Modifier modifier = PaddingKt.m١١٩٦padding3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(10));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor2);
            } else {
                $composer.useNode();
            }
            Composer composer6 = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer6, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer6, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer6.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composer6.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                }
                Updater.m٤٤٩٥setimpl(composer6, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i2 = (i >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i3 = ((6 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1517976261, "C126@5597L5134,233@10749L40,239@10994L1077,236@10840L1231:BrowserScreen.kt#2thlc2");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                Arrangement.Horizontal horizontal = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(8));
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontal, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i4 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    composer2.createNode(constructor);
                } else {
                    composer2.useNode();
                }
                composer3 = Updater.m٤٤٨٨constructorimpl(composer2);
                Updater.m٤٤٩٥setimpl(composer3, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer3, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer3.getInserting() || !Intrinsics.areEqual(composer3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composer3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composer3.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m٤٤٩٥setimpl(composer3, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i5 = (i4 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i6 = ((438 >> 6) & 112) | 6;
                RowScope rowScope = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, 924057528, "C135@6046L187,133@5918L29,132@5872L561,148@6673L187,146@6539L32,145@6493L573,161@7316L425,174@8019L607,160@7234L21,158@7129L1733,205@9592L44,194@8971L567,193@8925L994,223@10346L44,216@10032L260,225@10470L243,215@9986L727:BrowserScreen.kt#2thlc2");
                boolean zBrowserScreen$lambda$16 = BrowserScreen$lambda$16($canGoBack$delegate);
                IconButtonDefaults iconButtonDefaults = IconButtonDefaults.INSTANCE;
                long goldPrimary = ColorKt.getGoldPrimary();
                long textSecondaryDark = ColorKt.getTextSecondaryDark();
                IconButtonColors iconButtonColors = iconButtonDefaults.m٢٩٢٨iconButtonColorsro_MJ88(0L, goldPrimary, 0L, Color.m٥٠٦٧copywmQWz5c(textSecondaryDark, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(textSecondaryDark) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(textSecondaryDark) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(textSecondaryDark) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(textSecondaryDark) : 0.0f), composer2, (IconButtonDefaults.$stable << 12) | 3120, 5);
                Modifier modifier2 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                ComposerKt.sourceInformationMarkerStart(composer2, -247289697, "CC(remember):BrowserScreen.kt#9igjgp");
                objRememberedValue = composer2.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٤٦xe35fe874($webViewInstance$delegate);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                IconButtonKt.IconButton((Function0) objRememberedValue, modifier2, zBrowserScreen$lambda$16, iconButtonColors, null, ComposableSingletons$BrowserScreenKt.INSTANCE.m٨٣٥٤getLambda$1024999489$app(), composer2, 196662, 16);
                boolean zBrowserScreen$lambda$19 = BrowserScreen$lambda$19($canGoForward$delegate);
                IconButtonDefaults iconButtonDefaults2 = IconButtonDefaults.INSTANCE;
                long goldPrimary2 = ColorKt.getGoldPrimary();
                long textSecondaryDark2 = ColorKt.getTextSecondaryDark();
                IconButtonColors iconButtonColors2 = iconButtonDefaults2.m٢٩٢٨iconButtonColorsro_MJ88(0L, goldPrimary2, 0L, Color.m٥٠٦٧copywmQWz5c(textSecondaryDark2, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(textSecondaryDark2) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(textSecondaryDark2) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(textSecondaryDark2) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(textSecondaryDark2) : 0.0f), composer2, (IconButtonDefaults.$stable << 12) | 3120, 5);
                Modifier modifier3 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                ComposerKt.sourceInformationMarkerStart(composer2, -247269822, "CC(remember):BrowserScreen.kt#9igjgp");
                objRememberedValue2 = composer2.rememberedValue();
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٤٧x43ebf7cd($webViewInstance$delegate);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                IconButtonKt.IconButton((Function0) objRememberedValue2, modifier3, zBrowserScreen$lambda$19, iconButtonColors2, null, ComposableSingletons$BrowserScreenKt.INSTANCE.getLambda$586216438$app(), composer2, 196662, 16);
                String strBrowserScreen$lambda$7 = BrowserScreen$lambda$7($urlInputText$delegate);
                TextFieldColors textFieldColors = OutlinedTextFieldDefaults.INSTANCE.m٣١٣٣colors0hiis_0(ColorKt.getTextPrimaryDark(), ColorKt.getTextPrimaryDark(), 0L, 0L, ColorKt.getObsidianDark(), ColorKt.getObsidianDark(), 0L, 0L, 0L, 0L, null, ColorKt.getGoldPrimary(), ColorKt.getObsidianBorder(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 221238, 432, 0, 0, 3072, 2147477452, 4095);
                KeyboardOptions keyboardOptions = new KeyboardOptions(0, (Boolean) null, 0, ImeAction.INSTANCE.m٧٥٨٣getGoeUduSuo(), (PlatformImeOptions) null, (Boolean) null, (LocaleList) null, 119, (DefaultConstructorMarker) null);
                ComposerKt.sourceInformationMarkerStart(composer2, -247221887, "CC(remember):BrowserScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($focusManager) | composer2.changedInstance($viewModel) | composer2.changedInstance($context);
                objRememberedValue3 = composer2.rememberedValue();
                if (zChangedInstance) {
                    composer4 = composer2;
                } else {
                    composer4 = composer2;
                    if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                        focusManager = $focusManager;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    KeyboardActions keyboardActions = new KeyboardActions(null, (Function1) objRememberedValue3, null, null, null, null, 61, null);
                    Modifier modifierTestTag = TestTagKt.testTag(SizeKt.m١٢٥٢height3ABfNKs(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), CDp.m٧٩٥٨constructorimpl(48)), "browser_address_bar");
                    composer5 = composer4;
                    ComposerKt.sourceInformationMarkerStart(composer5, -247247593, "CC(remember):BrowserScreen.kt#9igjgp");
                    objRememberedValue4 = composer5.rememberedValue();
                    if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                        obj = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda10
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj4) {
                                return BrowserScreenKt.m٨٣٤٩x977ec2ea($urlInputText$delegate, (String) obj4);
                            }
                        };
                        composer5.updateRememberedValue(obj);
                    } else {
                        obj = objRememberedValue4;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    OutlinedTextFieldKt.OutlinedTextField(strBrowserScreen$lambda$7, (Function1<? super String, Unit>) obj, modifierTestTag, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, keyboardOptions, keyboardActions, true, 0, 0, (MutableInteractionSource) null, (Shape) null, textFieldColors, composer5, 48, 12779520, 0, 3964920);
                    IconButtonColors iconButtonColors3 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, composer5, (IconButtonDefaults.$stable << 12) | 48, 13);
                    Modifier modifier4 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                    ComposerKt.sourceInformationMarkerStart(composer5, -247191463, "CC(remember):BrowserScreen.kt#9igjgp");
                    zChangedInstance2 = composer5.changedInstance(focusManager) | composer5.changedInstance($viewModel) | composer5.changedInstance($context);
                    objRememberedValue5 = composer5.rememberedValue();
                    if (!zChangedInstance2 || objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                        mutableState = $webViewInstance$delegate;
                        mutableState2 = $urlInputText$delegate;
                        focusManager2 = $focusManager;
                        objRememberedValue5 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return BrowserScreenKt.m٨٣٥٠xc148286e(focusManager2, $viewModel, $context, mutableState2, $currentUrl$delegate, mutableState);
                            }
                        };
                        composer5.updateRememberedValue(objRememberedValue5);
                    } else {
                        mutableState = $webViewInstance$delegate;
                        mutableState2 = $urlInputText$delegate;
                        focusManager2 = focusManager;
                    }
                    ComposerKt.sourceInformationMarkerEnd(r1);
                    IconButtonKt.IconButton((Function0) objRememberedValue5, modifier4, false, iconButtonColors3, null, ComposableSingletons$BrowserScreenKt.INSTANCE.getLambda$2049854455$app(), r1, 196656, 20);
                    IconButtonColors iconButtonColors4 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, r1, (IconButtonDefaults.$stable << 12) | 48, 13);
                    Modifier modifier5 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                    ComposerKt.sourceInformationMarkerStart(composer5, -247157818, "CC(remember):BrowserScreen.kt#9igjgp");
                    objRememberedValue6 = composer5.rememberedValue();
                    if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                        obj2 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda12
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return BrowserScreenKt.m٨٣٥١xeb118df2($isLoading$delegate, mutableState);
                            }
                        };
                        composer5.updateRememberedValue(obj2);
                    } else {
                        obj2 = objRememberedValue6;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    IconButtonKt.IconButton((Function0) obj2, modifier5, false, iconButtonColors4, null, ComposableLambdaKt.rememberComposableLambda(-781474824, true, new Function2() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda13
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj4, Object obj5) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$39($isLoading$delegate, (Composer) obj4, ((Integer) obj5).intValue());
                        }
                    }, composer5, 54), composer5, 196662, 20);
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), r43, 6);
                    Arrangement.HorizontalOrVertical horizontalOrVertical = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(8));
                    Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                    Arrangement.HorizontalOrVertical horizontalOrVertical2 = horizontalOrVertical;
                    ComposerKt.sourceInformationMarkerStart(r43, 228294995, "CC(remember):BrowserScreen.kt#9igjgp");
                    zChangedInstance3 = r43.changedInstance(focusManager2);
                    Object objRememberedValue7 = r43.rememberedValue();
                    if (!zChangedInstance3 || objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
                        obj3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda14
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj4) {
                                return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(focusManager2, $currentUrl$delegate, mutableState2, mutableState, (LazyListScope) obj4);
                            }
                        };
                        r43.updateRememberedValue(obj3);
                    } else {
                        obj3 = objRememberedValue7;
                    }
                    ComposerKt.sourceInformationMarkerEnd(r43);
                    LazyDslKt.LazyRow(modifierFillMaxWidth$default2, null, null, false, horizontalOrVertical2, null, null, false, (Function1) obj3, composer2, 24582, 238);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                focusManager = $focusManager;
                objRememberedValue3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj4) {
                        return BrowserScreenKt.m٨٣٤٨x6db55d66($focusManager, $viewModel, $context, $urlInputText$delegate, $currentUrl$delegate, $webViewInstance$delegate, (KeyboardActionScope) obj4);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue3);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                KeyboardActions keyboardActions2 = new KeyboardActions(null, (Function1) objRememberedValue3, null, null, null, null, 61, null);
                Modifier modifierTestTag2 = TestTagKt.testTag(SizeKt.m١٢٥٢height3ABfNKs(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), CDp.m٧٩٥٨constructorimpl(48)), "browser_address_bar");
                composer5 = composer4;
                ComposerKt.sourceInformationMarkerStart(composer5, -247247593, "CC(remember):BrowserScreen.kt#9igjgp");
                objRememberedValue4 = composer5.rememberedValue();
                if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.m٨٣٤٩x977ec2ea($urlInputText$delegate, (String) obj4);
                        }
                    };
                    composer5.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue4;
                }
                ComposerKt.sourceInformationMarkerEnd(composer5);
                OutlinedTextFieldKt.OutlinedTextField(strBrowserScreen$lambda$7, (Function1<? super String, Unit>) obj, modifierTestTag2, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, keyboardOptions, keyboardActions2, true, 0, 0, (MutableInteractionSource) null, (Shape) null, textFieldColors, composer5, 48, 12779520, 0, 3964920);
                IconButtonColors iconButtonColors5 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, composer5, (IconButtonDefaults.$stable << 12) | 48, 13);
                Modifier modifier6 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                ComposerKt.sourceInformationMarkerStart(composer5, -247191463, "CC(remember):BrowserScreen.kt#9igjgp");
                zChangedInstance2 = composer5.changedInstance(focusManager) | composer5.changedInstance($viewModel) | composer5.changedInstance($context);
                objRememberedValue5 = composer5.rememberedValue();
                if (zChangedInstance2) {
                    mutableState = $webViewInstance$delegate;
                    mutableState2 = $urlInputText$delegate;
                    focusManager2 = $focusManager;
                    objRememberedValue5 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٥٠xc148286e(focusManager2, $viewModel, $context, mutableState2, $currentUrl$delegate, mutableState);
                        }
                    };
                    composer5.updateRememberedValue(objRememberedValue5);
                } else {
                    mutableState = $webViewInstance$delegate;
                    mutableState2 = $urlInputText$delegate;
                    focusManager2 = $focusManager;
                    objRememberedValue5 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٥٠xc148286e(focusManager2, $viewModel, $context, mutableState2, $currentUrl$delegate, mutableState);
                        }
                    };
                    composer5.updateRememberedValue(objRememberedValue5);
                }
                ComposerKt.sourceInformationMarkerEnd(r1);
                IconButtonKt.IconButton((Function0) objRememberedValue5, modifier6, false, iconButtonColors5, null, ComposableSingletons$BrowserScreenKt.INSTANCE.getLambda$2049854455$app(), r1, 196656, 20);
                IconButtonColors iconButtonColors6 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, r1, (IconButtonDefaults.$stable << 12) | 48, 13);
                Modifier modifier7 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                ComposerKt.sourceInformationMarkerStart(composer5, -247157818, "CC(remember):BrowserScreen.kt#9igjgp");
                objRememberedValue6 = composer5.rememberedValue();
                if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                    obj2 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٥١xeb118df2($isLoading$delegate, mutableState);
                        }
                    };
                    composer5.updateRememberedValue(obj2);
                } else {
                    obj2 = objRememberedValue6;
                }
                ComposerKt.sourceInformationMarkerEnd(composer5);
                IconButtonKt.IconButton((Function0) obj2, modifier7, false, iconButtonColors6, null, ComposableLambdaKt.rememberComposableLambda(-781474824, true, new Function2() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda13
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj4, Object obj5) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$39($isLoading$delegate, (Composer) obj4, ((Integer) obj5).intValue());
                    }
                }, composer5, 54), composer5, 196662, 20);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), r43, 6);
                Arrangement.HorizontalOrVertical horizontalOrVertical3 = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(8));
                Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.HorizontalOrVertical horizontalOrVertical4 = horizontalOrVertical3;
                ComposerKt.sourceInformationMarkerStart(r43, 228294995, "CC(remember):BrowserScreen.kt#9igjgp");
                zChangedInstance3 = r43.changedInstance(focusManager2);
                Object objRememberedValue8 = r43.rememberedValue();
                if (zChangedInstance3) {
                    obj3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(focusManager2, $currentUrl$delegate, mutableState2, mutableState, (LazyListScope) obj4);
                        }
                    };
                    r43.updateRememberedValue(obj3);
                } else {
                    obj3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(focusManager2, $currentUrl$delegate, mutableState2, mutableState, (LazyListScope) obj4);
                        }
                    };
                    r43.updateRememberedValue(obj3);
                }
                ComposerKt.sourceInformationMarkerEnd(r43);
                LazyDslKt.LazyRow(modifierFillMaxWidth$default3, null, null, false, horizontalOrVertical4, null, null, false, (Function1) obj3, composer2, 24582, 238);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composer6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composer6.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash);
            Updater.m٤٤٩٥setimpl(composer6, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i7 = (i >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i8 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1517976261, "C126@5597L5134,233@10749L40,239@10994L1077,236@10840L1231:BrowserScreen.kt#2thlc2");
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
            Arrangement.Horizontal horizontal2 = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(8));
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontal2, centerVertically2, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default4);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i9 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                composer2.createNode(constructor);
            } else {
                composer2.useNode();
            }
            composer3 = Updater.m٤٤٨٨constructorimpl(composer2);
            Updater.m٤٤٩٥setimpl(composer3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer3.getInserting()) {
            }
            composer3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composer3.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash3);
            Updater.m٤٤٩٥setimpl(composer3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
            int i10 = (i9 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i11 = ((438 >> 6) & 112) | 6;
            RowScope rowScope2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, 924057528, "C135@6046L187,133@5918L29,132@5872L561,148@6673L187,146@6539L32,145@6493L573,161@7316L425,174@8019L607,160@7234L21,158@7129L1733,205@9592L44,194@8971L567,193@8925L994,223@10346L44,216@10032L260,225@10470L243,215@9986L727:BrowserScreen.kt#2thlc2");
            boolean zBrowserScreen$lambda$17 = BrowserScreen$lambda$16($canGoBack$delegate);
            IconButtonDefaults iconButtonDefaults3 = IconButtonDefaults.INSTANCE;
            long goldPrimary3 = ColorKt.getGoldPrimary();
            long textSecondaryDark3 = ColorKt.getTextSecondaryDark();
            IconButtonColors iconButtonColors7 = iconButtonDefaults3.m٢٩٢٨iconButtonColorsro_MJ88(0L, goldPrimary3, 0L, Color.m٥٠٦٧copywmQWz5c(textSecondaryDark3, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(textSecondaryDark3) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(textSecondaryDark3) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(textSecondaryDark3) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(textSecondaryDark3) : 0.0f), composer2, (IconButtonDefaults.$stable << 12) | 3120, 5);
            Modifier modifier8 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
            ComposerKt.sourceInformationMarkerStart(composer2, -247289697, "CC(remember):BrowserScreen.kt#9igjgp");
            objRememberedValue = composer2.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BrowserScreenKt.m٨٣٤٦xe35fe874($webViewInstance$delegate);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer2);
            IconButtonKt.IconButton((Function0) objRememberedValue, modifier8, zBrowserScreen$lambda$17, iconButtonColors7, null, ComposableSingletons$BrowserScreenKt.INSTANCE.m٨٣٥٤getLambda$1024999489$app(), composer2, 196662, 16);
            boolean zBrowserScreen$lambda$110 = BrowserScreen$lambda$19($canGoForward$delegate);
            IconButtonDefaults iconButtonDefaults4 = IconButtonDefaults.INSTANCE;
            long goldPrimary4 = ColorKt.getGoldPrimary();
            long textSecondaryDark4 = ColorKt.getTextSecondaryDark();
            IconButtonColors iconButtonColors8 = iconButtonDefaults4.m٢٩٢٨iconButtonColorsro_MJ88(0L, goldPrimary4, 0L, Color.m٥٠٦٧copywmQWz5c(textSecondaryDark4, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(textSecondaryDark4) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(textSecondaryDark4) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(textSecondaryDark4) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(textSecondaryDark4) : 0.0f), composer2, (IconButtonDefaults.$stable << 12) | 3120, 5);
            Modifier modifier9 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
            ComposerKt.sourceInformationMarkerStart(composer2, -247269822, "CC(remember):BrowserScreen.kt#9igjgp");
            objRememberedValue2 = composer2.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue2 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BrowserScreenKt.m٨٣٤٧x43ebf7cd($webViewInstance$delegate);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue2);
            }
            ComposerKt.sourceInformationMarkerEnd(composer2);
            IconButtonKt.IconButton((Function0) objRememberedValue2, modifier9, zBrowserScreen$lambda$110, iconButtonColors8, null, ComposableSingletons$BrowserScreenKt.INSTANCE.getLambda$586216438$app(), composer2, 196662, 16);
            String strBrowserScreen$lambda$8 = BrowserScreen$lambda$7($urlInputText$delegate);
            TextFieldColors textFieldColors2 = OutlinedTextFieldDefaults.INSTANCE.m٣١٣٣colors0hiis_0(ColorKt.getTextPrimaryDark(), ColorKt.getTextPrimaryDark(), 0L, 0L, ColorKt.getObsidianDark(), ColorKt.getObsidianDark(), 0L, 0L, 0L, 0L, null, ColorKt.getGoldPrimary(), ColorKt.getObsidianBorder(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 221238, 432, 0, 0, 3072, 2147477452, 4095);
            KeyboardOptions keyboardOptions2 = new KeyboardOptions(0, (Boolean) null, 0, ImeAction.INSTANCE.m٧٥٨٣getGoeUduSuo(), (PlatformImeOptions) null, (Boolean) null, (LocaleList) null, 119, (DefaultConstructorMarker) null);
            ComposerKt.sourceInformationMarkerStart(composer2, -247221887, "CC(remember):BrowserScreen.kt#9igjgp");
            zChangedInstance = composer2.changedInstance($focusManager) | composer2.changedInstance($viewModel) | composer2.changedInstance($context);
            objRememberedValue3 = composer2.rememberedValue();
            if (zChangedInstance) {
                composer4 = composer2;
                if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                    focusManager = $focusManager;
                }
                ComposerKt.sourceInformationMarkerEnd(composer4);
                KeyboardActions keyboardActions3 = new KeyboardActions(null, (Function1) objRememberedValue3, null, null, null, null, 61, null);
                Modifier modifierTestTag3 = TestTagKt.testTag(SizeKt.m١٢٥٢height3ABfNKs(RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), CDp.m٧٩٥٨constructorimpl(48)), "browser_address_bar");
                composer5 = composer4;
                ComposerKt.sourceInformationMarkerStart(composer5, -247247593, "CC(remember):BrowserScreen.kt#9igjgp");
                objRememberedValue4 = composer5.rememberedValue();
                if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.m٨٣٤٩x977ec2ea($urlInputText$delegate, (String) obj4);
                        }
                    };
                    composer5.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue4;
                }
                ComposerKt.sourceInformationMarkerEnd(composer5);
                OutlinedTextFieldKt.OutlinedTextField(strBrowserScreen$lambda$8, (Function1<? super String, Unit>) obj, modifierTestTag3, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, keyboardOptions2, keyboardActions3, true, 0, 0, (MutableInteractionSource) null, (Shape) null, textFieldColors2, composer5, 48, 12779520, 0, 3964920);
                IconButtonColors iconButtonColors9 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, composer5, (IconButtonDefaults.$stable << 12) | 48, 13);
                Modifier modifier10 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                ComposerKt.sourceInformationMarkerStart(composer5, -247191463, "CC(remember):BrowserScreen.kt#9igjgp");
                zChangedInstance2 = composer5.changedInstance(focusManager) | composer5.changedInstance($viewModel) | composer5.changedInstance($context);
                objRememberedValue5 = composer5.rememberedValue();
                if (zChangedInstance2) {
                    mutableState = $webViewInstance$delegate;
                    mutableState2 = $urlInputText$delegate;
                    focusManager2 = $focusManager;
                    objRememberedValue5 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٥٠xc148286e(focusManager2, $viewModel, $context, mutableState2, $currentUrl$delegate, mutableState);
                        }
                    };
                    composer5.updateRememberedValue(objRememberedValue5);
                } else {
                    mutableState = $webViewInstance$delegate;
                    mutableState2 = $urlInputText$delegate;
                    focusManager2 = $focusManager;
                    objRememberedValue5 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٥٠xc148286e(focusManager2, $viewModel, $context, mutableState2, $currentUrl$delegate, mutableState);
                        }
                    };
                    composer5.updateRememberedValue(objRememberedValue5);
                }
                ComposerKt.sourceInformationMarkerEnd(r1);
                IconButtonKt.IconButton((Function0) objRememberedValue5, modifier10, false, iconButtonColors9, null, ComposableSingletons$BrowserScreenKt.INSTANCE.getLambda$2049854455$app(), r1, 196656, 20);
                IconButtonColors iconButtonColors10 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, r1, (IconButtonDefaults.$stable << 12) | 48, 13);
                Modifier modifier11 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
                ComposerKt.sourceInformationMarkerStart(composer5, -247157818, "CC(remember):BrowserScreen.kt#9igjgp");
                objRememberedValue6 = composer5.rememberedValue();
                if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                    obj2 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BrowserScreenKt.m٨٣٥١xeb118df2($isLoading$delegate, mutableState);
                        }
                    };
                    composer5.updateRememberedValue(obj2);
                } else {
                    obj2 = objRememberedValue6;
                }
                ComposerKt.sourceInformationMarkerEnd(composer5);
                IconButtonKt.IconButton((Function0) obj2, modifier11, false, iconButtonColors10, null, ComposableLambdaKt.rememberComposableLambda(-781474824, true, new Function2() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda13
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj4, Object obj5) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$39($isLoading$delegate, (Composer) obj4, ((Integer) obj5).intValue());
                    }
                }, composer5, 54), composer5, 196662, 20);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), r43, 6);
                Arrangement.HorizontalOrVertical horizontalOrVertical5 = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(8));
                Modifier modifierFillMaxWidth$default5 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.HorizontalOrVertical horizontalOrVertical6 = horizontalOrVertical5;
                ComposerKt.sourceInformationMarkerStart(r43, 228294995, "CC(remember):BrowserScreen.kt#9igjgp");
                zChangedInstance3 = r43.changedInstance(focusManager2);
                Object objRememberedValue9 = r43.rememberedValue();
                if (zChangedInstance3) {
                    obj3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(focusManager2, $currentUrl$delegate, mutableState2, mutableState, (LazyListScope) obj4);
                        }
                    };
                    r43.updateRememberedValue(obj3);
                } else {
                    obj3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(focusManager2, $currentUrl$delegate, mutableState2, mutableState, (LazyListScope) obj4);
                        }
                    };
                    r43.updateRememberedValue(obj3);
                }
                ComposerKt.sourceInformationMarkerEnd(r43);
                LazyDslKt.LazyRow(modifierFillMaxWidth$default5, null, null, false, horizontalOrVertical6, null, null, false, (Function1) obj3, composer2, 24582, 238);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer4 = composer2;
            }
            focusManager = $focusManager;
            objRememberedValue3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj4) {
                    return BrowserScreenKt.m٨٣٤٨x6db55d66($focusManager, $viewModel, $context, $urlInputText$delegate, $currentUrl$delegate, $webViewInstance$delegate, (KeyboardActionScope) obj4);
                }
            };
            composer2.updateRememberedValue(objRememberedValue3);
            ComposerKt.sourceInformationMarkerEnd(composer4);
            KeyboardActions keyboardActions4 = new KeyboardActions(null, (Function1) objRememberedValue3, null, null, null, null, 61, null);
            Modifier modifierTestTag4 = TestTagKt.testTag(SizeKt.m١٢٥٢height3ABfNKs(RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), CDp.m٧٩٥٨constructorimpl(48)), "browser_address_bar");
            composer5 = composer4;
            ComposerKt.sourceInformationMarkerStart(composer5, -247247593, "CC(remember):BrowserScreen.kt#9igjgp");
            objRememberedValue4 = composer5.rememberedValue();
            if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                obj = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda10
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj4) {
                        return BrowserScreenKt.m٨٣٤٩x977ec2ea($urlInputText$delegate, (String) obj4);
                    }
                };
                composer5.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue4;
            }
            ComposerKt.sourceInformationMarkerEnd(composer5);
            OutlinedTextFieldKt.OutlinedTextField(strBrowserScreen$lambda$8, (Function1<? super String, Unit>) obj, modifierTestTag4, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, keyboardOptions2, keyboardActions4, true, 0, 0, (MutableInteractionSource) null, (Shape) null, textFieldColors2, composer5, 48, 12779520, 0, 3964920);
            IconButtonColors iconButtonColors11 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, composer5, (IconButtonDefaults.$stable << 12) | 48, 13);
            Modifier modifier12 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
            ComposerKt.sourceInformationMarkerStart(composer5, -247191463, "CC(remember):BrowserScreen.kt#9igjgp");
            zChangedInstance2 = composer5.changedInstance(focusManager) | composer5.changedInstance($viewModel) | composer5.changedInstance($context);
            objRememberedValue5 = composer5.rememberedValue();
            if (zChangedInstance2) {
                mutableState = $webViewInstance$delegate;
                mutableState2 = $urlInputText$delegate;
                focusManager2 = $focusManager;
                objRememberedValue5 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda11
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BrowserScreenKt.m٨٣٥٠xc148286e(focusManager2, $viewModel, $context, mutableState2, $currentUrl$delegate, mutableState);
                    }
                };
                composer5.updateRememberedValue(objRememberedValue5);
            } else {
                mutableState = $webViewInstance$delegate;
                mutableState2 = $urlInputText$delegate;
                focusManager2 = $focusManager;
                objRememberedValue5 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda11
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BrowserScreenKt.m٨٣٥٠xc148286e(focusManager2, $viewModel, $context, mutableState2, $currentUrl$delegate, mutableState);
                    }
                };
                composer5.updateRememberedValue(objRememberedValue5);
            }
            ComposerKt.sourceInformationMarkerEnd(r1);
            IconButtonKt.IconButton((Function0) objRememberedValue5, modifier12, false, iconButtonColors11, null, ComposableSingletons$BrowserScreenKt.INSTANCE.getLambda$2049854455$app(), r1, 196656, 20);
            IconButtonColors iconButtonColors12 = IconButtonDefaults.INSTANCE.m٢٩٢٨iconButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, r1, (IconButtonDefaults.$stable << 12) | 48, 13);
            Modifier modifier13 = SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36));
            ComposerKt.sourceInformationMarkerStart(composer5, -247157818, "CC(remember):BrowserScreen.kt#9igjgp");
            objRememberedValue6 = composer5.rememberedValue();
            if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                obj2 = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda12
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BrowserScreenKt.m٨٣٥١xeb118df2($isLoading$delegate, mutableState);
                    }
                };
                composer5.updateRememberedValue(obj2);
            } else {
                obj2 = objRememberedValue6;
            }
            ComposerKt.sourceInformationMarkerEnd(composer5);
            IconButtonKt.IconButton((Function0) obj2, modifier13, false, iconButtonColors12, null, ComposableLambdaKt.rememberComposableLambda(-781474824, true, new Function2() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj4, Object obj5) {
                    return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$39($isLoading$delegate, (Composer) obj4, ((Integer) obj5).intValue());
                }
            }, composer5, 54), composer5, 196662, 20);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), r43, 6);
            Arrangement.HorizontalOrVertical horizontalOrVertical7 = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(8));
            Modifier modifierFillMaxWidth$default6 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.HorizontalOrVertical horizontalOrVertical8 = horizontalOrVertical7;
            ComposerKt.sourceInformationMarkerStart(r43, 228294995, "CC(remember):BrowserScreen.kt#9igjgp");
            zChangedInstance3 = r43.changedInstance(focusManager2);
            Object objRememberedValue10 = r43.rememberedValue();
            if (zChangedInstance3) {
                obj3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda14
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj4) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(focusManager2, $currentUrl$delegate, mutableState2, mutableState, (LazyListScope) obj4);
                    }
                };
                r43.updateRememberedValue(obj3);
            } else {
                obj3 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda14
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj4) {
                        return BrowserScreenKt.BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(focusManager2, $currentUrl$delegate, mutableState2, mutableState, (LazyListScope) obj4);
                    }
                };
                r43.updateRememberedValue(obj3);
            }
            ComposerKt.sourceInformationMarkerEnd(r43);
            LazyDslKt.LazyRow(modifierFillMaxWidth$default6, null, null, false, horizontalOrVertical8, null, null, false, (Function1) obj3, composer2, 24582, 238);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$28$lambda$27, reason: contains not printable characters */
    static final Unit m٨٣٤٦xe35fe874(MutableState $webViewInstance$delegate) {
        WebView webViewBrowserScreen$lambda$1 = BrowserScreen$lambda$1($webViewInstance$delegate);
        if (webViewBrowserScreen$lambda$1 != null) {
            webViewBrowserScreen$lambda$1.goBack();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$30$lambda$29, reason: contains not printable characters */
    static final Unit m٨٣٤٧x43ebf7cd(MutableState $webViewInstance$delegate) {
        WebView webViewBrowserScreen$lambda$1 = BrowserScreen$lambda$1($webViewInstance$delegate);
        if (webViewBrowserScreen$lambda$1 != null) {
            webViewBrowserScreen$lambda$1.goForward();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$34$lambda$33, reason: contains not printable characters */
    static final Unit m٨٣٤٩x977ec2ea(MutableState $urlInputText$delegate, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $urlInputText$delegate.setValue(it);
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$32$lambda$31, reason: contains not printable characters */
    static final Unit m٨٣٤٨x6db55d66(FocusManager $focusManager, TransactionViewModel $viewModel, Context $context, MutableState $urlInputText$delegate, MutableState $currentUrl$delegate, MutableState $webViewInstance$delegate, KeyboardActionScope KeyboardActions) {
        Intrinsics.checkNotNullParameter(KeyboardActions, "$this$KeyboardActions");
        FocusManager.clearFocus$default($focusManager, false, 1, null);
        String target = StringsKt.trim((CharSequence) BrowserScreen$lambda$7($urlInputText$delegate)).toString();
        if (!StringsKt.startsWith$default(target, "http://", false, 2, (Object) null) && !StringsKt.startsWith$default(target, "https://", false, 2, (Object) null)) {
            target = "https://" + target;
        }
        registerCodeToMonitor(target, $viewModel, $context);
        $currentUrl$delegate.setValue(target);
        $urlInputText$delegate.setValue(target);
        WebView webViewBrowserScreen$lambda$1 = BrowserScreen$lambda$1($webViewInstance$delegate);
        if (webViewBrowserScreen$lambda$1 != null) {
            webViewBrowserScreen$lambda$1.loadUrl(target);
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$36$lambda$35, reason: contains not printable characters */
    static final Unit m٨٣٥٠xc148286e(FocusManager $focusManager, TransactionViewModel $viewModel, Context $context, MutableState $urlInputText$delegate, MutableState $currentUrl$delegate, MutableState $webViewInstance$delegate) {
        FocusManager.clearFocus$default($focusManager, false, 1, null);
        String target = StringsKt.trim((CharSequence) BrowserScreen$lambda$7($urlInputText$delegate)).toString();
        if (!StringsKt.startsWith$default(target, "http://", false, 2, (Object) null) && !StringsKt.startsWith$default(target, "https://", false, 2, (Object) null)) {
            target = "https://" + target;
        }
        registerCodeToMonitor(target, $viewModel, $context);
        $currentUrl$delegate.setValue(target);
        $urlInputText$delegate.setValue(target);
        WebView webViewBrowserScreen$lambda$1 = BrowserScreen$lambda$1($webViewInstance$delegate);
        if (webViewBrowserScreen$lambda$1 != null) {
            webViewBrowserScreen$lambda$1.loadUrl(target);
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$38$lambda$37, reason: contains not printable characters */
    static final Unit m٨٣٥١xeb118df2(MutableState $isLoading$delegate, MutableState $webViewInstance$delegate) {
        if (BrowserScreen$lambda$10($isLoading$delegate)) {
            WebView webViewBrowserScreen$lambda$1 = BrowserScreen$lambda$1($webViewInstance$delegate);
            if (webViewBrowserScreen$lambda$1 != null) {
                webViewBrowserScreen$lambda$1.stopLoading();
            }
        } else {
            WebView webViewBrowserScreen$lambda$2 = BrowserScreen$lambda$1($webViewInstance$delegate);
            if (webViewBrowserScreen$lambda$2 != null) {
                webViewBrowserScreen$lambda$2.reload();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$40$lambda$39(MutableState $isLoading$delegate, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C226@10496L195:BrowserScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-781474824, $changed, -1, "com.example.ui.screens.BrowserScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (BrowserScreen.kt:226)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(BrowserScreen$lambda$10($isLoading$delegate) ? CloseKt.getClose(Icons.INSTANCE.getDefault()) : RefreshKt.getRefresh(Icons.INSTANCE.getDefault()), "Refresh", (Modifier) null, 0L, $composer, 48, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43(final FocusManager $focusManager, final MutableState $currentUrl$delegate, final MutableState $urlInputText$delegate, final MutableState $webViewInstance$delegate, LazyListScope LazyRow) {
        Intrinsics.checkNotNullParameter(LazyRow, "$this$LazyRow");
        final List<Bookmark> list = BookmarksList;
        final Function1 function1 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                return invoke((Bookmark) p1);
            }

            @Override // kotlin.jvm.functions.Function1
            public final Void invoke(Bookmark bookmark) {
                return null;
            }
        };
        LazyRow.items(list.size(), null, new Function1<Integer, Object>() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43$$inlined$items$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int index) {
                return function1.invoke(list.get(index));
            }
        }, ComposableLambdaKt.composableLambdaInstance(-632812321, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$lambda$66$lambda$46$lambda$45$lambda$44$lambda$43$$inlined$items$default$4
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(4);
            }

            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(LazyItemScope $this$items, int it, Composer $composer, int $changed) {
                ComposerKt.sourceInformation($composer, "C152@7074L22:LazyDsl.kt#428nma");
                int $dirty = $changed;
                if (($changed & 6) == 0) {
                    $dirty |= $composer.changed($this$items) ? 4 : 2;
                }
                if (($changed & 48) == 0) {
                    $dirty |= $composer.changed(it) ? 32 : 16;
                }
                if (($dirty & 147) == 146 && $composer.getSkipping()) {
                    $composer.skipToGroupEnd();
                    return;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-632812321, $dirty, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:152)");
                }
                int i = $dirty & 14;
                final Bookmark bookmark = (Bookmark) list.get(it);
                $composer.startReplaceGroup(-1684172301);
                ComposerKt.sourceInformation($composer, "C*242@11122L278,251@11624L407,241@11075L956:BrowserScreen.kt#2thlc2");
                ComposerKt.sourceInformationMarkerStart($composer, -1301253302, "CC(remember):BrowserScreen.kt#9igjgp");
                boolean zChangedInstance = ((((i & 112) ^ 48) > 32 && $composer.changed(bookmark)) || (i & 48) == 32) | $composer.changedInstance($focusManager);
                Object objRememberedValue = $composer.rememberedValue();
                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    final FocusManager focusManager = $focusManager;
                    final MutableState mutableState = $currentUrl$delegate;
                    final MutableState mutableState2 = $urlInputText$delegate;
                    final MutableState mutableState3 = $webViewInstance$delegate;
                    objRememberedValue = new Function0<Unit>() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$1$1$2$1$1$1$1
                        @Override // kotlin.jvm.functions.Function0
                        public /* bridge */ /* synthetic */ Unit invoke() {
                            invoke2();
                            return Unit.INSTANCE;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final void invoke2() {
                            FocusManager.clearFocus$default(focusManager, false, 1, null);
                            mutableState.setValue(bookmark.getUrl());
                            mutableState2.setValue(bookmark.getUrl());
                            WebView webViewBrowserScreen$lambda$1 = BrowserScreenKt.BrowserScreen$lambda$1(mutableState3);
                            if (webViewBrowserScreen$lambda$1 != null) {
                                webViewBrowserScreen$lambda$1.loadUrl(bookmark.getUrl());
                            }
                        }
                    };
                    $composer.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd($composer);
                SurfaceKt.m٣٣٤٩Surfaceo_FOJdg((Function0) objRememberedValue, null, false, RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(16)), ColorKt.getObsidianSurfaceElevated(), 0L, 0.0f, 0.0f, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder()), null, ComposableLambdaKt.rememberComposableLambda(-252729633, true, new Function2<Composer, Integer, Unit>() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$1$1$2$1$1$2
                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Unit invoke(Composer composer, Integer num) {
                        invoke(composer, num.intValue());
                        return Unit.INSTANCE;
                    }

                    public final void invoke(Composer $composer2, int $changed2) {
                        ComposerKt.sourceInformation($composer2, "C252@11654L351:BrowserScreen.kt#2thlc2");
                        if (($changed2 & 3) == 2 && $composer2.getSkipping()) {
                            $composer2.skipToGroupEnd();
                            return;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-252729633, $changed2, -1, "com.example.ui.screens.BrowserScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (BrowserScreen.kt:252)");
                        }
                        TextKt.m٣٥٠٢Text4IGK_g(bookmark.getName(), PaddingKt.m١١٩٧paddingVpY3zN4(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(12), CDp.m٧٩٥٨constructorimpl(6)), ColorKt.getGoldPrimary(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer2, 200112, 0, 131024);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
                }, $composer, 54), $composer, 100687872, 6, 742);
                $composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
        }));
        return Unit.INSTANCE;
    }

    static final float BrowserScreen$lambda$66$lambda$48$lambda$47(MutableState $progress$delegate) {
        return BrowserScreen$lambda$13($progress$delegate) / 100.0f;
    }

    static final WebView BrowserScreen$lambda$66$lambda$56$lambda$53$lambda$52(MutableState $webViewInstance$delegate, final SnapshotStateList $consoleLogs, TransactionViewModel $viewModel, Context $context, MutableState $progress$delegate, final String $shimJs, final String $wafJs, final String $livenessJs, final MutableState $isLoading$delegate, final MutableState $currentUrl$delegate, final MutableState $urlInputText$delegate, final MutableState $canGoBack$delegate, final MutableState $canGoForward$delegate, Context ctx) {
        Intrinsics.checkNotNullParameter(ctx, "ctx");
        WebView.setWebContentsDebuggingEnabled(true);
        final WebView webView = new WebView(ctx);
        $webViewInstance$delegate.setValue(webView);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setOnTouchListener(new View.OnTouchListener() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda7
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return BrowserScreenKt.m٨٣٥٢xedaf7fa7(view, motionEvent);
            }
        });
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMixedContentMode(0);
        settings.setUserAgentString(DEFAULT_FAKE_UA);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new BrowserScreenKt$BrowserScreen$2$3$1$1$1$3(webView, $consoleLogs, $viewModel, $context, $webViewInstance$delegate), "AndroidBridge");
        webView.setWebChromeClient(new BrowserScreenKt$BrowserScreen$2$3$1$1$1$4($progress$delegate, $consoleLogs, $webViewInstance$delegate));
        webView.setWebViewClient(new WebViewClient() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$2$3$1$1$1$5
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) throws Throwable {
                Uri url;
                String reqUrl;
                if (request == null || (url = request.getUrl()) == null || (reqUrl = url.toString()) == null || !request.isForMainFrame() || !StringsKt.contains((CharSequence) reqUrl, (CharSequence) "/appointment/livenessrequest", true)) {
                    return false;
                }
                DebugLog.INSTANCE.add("NAV", "BLOCKED real navigation to " + reqUrl + " (cosmetic-only URL, not a real page)");
                $consoleLogs.add("🚫 Blocked a bad navigation to livenessrequest — staying on the selfie page");
                if ($consoleLogs.size() > 80) {
                    $consoleLogs.remove(0);
                }
                return true;
            }

            @Override // android.webkit.WebViewClient
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return BookerCsp.INSTANCE.intercept(request);
            }

            @Override // android.webkit.WebViewClient
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                BrowserScreenKt.BrowserScreen$lambda$11($isLoading$delegate, true);
                DebugLog.INSTANCE.add("NAV", "start " + url);
                if (url != null) {
                    $currentUrl$delegate.setValue(url);
                    $urlInputText$delegate.setValue(url);
                }
                BrowserScreenKt.injectLivenessExtension(view, $shimJs, $wafJs, $livenessJs);
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView view, String url) {
                BrowserScreenKt.BrowserScreen$lambda$11($isLoading$delegate, false);
                BrowserScreenKt.BrowserScreen$lambda$17($canGoBack$delegate, webView.canGoBack());
                BrowserScreenKt.BrowserScreen$lambda$20($canGoForward$delegate, webView.canGoForward());
                if (url != null) {
                    $currentUrl$delegate.setValue(url);
                    $urlInputText$delegate.setValue(url);
                }
                DebugLog.INSTANCE.add("NAV", "finished " + url);
                BrowserScreenKt.injectLivenessExtension(view, $shimJs, $wafJs, $livenessJs);
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                if (handler != null) {
                    handler.proceed();
                }
            }

            /* JADX WARN: Code duplicated, block: B:20:0x006d  */
            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) throws Throwable {
                boolean z;
                DebugLog.INSTANCE.add("ERR", "(" + (error != null ? Integer.valueOf(error.getErrorCode()) : null) + ") " + ((Object) (error != null ? error.getDescription() : null)) + " main=" + (request != null ? Boolean.valueOf(request.isForMainFrame()) : null) + " — " + (request != null ? request.getUrl() : null));
                if (request != null) {
                    z = request.isForMainFrame();
                }
                if (z) {
                    $consoleLogs.add("❌ Page failed (" + (error != null ? Integer.valueOf(error.getErrorCode()) : null) + "): " + ((Object) (error != null ? error.getDescription() : null)) + " — " + request.getUrl());
                    if ($consoleLogs.size() > 80) {
                        $consoleLogs.remove(0);
                    }
                }
            }
        });
        webView.loadUrl(BrowserScreen$lambda$4($currentUrl$delegate));
        return webView;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$56$lambda$53$lambda$52$lambda$51$lambda$49, reason: contains not printable characters */
    static final boolean m٨٣٥٢xedaf7fa7(View v, MotionEvent event) {
        switch (event.getAction()) {
            case 0:
            case 1:
                if (!v.hasFocus()) {
                    v.requestFocus();
                }
                break;
        }
        return false;
    }

    static final Unit BrowserScreen$lambda$66$lambda$56$lambda$55$lambda$54(MutableState $webViewInstance$delegate, WebView view) {
        Intrinsics.checkNotNullParameter(view, "view");
        $webViewInstance$delegate.setValue(view);
        return Unit.INSTANCE;
    }

    static final Unit BrowserScreen$lambda$66$lambda$65(final SnapshotStateList $consoleLogs, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Function0<ComposeUiNode> function1;
        Object obj;
        Composer composer;
        Function0<ComposeUiNode> function2;
        Composer composer2;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C621@34326L2244:BrowserScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-500878464, $changed, -1, "com.example.ui.screens.BrowserScreen.<anonymous>.<anonymous> (BrowserScreen.kt:621)");
            }
            Modifier modifier = PaddingKt.m١١٩٦padding3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(10));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor;
                $composer.createNode(function0);
            } else {
                function0 = constructor;
                $composer.useNode();
            }
            Composer composer3 = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer3, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer3, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer3.getInserting() || !Intrinsics.areEqual(composer3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composer3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composer3.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m٤٤٩٥setimpl(composer3, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i3 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -792887150, "C624@34417L847,645@35282L40:BrowserScreen.kt#2thlc2");
            Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor2;
                $composer.createNode(function1);
            } else {
                function1 = constructor2;
                $composer.useNode();
            }
            Composer composer4 = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer4, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer4, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer4.getInserting() || !Intrinsics.areEqual(composer4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                composer4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composer4.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
            }
            Updater.m٤٤٩٥setimpl(composer4, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i4 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            int i6 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 960865978, "C629@34655L285,641@35201L23,636@34961L285:BrowserScreen.kt#2thlc2");
            TextKt.m٣٥٠٢Text4IGK_g("INTEGRATED LOGS & INJECTION MONITOR", (Modifier) null, ColorKt.getGoldSecondary(), TextUnitKt.getSp(10), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, TextUnitKt.getSp(1), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 12782982, 0, 130898);
            long sp = TextUnitKt.getSp(11);
            long stateError = ColorKt.getStateError();
            FontWeight bold = FontWeight.INSTANCE.getBold();
            Modifier.Companion companion = Modifier.INSTANCE;
            ComposerKt.sourceInformationMarkerStart($composer, 446654577, "CC(remember):BrowserScreen.kt#9igjgp");
            Object objRememberedValue = $composer.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BrowserScreenKt.m٨٣٥٣x6ffd2bd0($consoleLogs);
                    }
                };
                $composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            TextKt.m٣٥٠٢Text4IGK_g("Clear", ClickableKt.m٧٠٠clickableXHw0xAI$default(companion, false, null, null, (Function0) objRememberedValue, 7, null), stateError, sp, (FontStyle) null, bold, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200070, 0, 131024);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(4)), $composer, 6);
            if ($consoleLogs.isEmpty()) {
                $composer.startReplaceGroup(-791993762);
                ComposerKt.sourceInformation($composer, "648@35389L518");
                Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                Alignment center = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart($composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxSize$default);
                Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i7 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function2 = constructor3;
                    $composer.createNode(function2);
                } else {
                    function2 = constructor3;
                    $composer.useNode();
                }
                Composer composer5 = Updater.m٤٤٨٨constructorimpl($composer);
                Updater.m٤٤٩٥setimpl(composer5, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer5, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composer5.getInserting()) {
                    composer2 = $composer;
                } else {
                    composer2 = $composer;
                    if (!Intrinsics.areEqual(composer5.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    }
                    Updater.m٤٤٩٥setimpl(composer5, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                    int i8 = (i7 >> 6) & 14;
                    Composer composer6 = composer2;
                    ComposerKt.sourceInformationMarkerStart(composer6, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                    int i9 = ((54 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer6, -1147204856, "C652@35561L324:BrowserScreen.kt#2thlc2");
                    TextKt.m٣٥٠٢Text4IGK_g("No active logs. Navigate to blsspainglobal/blsspainmorocco/Portugal sites to trigger automation.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, TextAlign.m٧٨٠٤boximpl(TextAlign.INSTANCE.m٧٨١١getCentere0LSkKk()), 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer6, 3462, 0, 130546);
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    $composer.endReplaceGroup();
                    composer = $composer;
                }
                composer5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                composer5.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
                Updater.m٤٤٩٥setimpl(composer5, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i10 = (i7 >> 6) & 14;
                Composer composer7 = composer2;
                ComposerKt.sourceInformationMarkerStart(composer7, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                int i11 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -1147204856, "C652@35561L324:BrowserScreen.kt#2thlc2");
                TextKt.m٣٥٠٢Text4IGK_g("No active logs. Navigate to blsspainglobal/blsspainmorocco/Portugal sites to trigger automation.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, TextAlign.m٧٨٠٤boximpl(TextAlign.INSTANCE.m٧٨١١getCentere0LSkKk()), 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 3462, 0, 130546);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                $composer.endReplaceGroup();
                composer = $composer;
            } else {
                $composer.startReplaceGroup(-791432197);
                ComposerKt.sourceInformation($composer, "662@36078L460,660@35986L552");
                Modifier modifierFillMaxSize$default2 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                ComposerKt.sourceInformationMarkerStart($composer, 2052684450, "CC(remember):BrowserScreen.kt#9igjgp");
                Object objRememberedValue2 = $composer.rememberedValue();
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return BrowserScreenKt.BrowserScreen$lambda$66$lambda$65$lambda$64$lambda$63$lambda$62($consoleLogs, (LazyListScope) obj2);
                        }
                    };
                    $composer.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue2;
                }
                ComposerKt.sourceInformationMarkerEnd($composer);
                LazyDslKt.LazyColumn(modifierFillMaxSize$default2, null, null, false, null, null, null, false, (Function1) obj, $composer, 100663302, 254);
                composer = $composer;
                composer.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: BrowserScreen$lambda$66$lambda$65$lambda$64$lambda$59$lambda$58$lambda$57, reason: contains not printable characters */
    static final Unit m٨٣٥٣x6ffd2bd0(SnapshotStateList $consoleLogs) {
        $consoleLogs.clear();
        return Unit.INSTANCE;
    }

    static final Unit BrowserScreen$lambda$66$lambda$65$lambda$64$lambda$63$lambda$62(SnapshotStateList $consoleLogs, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        final SnapshotStateList snapshotStateList = $consoleLogs;
        final Function1 function1 = new Function1() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$lambda$66$lambda$65$lambda$64$lambda$63$lambda$62$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                return invoke((String) p1);
            }

            @Override // kotlin.jvm.functions.Function1
            public final Void invoke(String str) {
                return null;
            }
        };
        LazyColumn.items(snapshotStateList.size(), null, new Function1<Integer, Object>() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$lambda$66$lambda$65$lambda$64$lambda$63$lambda$62$$inlined$items$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int index) {
                return function1.invoke(snapshotStateList.get(index));
            }
        }, ComposableLambdaKt.composableLambdaInstance(-632812321, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.example.ui.screens.BrowserScreenKt$BrowserScreen$lambda$66$lambda$65$lambda$64$lambda$63$lambda$62$$inlined$items$default$4
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(4);
            }

            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(LazyItemScope $this$items, int it, Composer $composer, int $changed) {
                ComposerKt.sourceInformation($composer, "C152@7074L22:LazyDsl.kt#428nma");
                int $dirty = $changed;
                if (($changed & 6) == 0) {
                    $dirty |= $composer.changed($this$items) ? 4 : 2;
                }
                if (($changed & 48) == 0) {
                    $dirty |= $composer.changed(it) ? 32 : 16;
                }
                if (($dirty & 147) == 146 && $composer.getSkipping()) {
                    $composer.skipToGroupEnd();
                    return;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-632812321, $dirty, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:152)");
                }
                String str = (String) snapshotStateList.get(it);
                $composer.startReplaceGroup(-728319640);
                ComposerKt.sourceInformation($composer, "C*664@36160L330:BrowserScreen.kt#2thlc2");
                TextKt.m٣٥٠٢Text4IGK_g(str, PaddingKt.m١١٩٨paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, CDp.m٧٩٥٨constructorimpl(2), 1, null), ColorKt.getTextPrimaryDark(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) FontFamily.INSTANCE.getMonospace(), 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, ((($dirty & 14) >> 3) & 14) | 3504, 0, 130992);
                $composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
        }));
        return Unit.INSTANCE;
    }

    public static final void injectLivenessExtension(WebView webView, String shimJs, String wafJs, String contentJs) {
        Intrinsics.checkNotNullParameter(shimJs, "shimJs");
        Intrinsics.checkNotNullParameter(wafJs, "wafJs");
        Intrinsics.checkNotNullParameter(contentJs, "contentJs");
        if (webView == null) {
            return;
        }
        if (shimJs.length() == 0) {
            if (contentJs.length() == 0) {
                return;
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("(function(){\n");
        sb.append("  if (window.__blsExtRan) { return; }\n");
        sb.append("  window.__blsExtRan = true;\n");
        sb.append("  function _log(t){ try { AndroidBridge.logFromJS(t); } catch(e){} }\n");
        sb.append("  try {\n").append(shimJs).append("\n  } catch(e){ _log('shim error: '+e.message); }\n");
        sb.append("  try {\n").append(wafJs).append("\n  } catch(e){ _log('waf error: '+e.message); }\n");
        sb.append("  try {\n").append(contentJs).append("\n  } catch(e){ _log('content error: '+e.message); }\n");
        sb.append("})();");
        String combined = sb.toString();
        webView.evaluateJavascript(combined, null);
    }

    public static final void registerCodeToMonitor(String url, TransactionViewModel viewModel, Context context) {
        Intrinsics.checkNotNullParameter(url, "url");
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(context, "context");
        String decodedUrl = url;
        try {
            if (StringsKt.contains$default((CharSequence) url, (CharSequence) "%", false, 2, (Object) null)) {
                for (int i = 0; i < 3; i++) {
                    try {
                        if (!StringsKt.contains$default((CharSequence) decodedUrl, (CharSequence) "%", false, 2, (Object) null)) {
                            break;
                        }
                        String strDecode = URLDecoder.decode(decodedUrl, "UTF-8");
                        Intrinsics.checkNotNullExpressionValue(strDecode, "decode(...)");
                        decodedUrl = strDecode;
                    } catch (Exception e) {
                    }
                }
            }
            if (StringsKt.contains$default((CharSequence) decodedUrl, (CharSequence) "code=", false, 2, (Object) null)) {
                TransactionViewModel.ParseResult parseResult = viewModel.parseInputText(decodedUrl);
                DebugLog.INSTANCE.add("DECODE", "success=" + parseResult.getSuccess() + " sess=" + parseResult.getSess() + " token=" + DebugLog.INSTANCE.maskToken(parseResult.getToken()) + " msg=" + parseResult.getMessage());
                if (parseResult.getSuccess()) {
                    if (parseResult.getSess().length() > 0) {
                        if (parseResult.getToken().length() > 0) {
                            viewModel.addTransaction(parseResult.getSess(), parseResult.getToken(), true);
                            Toast.makeText(context, "📱 Code registered for monitoring\nSess: " + parseResult.getSess(), 0).show();
                        }
                    }
                }
            }
        } catch (Exception e2) {
            DebugLog.INSTANCE.add("DECODE", "error: " + e2.getMessage());
        }
    }
}
