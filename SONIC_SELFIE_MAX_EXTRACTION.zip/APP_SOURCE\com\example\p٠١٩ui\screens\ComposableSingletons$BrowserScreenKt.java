package com.example.p٠١٩ui.screens;

import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.ArrowBackKt;
import androidx.compose.material.icons.filled.ArrowForwardKt;
import androidx.compose.material3.IconKt;
import androidx.compose.p٠١٤ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: BrowserScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class ComposableSingletons$BrowserScreenKt {
    public static final ComposableSingletons$BrowserScreenKt INSTANCE = new ComposableSingletons$BrowserScreenKt();

    /* JADX INFO: renamed from: lambda$-1024999489, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f٩٤٥lambda$1024999489 = ComposableLambdaKt.composableLambdaInstance(-1024999489, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$BrowserScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$BrowserScreenKt.lambda__1024999489$lambda$0((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$586216438 = ComposableLambdaKt.composableLambdaInstance(586216438, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$BrowserScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$BrowserScreenKt.lambda_586216438$lambda$1((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$2049854455 = ComposableLambdaKt.composableLambdaInstance(2049854455, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$BrowserScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$BrowserScreenKt.lambda_2049854455$lambda$2((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: getLambda$-1024999489$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m٨٣٥٤getLambda$1024999489$app() {
        return f٩٤٥lambda$1024999489;
    }

    public final Function2<Composer, Integer, Unit> getLambda$2049854455$app() {
        return lambda$2049854455;
    }

    public final Function2<Composer, Integer, Unit> getLambda$586216438$app() {
        return lambda$586216438;
    }

    static final Unit lambda__1024999489$lambda$0(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C141@6339L72:BrowserScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1024999489, $changed, -1, "com.example.ui.screens.ComposableSingletons$BrowserScreenKt.lambda$-1024999489.<anonymous> (BrowserScreen.kt:141)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(ArrowBackKt.getArrowBack(Icons.INSTANCE.getDefault()), "Back", (Modifier) null, 0L, $composer, 48, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_586216438$lambda$1(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C154@6966L78:BrowserScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(586216438, $changed, -1, "com.example.ui.screens.ComposableSingletons$BrowserScreenKt.lambda$586216438.<anonymous> (BrowserScreen.kt:154)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(ArrowForwardKt.getArrowForward(Icons.INSTANCE.getDefault()), "Forward", (Modifier) null, 0L, $composer, 48, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_2049854455$lambda$2(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C208@9742L155:BrowserScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2049854455, $changed, -1, "com.example.ui.screens.ComposableSingletons$BrowserScreenKt.lambda$2049854455.<anonymous> (BrowserScreen.kt:208)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(ArrowForwardKt.getArrowForward(Icons.INSTANCE.getDefault()), "Go", (Modifier) null, 0L, $composer, 48, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
