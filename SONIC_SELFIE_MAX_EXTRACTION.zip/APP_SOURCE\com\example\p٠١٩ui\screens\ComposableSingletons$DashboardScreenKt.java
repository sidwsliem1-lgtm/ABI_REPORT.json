package com.example.p٠١٩ui.screens;

import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.BugReportKt;
import androidx.compose.material.icons.filled.ContentCopyKt;
import androidx.compose.material.icons.filled.DeleteKt;
import androidx.compose.material.icons.filled.FlashOnKt;
import androidx.compose.material.icons.filled.RefreshKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.p٠١٤ui.Alignment;
import androidx.compose.p٠١٤ui.ComposedModifierKt;
import androidx.compose.p٠١٤ui.Modifier;
import androidx.compose.p٠١٤ui.graphics.Color;
import androidx.compose.p٠١٤ui.graphics.vector.ImageVector;
import androidx.compose.p٠١٤ui.layout.MeasurePolicy;
import androidx.compose.p٠١٤ui.node.ComposeUiNode;
import androidx.compose.p٠١٤ui.text.TextLayoutResult;
import androidx.compose.p٠١٤ui.text.TextStyle;
import androidx.compose.p٠١٤ui.text.font.FontFamily;
import androidx.compose.p٠١٤ui.text.font.FontStyle;
import androidx.compose.p٠١٤ui.text.font.FontWeight;
import androidx.compose.p٠١٤ui.text.style.TextAlign;
import androidx.compose.p٠١٤ui.text.style.TextDecoration;
import androidx.compose.p٠١٤ui.unit.CDp;
import androidx.compose.p٠١٤ui.unit.TextUnitKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import com.example.p٠١٩ui.theme.ColorKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: DashboardScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class ComposableSingletons$DashboardScreenKt {
    public static final ComposableSingletons$DashboardScreenKt INSTANCE = new ComposableSingletons$DashboardScreenKt();

    /* JADX INFO: renamed from: lambda$-1476661252, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f٩٤٧lambda$1476661252 = ComposableLambdaKt.composableLambdaInstance(-1476661252, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$DashboardScreenKt.lambda__1476661252$lambda$1((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1594852494 = ComposableLambdaKt.composableLambdaInstance(1594852494, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$DashboardScreenKt.lambda_1594852494$lambda$2((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1531851709 = ComposableLambdaKt.composableLambdaInstance(1531851709, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$DashboardScreenKt.lambda_1531851709$lambda$3((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-1993344262, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f٩٤٨lambda$1993344262 = ComposableLambdaKt.composableLambdaInstance(-1993344262, false, new Function3() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$DashboardScreenKt.lambda__1993344262$lambda$4((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-1263673359, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f٩٤٦lambda$1263673359 = ComposableLambdaKt.composableLambdaInstance(-1263673359, false, new Function3() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$DashboardScreenKt.lambda__1263673359$lambda$5((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$827856178 = ComposableLambdaKt.composableLambdaInstance(827856178, false, new Function3() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$DashboardScreenKt.lambda_827856178$lambda$6((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-980212778, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f٩٥٠lambda$980212778 = ComposableLambdaKt.composableLambdaInstance(-980212778, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$DashboardScreenKt.lambda__980212778$lambda$7((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$1798087516 = ComposableLambdaKt.composableLambdaInstance(1798087516, false, new Function3() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda7
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$DashboardScreenKt.lambda_1798087516$lambda$8((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-290641549, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f٩٤٩lambda$290641549 = ComposableLambdaKt.composableLambdaInstance(-290641549, false, new Function2() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda8
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$DashboardScreenKt.lambda__290641549$lambda$9((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$1899194514 = ComposableLambdaKt.composableLambdaInstance(1899194514, false, new Function3() { // from class: com.example.ui.screens.ComposableSingletons$DashboardScreenKt$$ExternalSyntheticLambda9
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$DashboardScreenKt.lambda_1899194514$lambda$10((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: getLambda$-1263673359$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m٨٣٥٥getLambda$1263673359$app() {
        return f٩٤٦lambda$1263673359;
    }

    /* JADX INFO: renamed from: getLambda$-1476661252$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m٨٣٥٦getLambda$1476661252$app() {
        return f٩٤٧lambda$1476661252;
    }

    /* JADX INFO: renamed from: getLambda$-1993344262$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m٨٣٥٧getLambda$1993344262$app() {
        return f٩٤٨lambda$1993344262;
    }

    /* JADX INFO: renamed from: getLambda$-290641549$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m٨٣٥٨getLambda$290641549$app() {
        return f٩٤٩lambda$290641549;
    }

    /* JADX INFO: renamed from: getLambda$-980212778$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m٨٣٥٩getLambda$980212778$app() {
        return f٩٥٠lambda$980212778;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1531851709$app() {
        return lambda$1531851709;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1594852494$app() {
        return lambda$1594852494;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$1798087516$app() {
        return lambda$1798087516;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$1899194514$app() {
        return lambda$1899194514;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$827856178$app() {
        return lambda$827856178;
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0217  */
    static final Unit lambda__1476661252$lambda$1(Composer $composer, int $changed) {
        int i;
        ComposerKt.sourceInformation($composer, "C81@3420L888:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1476661252, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$-1476661252.<anonymous> (DashboardScreen.kt:81)");
            }
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i2 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composer = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer.getInserting()) {
                i = 384;
            } else {
                i = 384;
                if (!Intrinsics.areEqual(composer.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                }
                Updater.m٤٤٩٥setimpl(composer, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i3 = (i2 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i4 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, 1030723743, "C82@3502L281,88@3812L39,91@4001L10,89@3880L402:DashboardScreen.kt#2thlc2");
                IconKt.m٢٩٣٤Iconww6aTOc(FlashOnKt.getFlashOn(Icons.INSTANCE.getDefault()), "Logo", SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(24)), ColorKt.getGoldPrimary(), $composer, 3504, 0);
                SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), $composer, 6);
                TextKt.m٣٥٠٢Text4IGK_g("BIOMETRIC LIVENESS", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, TextStyle.m٧٤٠٥copyp1EtxEg$default(MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), ColorKt.getGoldPrimary(), 0L, FontWeight.INSTANCE.getBlack(), null, null, null, null, TextUnitKt.getSp(1.5d), null, null, null, 0L, null, null, null, 0, 0, 0L, null, null, null, 0, 0, null, 16777082, null), $composer, 6, 0, 65534);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composer.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composer.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            Updater.m٤٤٩٥setimpl(composer, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i2 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
            int i6 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1030723743, "C82@3502L281,88@3812L39,91@4001L10,89@3880L402:DashboardScreen.kt#2thlc2");
            IconKt.m٢٩٣٤Iconww6aTOc(FlashOnKt.getFlashOn(Icons.INSTANCE.getDefault()), "Logo", SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(24)), ColorKt.getGoldPrimary(), $composer, 3504, 0);
            SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), $composer, 6);
            TextKt.m٣٥٠٢Text4IGK_g("BIOMETRIC LIVENESS", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, TextStyle.m٧٤٠٥copyp1EtxEg$default(MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), ColorKt.getGoldPrimary(), 0L, FontWeight.INSTANCE.getBlack(), null, null, null, null, TextUnitKt.getSp(1.5d), null, null, null, 0L, null, null, null, 0, 0, 0L, null, null, null, 0, 0, null, 16777082, null), $composer, 6, 0, 65534);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1594852494$lambda$2(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C105@4668L223:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1594852494, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$1594852494.<anonymous> (DashboardScreen.kt:105)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(BugReportKt.getBugReport(Icons.INSTANCE.getDefault()), "Debug log", (Modifier) null, ColorKt.getGoldPrimary(), $composer, 3120, 4);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1531851709$lambda$3(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C157@6784L40:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1531851709, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$1531851709.<anonymous> (DashboardScreen.kt:157)");
            }
            TextKt.m٣٥٠٢Text4IGK_g("12345", (Modifier) null, ColorKt.getTextSecondaryDark(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 390, 0, 131066);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1993344262$lambda$4(RowScope TextButton, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation($composer, "C259@11376L63:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1993344262, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$-1993344262.<anonymous> (DashboardScreen.kt:259)");
            }
            TextKt.m٣٥٠٢Text4IGK_g("Copy", (Modifier) null, ColorKt.getGoldPrimary(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 196998, 0, 131034);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1263673359$lambda$5(RowScope TextButton, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation($composer, "C262@11563L63:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1263673359, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$-1263673359.<anonymous> (DashboardScreen.kt:262)");
            }
            TextKt.m٣٥٠٢Text4IGK_g("Clear", (Modifier) null, ColorKt.getStateError(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 196998, 0, 131034);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_827856178$lambda$6(RowScope TextButton, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation($composer, "C265@11739L70:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(827856178, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$827856178.<anonymous> (DashboardScreen.kt:265)");
            }
            TextKt.m٣٥٠٢Text4IGK_g("Close", (Modifier) null, ColorKt.getTextSecondaryDark(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 196998, 0, 131034);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__980212778$lambda$7(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C375@15999L296:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-980212778, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$-980212778.<anonymous> (DashboardScreen.kt:375)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(ContentCopyKt.getContentCopy(Icons.INSTANCE.getDefault()), "Copy Sess", SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(12)), ColorKt.getTextSecondaryDark(), $composer, 3504, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1798087516$lambda$8(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C473@20598L231,478@20858L39,479@20926L63:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1798087516, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$1798087516.<anonymous> (DashboardScreen.kt:473)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(ContentCopyKt.getContentCopy(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(12)), 0L, $composer, 432, 8);
            SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(4)), $composer, 6);
            TextKt.m٣٥٠٢Text4IGK_g("Copy ID", (Modifier) null, 0L, TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199686, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__290641549$lambda$9(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C554@24128L203:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-290641549, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$-290641549.<anonymous> (DashboardScreen.kt:554)");
            }
            ImageVector delete = DeleteKt.getDelete(Icons.INSTANCE.getDefault());
            long stateError = ColorKt.getStateError();
            IconKt.m٢٩٣٤Iconww6aTOc(delete, "Delete", (Modifier) null, Color.m٥٠٦٧copywmQWz5c(stateError, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateError) : 0.8f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateError) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateError) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateError) : 0.0f), $composer, 3120, 4);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1899194514$lambda$10(RowScope TextButton, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
        ComposerKt.sourceInformation($composer, "C573@25034L101,574@25164L39,575@25232L61:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1899194514, $changed, -1, "com.example.ui.screens.ComposableSingletons$DashboardScreenKt.lambda$1899194514.<anonymous> (DashboardScreen.kt:573)");
            }
            IconKt.m٢٩٣٤Iconww6aTOc(RefreshKt.getRefresh(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16)), 0L, $composer, 432, 8);
            SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(4)), $composer, 6);
            TextKt.m٣٥٠٢Text4IGK_g("Check", (Modifier) null, 0L, TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199686, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
