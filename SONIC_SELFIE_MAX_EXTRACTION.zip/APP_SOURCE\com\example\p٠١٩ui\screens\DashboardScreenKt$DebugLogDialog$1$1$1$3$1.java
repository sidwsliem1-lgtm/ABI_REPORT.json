package com.example.p٠١٩ui.screens;

import androidx.compose.foundation.lazy.LazyListState;
import androidx.compose.runtime.State;
import java.util.List;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: DashboardScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
@DebugMetadata(m١٠٠٢٥c = "com.example.ui.screens.DashboardScreenKt$DebugLogDialog$1$1$1$3$1", m١٠٠٢٦f = "DashboardScreen.kt", m١٠٠٢٧i = {}, m١٠٠٢٨l = {280}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {}, m١٠٠٣١s = {})
final class DashboardScreenKt$DebugLogDialog$1$1$1$3$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ State<List<String>> $lines$delegate;
    final /* synthetic */ LazyListState $listState;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    DashboardScreenKt$DebugLogDialog$1$1$1$3$1(LazyListState lazyListState, State<? extends List<String>> state, Continuation<? super DashboardScreenKt$DebugLogDialog$1$1$1$3$1> continuation) {
        super(2, continuation);
        this.$listState = lazyListState;
        this.$lines$delegate = state;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(this.$listState, this.$lines$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((DashboardScreenKt$DebugLogDialog$1$1$1$3$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                if (!DashboardScreenKt.DebugLogDialog$lambda$60(this.$lines$delegate).isEmpty()) {
                    this.label = 1;
                    if (LazyListState.animateScrollToItem$default(this.$listState, DashboardScreenKt.DebugLogDialog$lambda$60(this.$lines$delegate).size() - 1, 0, this, 2, null) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                }
                break;
            case 1:
                ResultKt.throwOnFailure($result);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }
}
