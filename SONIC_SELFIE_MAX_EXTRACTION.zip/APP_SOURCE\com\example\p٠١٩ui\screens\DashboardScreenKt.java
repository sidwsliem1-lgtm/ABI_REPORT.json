package com.example.p٠١٩ui.screens;

import android.content.Context;
import android.graphics.Matrix;
import android.widget.Toast;
import androidx.activity.compose.BackHandlerKt;
import androidx.compose.animation.AnimatedVisibilityKt;
import androidx.compose.animation.AnimatedVisibilityScope;
import androidx.compose.animation.EnterExitTransitionKt;
import androidx.compose.animation.core.AnimationSpecKt;
import androidx.compose.animation.core.EasingKt;
import androidx.compose.animation.core.InfiniteRepeatableSpec;
import androidx.compose.animation.core.InfiniteTransition;
import androidx.compose.animation.core.InfiniteTransitionKt;
import androidx.compose.animation.core.RepeatMode;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.foundation.BorderStrokeKt;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.lazy.LazyDslKt;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.foundation.lazy.LazyListScope;
import androidx.compose.foundation.lazy.LazyListState;
import androidx.compose.foundation.lazy.LazyListStateKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.CheckCircleKt;
import androidx.compose.material.icons.filled.FingerprintKt;
import androidx.compose.material.icons.filled.SendKt;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardColors;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.DividerKt;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.OutlinedTextFieldDefaults;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.SurfaceKt;
import androidx.compose.material3.SwitchColors;
import androidx.compose.material3.SwitchDefaults;
import androidx.compose.material3.SwitchKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.p٠١٤ui.Alignment;
import androidx.compose.p٠١٤ui.ComposedModifierKt;
import androidx.compose.p٠١٤ui.Modifier;
import androidx.compose.p٠١٤ui.draw.ClipKt;
import androidx.compose.p٠١٤ui.graphics.Color;
import androidx.compose.p٠١٤ui.graphics.Shape;
import androidx.compose.p٠١٤ui.layout.MeasurePolicy;
import androidx.compose.p٠١٤ui.node.ComposeUiNode;
import androidx.compose.p٠١٤ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.p٠١٤ui.platform.ClipboardManager;
import androidx.compose.p٠١٤ui.platform.CompositionLocalsKt;
import androidx.compose.p٠١٤ui.platform.TestTagKt;
import androidx.compose.p٠١٤ui.text.AnnotatedString;
import androidx.compose.p٠١٤ui.text.TextLayoutResult;
import androidx.compose.p٠١٤ui.text.TextStyle;
import androidx.compose.p٠١٤ui.text.font.FontFamily;
import androidx.compose.p٠١٤ui.text.font.FontStyle;
import androidx.compose.p٠١٤ui.text.font.FontWeight;
import androidx.compose.p٠١٤ui.text.input.KeyboardType;
import androidx.compose.p٠١٤ui.text.input.PlatformImeOptions;
import androidx.compose.p٠١٤ui.text.input.VisualTransformation;
import androidx.compose.p٠١٤ui.text.intl.LocaleList;
import androidx.compose.p٠١٤ui.text.style.TextAlign;
import androidx.compose.p٠١٤ui.text.style.TextDecoration;
import androidx.compose.p٠١٤ui.text.style.TextOverflow;
import androidx.compose.p٠١٤ui.unit.CDp;
import androidx.compose.p٠١٤ui.unit.TextUnitKt;
import androidx.compose.p٠١٤ui.window.AndroidDialog_androidKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.compose.FlowExtKt;
import androidx.profileinstaller.ProfileVerifier;
import com.example.data.model.Transaction;
import com.example.p٠١٩ui.theme.ColorKt;
import com.example.p٠١٩ui.viewmodel.TransactionViewModel;
import com.example.util.DebugLog;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: DashboardScreen.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000R\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\r\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\u001a\u001b\u0010\u0007\u001a\u00020\u00012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\tH\u0003¢\u0006\u0002\u0010\n\u001aa\u0010\u000b\u001a\u00020\u00012\u0006\u0010\f\u001a\u00020\r2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00010\t2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00010\t2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00010\t2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00010\t2\u0012\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u00010\u0013H\u0007¢\u0006\u0002\u0010\u0015\u001a\u0014\u0010\u0016\u001a\u00020\u0005*\u00020\u00052\u0006\u0010\u0016\u001a\u00020\u0017H\u0002¨\u0006\u0018²\u0006\u0010\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\r0\u001aX\u008a\u0084\u0002²\u0006\n\u0010\u001b\u001a\u00020\u0014X\u008a\u0084\u0002²\u0006\n\u0010\u001c\u001a\u00020\u001dX\u008a\u0084\u0002²\u0006\n\u0010\u001e\u001a\u00020\u0014X\u008a\u008e\u0002²\u0006\n\u0010\u001f\u001a\u00020 X\u008a\u008e\u0002²\u0006\n\u0010!\u001a\u00020\u0014X\u008a\u008e\u0002²\u0006\n\u0010\"\u001a\u00020\u0014X\u008a\u008e\u0002²\u0006\n\u0010#\u001a\u00020\u0014X\u008a\u008e\u0002²\u0006\n\u0010$\u001a\u00020 X\u008a\u008e\u0002²\u0006\n\u0010%\u001a\u00020\u0014X\u008a\u008e\u0002²\u0006\f\u0010&\u001a\u0004\u0018\u00010 X\u008a\u008e\u0002²\u0006\n\u0010'\u001a\u00020 X\u008a\u008e\u0002²\u0006\n\u0010(\u001a\u00020 X\u008a\u008e\u0002²\u0006\n\u0010)\u001a\u00020\u0014X\u008a\u008e\u0002²\u0006\n\u0010*\u001a\u00020\u0014X\u008a\u008e\u0002²\u0006\n\u0010+\u001a\u00020 X\u008a\u008e\u0002²\u0006\u0010\u0010,\u001a\b\u0012\u0004\u0012\u00020\u00140\u001aX\u008a\u0084\u0002²\u0006\n\u0010-\u001a\u00020 X\u008a\u008e\u0002²\u0006\n\u0010\u0016\u001a\u00020\u0017X\u008a\u0084\u0002"}, m٨٧٩٩d2 = {"DashboardScreen", "", "viewModel", "Lcom/example/ui/viewmodel/TransactionViewModel;", "modifier", "Landroidx/compose/ui/Modifier;", "(Lcom/example/ui/viewmodel/TransactionViewModel;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "DebugLogDialog", "onDismiss", "Lkotlin/Function0;", "(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "TransactionItem", "transaction", "Lcom/example/data/model/Transaction;", "onCheckSingle", "onToggleAutoPoll", "onDelete", "onCopySess", "onCopyCr", "Lkotlin/Function1;", "", "(Lcom/example/data/model/Transaction;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V", "scale", "", "app", "transactions", "", "endpointUrl", "pollingInterval", "", "syncCodeInput", "isResolvingSyncCode", "", "inputText", "parsedSession", "parsedToken", "isAutoPollOnAdd", "parseMessage", "isParseSuccess", "showSettingsDialog", "showDebugDialog", "settingUrlInput", "settingIntervalInput", "showSelfie", "lines", "expanded"}, m٨٨٠٠k = 2, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class DashboardScreenKt {
    static final Unit DashboardScreen$lambda$59(TransactionViewModel transactionViewModel, Modifier modifier, int i, int i2, Composer composer, int i3) {
        DashboardScreen(transactionViewModel, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit DebugLogDialog$lambda$75(Function0 function0, int i, Composer composer, int i2) {
        DebugLogDialog(function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit TransactionItem$lambda$103(Transaction transaction, Function0 function0, Function0 function1, Function0 function2, Function0 function3, Function1 function4, int i, Composer composer, int i2) {
        TransactionItem(transaction, function0, function1, function2, function3, function4, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void DashboardScreen(TransactionViewModel viewModel, Modifier modifier, Composer $composer, final int $changed, final int i) {
        final Modifier modifier2;
        Modifier modifier3;
        Object objMutableStateOf$default;
        Object objMutableStateOf$default2;
        Object objMutableStateOf$default3;
        Object objMutableStateOf$default4;
        Object objMutableStateOf$default5;
        boolean z;
        Object objMutableStateOf$default6;
        Object objMutableStateOf$default7;
        Object objMutableStateOf$default8;
        Object objMutableStateOf$default9;
        Object objMutableStateOf$default10;
        Object objMutableStateOf$default11;
        Object objMutableStateOf$default12;
        Object objMutableStateOf$default13;
        Object obj;
        final TransactionViewModel viewModel2 = viewModel;
        Intrinsics.checkNotNullParameter(viewModel2, "viewModel");
        Composer $composer2 = $composer.startRestartGroup(-350054047);
        ComposerKt.sourceInformation($composer2, "C(DashboardScreen)P(1)50@2012L29,51@2087L29,52@2177L29,54@2239L7,56@2273L31,57@2336L34,58@2392L31,59@2449L31,60@2504L31,61@2563L33,62@2621L31,63@2679L43,65@2754L34,66@2816L34,69@2902L40,70@2975L55,73@3149L34,76@3216L1765,117@5056L4464,75@3189L6331:DashboardScreen.kt#2thlc2");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changedInstance(viewModel2) ? 4 : 2;
        }
        int i2 = i & 2;
        if (i2 != 0) {
            $dirty |= 48;
            modifier2 = modifier;
        } else if (($changed & 48) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 32 : 16;
        } else {
            modifier2 = modifier;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 19) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            if (i2 != 0) {
                modifier3 = Modifier.INSTANCE;
            } else {
                modifier3 = modifier2;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-350054047, $dirty2, -1, "com.example.ui.screens.DashboardScreen (DashboardScreen.kt:49)");
            }
            FlowExtKt.collectAsStateWithLifecycle(viewModel2.getTransactions(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            State endpointUrl$delegate = FlowExtKt.collectAsStateWithLifecycle(viewModel2.getEndpointUrl(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            State pollingInterval$delegate = FlowExtKt.collectAsStateWithLifecycle(viewModel2.getPollingIntervalSeconds(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer2, 0, 7);
            ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localContext);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            final Context context = (Context) objConsume;
            ComposerKt.sourceInformationMarkerStart($composer2, -1394475456, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue = $composer2.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default);
            } else {
                objMutableStateOf$default = objRememberedValue;
            }
            final MutableState syncCodeInput$delegate = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394473437, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer2.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default2);
            } else {
                objMutableStateOf$default2 = objRememberedValue2;
            }
            final MutableState isResolvingSyncCode$delegate = (MutableState) objMutableStateOf$default2;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394471648, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue3 = $composer2.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default3 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default3);
            } else {
                objMutableStateOf$default3 = objRememberedValue3;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394469824, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue4 = $composer2.rememberedValue();
            if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default4 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default4);
            } else {
                objMutableStateOf$default4 = objRememberedValue4;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394468064, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue5 = $composer2.rememberedValue();
            if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default5 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default5);
            } else {
                objMutableStateOf$default5 = objRememberedValue5;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394466174, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue6 = $composer2.rememberedValue();
            if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                z = true;
                objMutableStateOf$default6 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(true, null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default6);
            } else {
                z = true;
                objMutableStateOf$default6 = objRememberedValue6;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394464320, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue7 = $composer2.rememberedValue();
            if (objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default7 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default7);
            } else {
                objMutableStateOf$default7 = objRememberedValue7;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394462452, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue8 = $composer2.rememberedValue();
            if (objRememberedValue8 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default8 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default8);
            } else {
                objMutableStateOf$default8 = objRememberedValue8;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394460061, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue9 = $composer2.rememberedValue();
            if (objRememberedValue9 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default9 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default9);
            } else {
                objMutableStateOf$default9 = objRememberedValue9;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394458077, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue10 = $composer2.rememberedValue();
            if (objRememberedValue10 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default10 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default10);
            } else {
                objMutableStateOf$default10 = objRememberedValue10;
            }
            final MutableState showDebugDialog$delegate = (MutableState) objMutableStateOf$default10;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394455319, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue11 = $composer2.rememberedValue();
            if (objRememberedValue11 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default11 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(DashboardScreen$lambda$1(endpointUrl$delegate), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default11);
            } else {
                objMutableStateOf$default11 = objRememberedValue11;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394452968, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue12 = $composer2.rememberedValue();
            if (objRememberedValue12 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default12 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(String.valueOf(DashboardScreen$lambda$2(pollingInterval$delegate)), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default12);
            } else {
                objMutableStateOf$default12 = objRememberedValue12;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1394447421, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue13 = $composer2.rememberedValue();
            if (objRememberedValue13 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default13 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default13);
            } else {
                objMutableStateOf$default13 = objRememberedValue13;
            }
            final MutableState showSelfie$delegate = (MutableState) objMutableStateOf$default13;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            boolean z2 = z;
            viewModel2 = viewModel;
            Modifier modifier4 = modifier3;
            ScaffoldKt.m٣٢٠١ScaffoldTvnljyQ(modifier4, ComposableLambdaKt.rememberComposableLambda(-713950683, z2, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return DashboardScreenKt.DashboardScreen$lambda$45(showSelfie$delegate, showDebugDialog$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer2, 54), null, null, null, 0, ColorKt.getObsidianDark(), 0L, null, ComposableLambdaKt.rememberComposableLambda(-949171728, z2, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return DashboardScreenKt.DashboardScreen$lambda$56(viewModel2, showSelfie$delegate, context, syncCodeInput$delegate, isResolvingSyncCode$delegate, (PaddingValues) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, $composer2, 54), $composer2, (($dirty2 >> 3) & 14) | 806879280, 444);
            $composer2 = $composer2;
            if (DashboardScreen$lambda$31(showDebugDialog$delegate)) {
                $composer2.startReplaceGroup(-271849126);
                ComposerKt.sourceInformation($composer2, "216@9584L27,216@9557L55");
                ComposerKt.sourceInformationMarkerStart($composer2, -1394241508, "CC(remember):DashboardScreen.kt#9igjgp");
                Object objRememberedValue14 = $composer2.rememberedValue();
                if (objRememberedValue14 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return DashboardScreenKt.DashboardScreen$lambda$58$lambda$57(showDebugDialog$delegate);
                        }
                    };
                    $composer2.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue14;
                }
                ComposerKt.sourceInformationMarkerEnd($composer2);
                DebugLogDialog((Function0) obj, $composer2, 6);
            } else {
                $composer2.startReplaceGroup(-281322943);
            }
            $composer2.endReplaceGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier2 = modifier4;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return DashboardScreenKt.DashboardScreen$lambda$59(viewModel2, modifier2, $changed, i, (Composer) obj2, ((Integer) obj3).intValue());
                }
            });
        }
    }

    private static final List<Transaction> DashboardScreen$lambda$0(State<? extends List<Transaction>> state) {
        return (List) state.getValue();
    }

    private static final String DashboardScreen$lambda$1(State<String> state) {
        return (String) state.getValue();
    }

    private static final int DashboardScreen$lambda$2(State<Integer> state) {
        return ((Number) state.getValue()).intValue();
    }

    private static final String DashboardScreen$lambda$4(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    private static final boolean DashboardScreen$lambda$7(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void DashboardScreen$lambda$8(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final boolean DashboardScreen$lambda$31(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void DashboardScreen$lambda$32(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final boolean DashboardScreen$lambda$40(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void DashboardScreen$lambda$41(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    static final Unit DashboardScreen$lambda$45(MutableState $showSelfie$delegate, final MutableState $showDebugDialog$delegate, Composer $composer, int $changed) {
        Composer composer = $composer;
        ComposerKt.sourceInformation(composer, "C:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-713950683, $changed, -1, "com.example.ui.screens.DashboardScreen.<anonymous> (DashboardScreen.kt:78)");
            }
            if (DashboardScreen$lambda$40($showSelfie$delegate)) {
                composer.startReplaceGroup(-629938723);
            } else {
                composer.startReplaceGroup(-626576773);
                ComposerKt.sourceInformation(composer, "99@4379L152,103@4563L376,79@3355L1602");
                composer = $composer;
                AppBarKt.m٢٥٢٥TopAppBarGHTll3U(ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٦getLambda$1476661252$app(), null, null, ComposableLambdaKt.rememberComposableLambda(889380401, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda19
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return DashboardScreenKt.DashboardScreen$lambda$45$lambda$44($showDebugDialog$delegate, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer, 54), 0.0f, null, TopAppBarDefaults.INSTANCE.m٣٦٨٣topAppBarColorszjMxDiM(ColorKt.getObsidianSurface(), 0L, 0L, ColorKt.getGoldPrimary(), 0L, $composer, (TopAppBarDefaults.$stable << 15) | 3078, 22), null, composer, 3078, 182);
            }
            composer.endReplaceGroup();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit DashboardScreen$lambda$45$lambda$44(final MutableState $showDebugDialog$delegate, RowScope TopAppBar, Composer $composer, int $changed) {
        Object obj;
        Intrinsics.checkNotNullParameter(TopAppBar, "$this$TopAppBar");
        ComposerKt.sourceInformation($composer, "C104@4610L26,104@4589L328:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(889380401, $changed, -1, "com.example.ui.screens.DashboardScreen.<anonymous>.<anonymous> (DashboardScreen.kt:104)");
            }
            ComposerKt.sourceInformationMarkerStart($composer, -3925013, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue = $composer.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardScreenKt.DashboardScreen$lambda$45$lambda$44$lambda$43$lambda$42($showDebugDialog$delegate);
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            IconButtonKt.IconButton((Function0) obj, null, false, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$1594852494$app(), $composer, 196614, 30);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit DashboardScreen$lambda$45$lambda$44$lambda$43$lambda$42(MutableState $showDebugDialog$delegate) {
        DashboardScreen$lambda$32($showDebugDialog$delegate, true);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:42:0x033f  */
    /* JADX WARN: Code duplicated, block: B:43:0x0351  */
    static final Unit DashboardScreen$lambda$56(final TransactionViewModel $viewModel, final MutableState $showSelfie$delegate, final Context $context, final MutableState $syncCodeInput$delegate, final MutableState $isResolvingSyncCode$delegate, PaddingValues innerPadding, Composer $composer, int $changed) {
        final MutableState mutableState;
        Object obj;
        Function0<ComposeUiNode> function0;
        int i;
        Object objRememberedValue;
        Object obj2;
        boolean zChangedInstance;
        Object obj3;
        Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        ComposerKt.sourceInformation($composer, "C119@5222L22,119@5188L56:DashboardScreen.kt#2thlc2");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer.changed(innerPadding) ? 4 : 2;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 19) == 18 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-949171728, $dirty2, -1, "com.example.ui.screens.DashboardScreen.<anonymous> (DashboardScreen.kt:119)");
            }
            boolean zDashboardScreen$lambda$40 = DashboardScreen$lambda$40($showSelfie$delegate);
            ComposerKt.sourceInformationMarkerStart($composer, -1620958522, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                mutableState = $showSelfie$delegate;
                obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda14
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardScreenKt.DashboardScreen$lambda$56$lambda$47$lambda$46(mutableState);
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                mutableState = $showSelfie$delegate;
                obj = objRememberedValue2;
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            BackHandlerKt.BackHandler(zDashboardScreen$lambda$40, (Function0) obj, $composer, 48, 0);
            if (DashboardScreen$lambda$40(mutableState)) {
                $composer.startReplaceGroup(1289949172);
                ComposerKt.sourceInformation($composer, "122@5360L217");
                BrowserScreenKt.BrowserScreen($viewModel, false, PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding), $composer, 48, 0);
                $composer.endReplaceGroup();
            } else {
                $composer.startReplaceGroup(1290382273);
                ComposerKt.sourceInformation($composer, "131@5673L3831");
                Modifier modifier = PaddingKt.m١١٩٨paddingVpY3zN4$default(PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding), CDp.m٧٩٥٨constructorimpl(28), 0.0f, 2, null);
                Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
                Arrangement.Vertical center = Arrangement.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(center, centerHorizontally, $composer, ((432 >> 3) & 14) | ((432 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
                Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i2 = ((((432 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function0 = constructor;
                    $composer.createNode(function0);
                } else {
                    function0 = constructor;
                    $composer.useNode();
                }
                Composer composer = Updater.m٤٤٨٨constructorimpl($composer);
                Updater.m٤٤٩٥setimpl(composer, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composer.getInserting()) {
                    i = currentCompositeKeyHash;
                } else {
                    i = currentCompositeKeyHash;
                    if (!Intrinsics.areEqual(composer.rememberedValue(), Integer.valueOf(i))) {
                    }
                    Updater.m٤٤٩٥setimpl(composer, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                    int i3 = (i2 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                    ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                    int i4 = ((432 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart($composer, 905886157, "C139@6002L223,145@6242L30,146@6289L172,151@6478L30,160@7021L403,154@6623L123,152@6525L973,170@7515L30,189@8507L139,172@7600L809,198@8889L601,171@7562L1928:DashboardScreen.kt#2thlc2");
                    IconKt.m٢٩٣٤Iconww6aTOc(FingerprintKt.getFingerprint(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(72)), ColorKt.getGoldPrimary(), $composer, 3504, 0);
                    SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(18)), $composer, 6);
                    TextKt.m٣٥٠٢Text4IGK_g("Enter the 5-digit SYNC CODE and go", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(14), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3462, 0, 131058);
                    SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(26)), $composer, 6);
                    String strDashboardScreen$lambda$4 = DashboardScreen$lambda$4($syncCodeInput$delegate);
                    KeyboardOptions keyboardOptions = new KeyboardOptions(0, (Boolean) null, KeyboardType.INSTANCE.m٧٦٣٩getNumberPasswordPjHm6EE(), 0, (PlatformImeOptions) null, (Boolean) null, (LocaleList) null, 123, (DefaultConstructorMarker) null);
                    TextFieldColors textFieldColors = OutlinedTextFieldDefaults.INSTANCE.m٣١٣٣colors0hiis_0(ColorKt.getTextPrimaryDark(), ColorKt.getTextPrimaryDark(), 0L, 0L, ColorKt.getObsidianSurface(), ColorKt.getObsidianSurface(), 0L, 0L, 0L, 0L, null, ColorKt.getGoldPrimary(), ColorKt.getObsidianBorder(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 221238, 432, 0, 0, 3072, 2147477452, 4095);
                    Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                    ComposerKt.sourceInformationMarkerStart($composer, 29238641, "CC(remember):DashboardScreen.kt#9igjgp");
                    objRememberedValue = $composer.rememberedValue();
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj4) {
                                return DashboardScreenKt.DashboardScreen$lambda$56$lambda$55$lambda$50$lambda$49($syncCodeInput$delegate, (String) obj4);
                            }
                        };
                        $composer.updateRememberedValue(obj2);
                    } else {
                        obj2 = objRememberedValue;
                    }
                    ComposerKt.sourceInformationMarkerEnd(r2);
                    OutlinedTextFieldKt.OutlinedTextField(strDashboardScreen$lambda$4, (Function1<? super String, Unit>) obj2, modifierFillMaxWidth$default, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$1531851709$app(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, keyboardOptions, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) null, textFieldColors, $composer, 12583344, 12779520, 0, 4030328);
                    SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16)), $composer, 6);
                    boolean z = !DashboardScreen$lambda$7($isResolvingSyncCode$delegate);
                    ButtonColors buttonColors = ButtonDefaults.INSTANCE.m٢٥٦٣buttonColorsro_MJ88(ColorKt.getGoldPrimary(), ColorKt.getTextOnGold(), 0L, 0L, $composer, (ButtonDefaults.$stable << 12) | 54, 12);
                    RoundedCornerShape roundedCornerShape = RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(14));
                    Modifier modifierTestTag = TestTagKt.testTag(SizeKt.m١٢٥٢height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), CDp.m٧٩٥٨constructorimpl(58)), "start_button");
                    ComposerKt.sourceInformationMarkerStart($composer, 29270591, "CC(remember):DashboardScreen.kt#9igjgp");
                    zChangedInstance = $composer.changedInstance($context) | $composer.changedInstance($viewModel);
                    Object objRememberedValue3 = $composer.rememberedValue();
                    if (!zChangedInstance || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                        obj3 = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return DashboardScreenKt.DashboardScreen$lambda$56$lambda$55$lambda$53$lambda$52($context, $viewModel, $syncCodeInput$delegate, $isResolvingSyncCode$delegate, $showSelfie$delegate);
                            }
                        };
                        $composer.updateRememberedValue(obj3);
                    } else {
                        obj3 = objRememberedValue3;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ButtonKt.Button((Function0) obj3, modifierTestTag, z, roundedCornerShape, buttonColors, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-804629338, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda17
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj4, Object obj5, Object obj6) {
                            return DashboardScreenKt.DashboardScreen$lambda$56$lambda$55$lambda$54($isResolvingSyncCode$delegate, (RowScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                        }
                    }, $composer, 54), $composer, 805306416, 480);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endReplaceGroup();
                }
                composer.updateRememberedValue(Integer.valueOf(i));
                composer.apply(Integer.valueOf(i), setCompositeKeyHash);
                Updater.m٤٤٩٥setimpl(composer, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i5 = (i2 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                int i6 = ((432 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, 905886157, "C139@6002L223,145@6242L30,146@6289L172,151@6478L30,160@7021L403,154@6623L123,152@6525L973,170@7515L30,189@8507L139,172@7600L809,198@8889L601,171@7562L1928:DashboardScreen.kt#2thlc2");
                IconKt.m٢٩٣٤Iconww6aTOc(FingerprintKt.getFingerprint(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(72)), ColorKt.getGoldPrimary(), $composer, 3504, 0);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(18)), $composer, 6);
                TextKt.m٣٥٠٢Text4IGK_g("Enter the 5-digit SYNC CODE and go", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(14), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3462, 0, 131058);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(26)), $composer, 6);
                String strDashboardScreen$lambda$5 = DashboardScreen$lambda$4($syncCodeInput$delegate);
                KeyboardOptions keyboardOptions2 = new KeyboardOptions(0, (Boolean) null, KeyboardType.INSTANCE.m٧٦٣٩getNumberPasswordPjHm6EE(), 0, (PlatformImeOptions) null, (Boolean) null, (LocaleList) null, 123, (DefaultConstructorMarker) null);
                TextFieldColors textFieldColors2 = OutlinedTextFieldDefaults.INSTANCE.m٣١٣٣colors0hiis_0(ColorKt.getTextPrimaryDark(), ColorKt.getTextPrimaryDark(), 0L, 0L, ColorKt.getObsidianSurface(), ColorKt.getObsidianSurface(), 0L, 0L, 0L, 0L, null, ColorKt.getGoldPrimary(), ColorKt.getObsidianBorder(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 221238, 432, 0, 0, 3072, 2147477452, 4095);
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                ComposerKt.sourceInformationMarkerStart($composer, 29238641, "CC(remember):DashboardScreen.kt#9igjgp");
                objRememberedValue = $composer.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda15
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj4) {
                            return DashboardScreenKt.DashboardScreen$lambda$56$lambda$55$lambda$50$lambda$49($syncCodeInput$delegate, (String) obj4);
                        }
                    };
                    $composer.updateRememberedValue(obj2);
                } else {
                    obj2 = objRememberedValue;
                }
                ComposerKt.sourceInformationMarkerEnd(r2);
                OutlinedTextFieldKt.OutlinedTextField(strDashboardScreen$lambda$5, (Function1<? super String, Unit>) obj2, modifierFillMaxWidth$default2, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$1531851709$app(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, keyboardOptions2, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) null, textFieldColors2, $composer, 12583344, 12779520, 0, 4030328);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16)), $composer, 6);
                boolean z2 = !DashboardScreen$lambda$7($isResolvingSyncCode$delegate);
                ButtonColors buttonColors2 = ButtonDefaults.INSTANCE.m٢٥٦٣buttonColorsro_MJ88(ColorKt.getGoldPrimary(), ColorKt.getTextOnGold(), 0L, 0L, $composer, (ButtonDefaults.$stable << 12) | 54, 12);
                RoundedCornerShape roundedCornerShape2 = RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(14));
                Modifier modifierTestTag2 = TestTagKt.testTag(SizeKt.m١٢٥٢height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), CDp.m٧٩٥٨constructorimpl(58)), "start_button");
                ComposerKt.sourceInformationMarkerStart($composer, 29270591, "CC(remember):DashboardScreen.kt#9igjgp");
                zChangedInstance = $composer.changedInstance($context) | $composer.changedInstance($viewModel);
                Object objRememberedValue4 = $composer.rememberedValue();
                if (zChangedInstance) {
                }
                obj3 = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda16
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardScreenKt.DashboardScreen$lambda$56$lambda$55$lambda$53$lambda$52($context, $viewModel, $syncCodeInput$delegate, $isResolvingSyncCode$delegate, $showSelfie$delegate);
                    }
                };
                $composer.updateRememberedValue(obj3);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ButtonKt.Button((Function0) obj3, modifierTestTag2, z2, roundedCornerShape2, buttonColors2, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-804629338, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda17
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return DashboardScreenKt.DashboardScreen$lambda$56$lambda$55$lambda$54($isResolvingSyncCode$delegate, (RowScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, $composer, 54), $composer, 805306416, 480);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endReplaceGroup();
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit DashboardScreen$lambda$56$lambda$47$lambda$46(MutableState $showSelfie$delegate) {
        DashboardScreen$lambda$41($showSelfie$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit DashboardScreen$lambda$56$lambda$55$lambda$50$lambda$49(MutableState $syncCodeInput$delegate, String str) {
        Intrinsics.checkNotNullParameter(str, "new");
        if (str.length() <= 5) {
            String str2 = str;
            boolean z = false;
            int i = 0;
            while (true) {
                if (i < str2.length()) {
                    if (!Character.isDigit(str2.charAt(i))) {
                        break;
                    }
                    i++;
                } else {
                    z = true;
                    break;
                }
            }
            if (z) {
                $syncCodeInput$delegate.setValue(str);
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit DashboardScreen$lambda$56$lambda$55$lambda$53$lambda$52(final Context $context, TransactionViewModel $viewModel, MutableState $syncCodeInput$delegate, final MutableState $isResolvingSyncCode$delegate, final MutableState $showSelfie$delegate) {
        String code = StringsKt.trim((CharSequence) DashboardScreen$lambda$4($syncCodeInput$delegate)).toString();
        if (code.length() != 5) {
            Toast.makeText($context, "Enter the 5-digit sync code first", 0).show();
        } else {
            DashboardScreen$lambda$8($isResolvingSyncCode$delegate, true);
            $viewModel.startSelfieWithSyncCode(code, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return DashboardScreenKt.m٨٣٦٠x2e801415($context, $isResolvingSyncCode$delegate, $showSelfie$delegate, ((Boolean) obj).booleanValue(), (String) obj2);
                }
            });
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: DashboardScreen$lambda$56$lambda$55$lambda$53$lambda$52$lambda$51, reason: contains not printable characters */
    static final Unit m٨٣٦٠x2e801415(Context $context, MutableState $isResolvingSyncCode$delegate, MutableState $showSelfie$delegate, boolean success, String message) {
        Intrinsics.checkNotNullParameter(message, "message");
        DashboardScreen$lambda$8($isResolvingSyncCode$delegate, false);
        if (!success) {
            Toast.makeText($context, message, 0).show();
        } else {
            DashboardScreen$lambda$41($showSelfie$delegate, true);
        }
        return Unit.INSTANCE;
    }

    static final Unit DashboardScreen$lambda$56$lambda$55$lambda$54(MutableState $isResolvingSyncCode$delegate, RowScope Button, Composer $composer, int $changed) {
        Composer composer = $composer;
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation(composer, "C208@9332L28,209@9381L91:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-804629338, $changed, -1, "com.example.ui.screens.DashboardScreen.<anonymous>.<anonymous>.<anonymous> (DashboardScreen.kt:199)");
            }
            if (DashboardScreen$lambda$7($isResolvingSyncCode$delegate)) {
                composer.startReplaceGroup(-500074820);
                ComposerKt.sourceInformation(composer, "200@8962L208");
                ProgressIndicatorKt.m٣١٥٩CircularProgressIndicatorLxG7B9w(SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(20)), ColorKt.getTextOnGold(), CDp.m٧٩٥٨constructorimpl(2), 0L, 0, $composer, 438, 24);
                composer = $composer;
                composer.endReplaceGroup();
            } else {
                composer.startReplaceGroup(-499819349);
                ComposerKt.sourceInformation(composer, "206@9224L65");
                IconKt.m٢٩٣٤Iconww6aTOc(SendKt.getSend(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, 0L, composer, 48, 12);
                composer.endReplaceGroup();
            }
            SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer, 6);
            TextKt.m٣٥٠٢Text4IGK_g("START SELFIE", (Modifier) null, 0L, TextUnitKt.getSp(15), (FontStyle) null, FontWeight.INSTANCE.getBlack(), (FontFamily) null, TextUnitKt.getSp(1), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 12782598, 0, 130902);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit DashboardScreen$lambda$58$lambda$57(MutableState $showDebugDialog$delegate) {
        DashboardScreen$lambda$32($showDebugDialog$delegate, false);
        return Unit.INSTANCE;
    }

    private static final void DebugLogDialog(final Function0<Unit> function0, Composer $composer, final int $changed) {
        final Function0<Unit> function1;
        Composer $composer2;
        Composer $composer3 = $composer.startRestartGroup(1609072369);
        ComposerKt.sourceInformation($composer3, "C(DebugLogDialog)228@10025L29,229@10104L7,230@10143L7,232@10193L2936,232@10156L2973:DashboardScreen.kt#2thlc2");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer3.changedInstance(function0) ? 4 : 2;
        }
        if (($dirty & 3) == 2 && $composer3.getSkipping()) {
            $composer3.skipToGroupEnd();
            function1 = function0;
            $composer2 = $composer3;
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1609072369, $dirty, -1, "com.example.ui.screens.DebugLogDialog (DashboardScreen.kt:227)");
            }
            final State lines$delegate = FlowExtKt.collectAsStateWithLifecycle(DebugLog.INSTANCE.getLines(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer3, 0, 7);
            ProvidableCompositionLocal<ClipboardManager> localClipboardManager = CompositionLocalsKt.getLocalClipboardManager();
            ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer3.consume(localClipboardManager);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            final ClipboardManager clipboardManager = (ClipboardManager) objConsume;
            ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume2 = $composer3.consume(localContext);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            final Context context = (Context) objConsume2;
            function1 = function0;
            AndroidDialog_androidKt.Dialog(function1, null, ComposableLambdaKt.rememberComposableLambda(1769485946, true, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return DashboardScreenKt.DebugLogDialog$lambda$74(lines$delegate, clipboardManager, context, function0, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer3, 54), $composer3, ($dirty & 14) | 384, 2);
            $composer2 = $composer3;
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return DashboardScreenKt.DebugLogDialog$lambda$75(function1, $changed, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final List<String> DebugLogDialog$lambda$60(State<? extends List<String>> state) {
        return (List) state.getValue();
    }

    static final Unit DebugLogDialog$lambda$74(final State $lines$delegate, final ClipboardManager $clipboardManager, final Context $context, final Function0 $onDismiss, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C240@10465L2658,233@10203L2920:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1769485946, $changed, -1, "com.example.ui.screens.DebugLogDialog.<anonymous> (DashboardScreen.kt:233)");
            }
            SurfaceKt.m٣٣٤٦SurfaceT9BRK9s(SizeKt.fillMaxHeight(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), 0.85f), RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(14)), ColorKt.getObsidianSurface(), 0L, 0.0f, 0.0f, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder()), ComposableLambdaKt.rememberComposableLambda(-990986369, true, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73($lines$delegate, $clipboardManager, $context, $onDismiss, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer, 54), $composer, 14156166, 56);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:103:0x077c  */
    /* JADX WARN: Code duplicated, block: B:28:0x01de  */
    /* JADX WARN: Code duplicated, block: B:31:0x01ea  */
    /* JADX WARN: Code duplicated, block: B:32:0x01f0  */
    /* JADX WARN: Code duplicated, block: B:43:0x0354  */
    /* JADX WARN: Code duplicated, block: B:46:0x0360  */
    /* JADX WARN: Code duplicated, block: B:47:0x0366  */
    /* JADX WARN: Code duplicated, block: B:58:0x041a  */
    /* JADX WARN: Code duplicated, block: B:61:0x0425  */
    /* JADX WARN: Code duplicated, block: B:62:0x042a  */
    /* JADX WARN: Code duplicated, block: B:66:0x047c  */
    /* JADX WARN: Code duplicated, block: B:67:0x048d  */
    /* JADX WARN: Code duplicated, block: B:70:0x0540  */
    /* JADX WARN: Code duplicated, block: B:72:0x05b1  */
    /* JADX WARN: Code duplicated, block: B:75:0x05bd  */
    /* JADX WARN: Code duplicated, block: B:76:0x05c3  */
    /* JADX WARN: Code duplicated, block: B:79:0x05f4  */
    /* JADX WARN: Code duplicated, block: B:82:0x0607  */
    /* JADX WARN: Code duplicated, block: B:83:0x060a  */
    /* JADX WARN: Code duplicated, block: B:86:0x06ab  */
    /* JADX WARN: Code duplicated, block: B:88:0x06e0  */
    /* JADX WARN: Code duplicated, block: B:92:0x06ed  */
    /* JADX WARN: Code duplicated, block: B:95:0x0726  */
    /* JADX WARN: Code duplicated, block: B:99:0x0731  */
    static final Unit DebugLogDialog$lambda$74$lambda$73(final State $lines$delegate, final ClipboardManager $clipboardManager, final Context $context, Function0 $onDismiss, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composer3;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composer4;
        boolean zChangedInstance;
        Object objRememberedValue;
        Composer composer5;
        Composer composer6;
        Object objRememberedValue2;
        Object obj;
        LazyListState lazyListStateRememberLazyListState;
        boolean zChanged;
        DashboardScreenKt$DebugLogDialog$1$1$1$3$1 dashboardScreenKt$DebugLogDialog$1$1$1$3$1;
        boolean zChanged2;
        Object obj2;
        Composer composer7;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composer8;
        int i;
        Composer composer9;
        ComposerKt.sourceInformation($composer, "C241@10479L2634:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-990986369, $changed, -1, "com.example.ui.screens.DebugLogDialog.<anonymous>.<anonymous> (DashboardScreen.kt:241)");
            }
            Modifier modifier = PaddingKt.m١١٩٦padding3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i2 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor4;
                $composer.createNode(function0);
            } else {
                function0 = constructor4;
                $composer.useNode();
            }
            Composer composer10 = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer10, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer10, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer10.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composer10.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                }
                Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i3 = (i2 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i4 = ((6 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 478700431, "C242@10540L1335,269@11892L29,270@11938L49,271@12004L29:DashboardScreen.kt#2thlc2");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i5 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composer3 = Updater.m٤٤٨٨constructorimpl(composer2);
                Updater.m٤٤٩٥setimpl(composer3, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer3, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer3.getInserting() || !Intrinsics.areEqual(composer3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composer3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composer3.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m٤٤٩٥setimpl(composer3, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i6 = (i5 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i7 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -3117837, "C247@10778L274,254@11073L784:DashboardScreen.kt#2thlc2");
                TextKt.m٣٥٠٢Text4IGK_g("DEBUG LOG (" + DebugLogDialog$lambda$60($lines$delegate).size() + ")", (Modifier) null, ColorKt.getGoldPrimary(), TextUnitKt.getSp(14), (FontStyle) null, FontWeight.INSTANCE.getBlack(), (FontFamily) null, TextUnitKt.getSp(1), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 12782976, 0, 130898);
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier2 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), Alignment.INSTANCE.getTop(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifier2);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i8 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composer4 = Updater.m٤٤٨٨constructorimpl(composer2);
                Updater.m٤٤٩٥setimpl(composer4, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer4, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer4.getInserting() || !Intrinsics.areEqual(composer4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composer4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composer4.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m٤٤٩٥setimpl(composer4, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i9 = (i8 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i10 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -900829558, "C255@11124L220,255@11103L362,261@11511L20,261@11490L162,264@11677L158:DashboardScreen.kt#2thlc2");
                ComposerKt.sourceInformationMarkerStart(composer2, -998890183, "CC(remember):DashboardScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($clipboardManager) | composer2.changedInstance($context);
                objRememberedValue = composer2.rememberedValue();
                if (zChangedInstance) {
                    composer5 = composer2;
                } else {
                    composer5 = composer2;
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٧getLambda$1993344262$app(), composer5, 805306368, 510);
                    composer6 = composer5;
                    ComposerKt.sourceInformationMarkerStart(composer6, -998877999, "CC(remember):DashboardScreen.kt#9igjgp");
                    objRememberedValue2 = composer6.rememberedValue();
                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda21
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return DashboardScreenKt.m٨٣٦٢x18ff8736();
                            }
                        };
                        composer6.updateRememberedValue(obj);
                    } else {
                        obj = objRememberedValue2;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    ButtonKt.TextButton((Function0) obj, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٥getLambda$1263673359$app(), composer6, 805306374, 510);
                    ButtonKt.TextButton($onDismiss, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$827856178$app(), composer6, 805306368, 510);
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
                    DividerKt.m٢٨٤٣Divider9IZ8Weo(null, CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder(), composer2, 432, 1);
                    SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
                    if (DebugLogDialog$lambda$60($lines$delegate).isEmpty()) {
                        composer2.startReplaceGroup(480147169);
                        ComposerKt.sourceInformation(composer2, "273@12093L196");
                        Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                        Alignment center = Alignment.INSTANCE.getCenter();
                        ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                        ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                        currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                        CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                        Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxSize$default);
                        constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                        int i11 = ((((54 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                        if (!(composer2.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
                        composer2.startReusableNode();
                        if (composer2.getInserting()) {
                            function3 = constructor3;
                            composer2.createNode(function3);
                        } else {
                            function3 = constructor3;
                            composer2.useNode();
                        }
                        composer8 = Updater.m٤٤٨٨constructorimpl(composer2);
                        Updater.m٤٤٩٥setimpl(composer8, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        Updater.m٤٤٩٥setimpl(composer8, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (composer8.getInserting()) {
                            i = 54;
                            composer9 = composer2;
                        } else {
                            i = 54;
                            composer9 = composer2;
                            if (!Intrinsics.areEqual(composer8.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                            }
                            Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                            int i12 = (i11 >> 6) & 14;
                            Composer composer11 = composer9;
                            ComposerKt.sourceInformationMarkerStart(composer11, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                            int i13 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer11, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                            TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer11, 3462, 0, 131058);
                            ComposerKt.sourceInformationMarkerEnd(composer11);
                            ComposerKt.sourceInformationMarkerEnd(composer11);
                            composer9.endNode();
                            ComposerKt.sourceInformationMarkerEnd(composer9);
                            ComposerKt.sourceInformationMarkerEnd(composer9);
                            ComposerKt.sourceInformationMarkerEnd(composer9);
                            composer2.endReplaceGroup();
                            composer7 = composer2;
                        }
                        composer8.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                        composer8.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                        Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                        int i14 = (i11 >> 6) & 14;
                        Composer composer12 = composer9;
                        ComposerKt.sourceInformationMarkerStart(composer12, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                        int i15 = ((i >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer12, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                        TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer12, 3462, 0, 131058);
                        ComposerKt.sourceInformationMarkerEnd(composer12);
                        ComposerKt.sourceInformationMarkerEnd(composer12);
                        composer9.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        composer2.endReplaceGroup();
                        composer7 = composer2;
                    } else {
                        composer2.startReplaceGroup(480404283);
                        ComposerKt.sourceInformation(composer2, "277@12351L23,278@12422L117,278@12395L144,281@12625L456,281@12560L521");
                        lazyListStateRememberLazyListState = LazyListStateKt.rememberLazyListState(0, 0, composer2, 0, 3);
                        Integer numValueOf = Integer.valueOf(DebugLogDialog$lambda$60($lines$delegate).size());
                        ComposerKt.sourceInformationMarkerStart(composer2, -1369973590, "CC(remember):DashboardScreen.kt#9igjgp");
                        zChanged = composer2.changed($lines$delegate) | composer2.changed(lazyListStateRememberLazyListState);
                        Object objRememberedValue3 = composer2.rememberedValue();
                        if (!zChanged || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                            dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(lazyListStateRememberLazyListState, $lines$delegate, null);
                            composer2.updateRememberedValue(dashboardScreenKt$DebugLogDialog$1$1$1$3$1);
                        } else {
                            dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = objRememberedValue3;
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        EffectsKt.LaunchedEffect(numValueOf, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) dashboardScreenKt$DebugLogDialog$1$1$1$3$1, composer2, 0);
                        Modifier modifierFillMaxSize$default2 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                        ComposerKt.sourceInformationMarkerStart(composer2, -1369966755, "CC(remember):DashboardScreen.kt#9igjgp");
                        zChanged2 = composer2.changed($lines$delegate);
                        Object objRememberedValue4 = composer2.rememberedValue();
                        if (!zChanged2 || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                            obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda22
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj3) {
                                    return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70($lines$delegate, (LazyListScope) obj3);
                                }
                            };
                            composer2.updateRememberedValue(obj2);
                        } else {
                            obj2 = objRememberedValue4;
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer7 = composer2;
                        LazyDslKt.LazyColumn(modifierFillMaxSize$default2, lazyListStateRememberLazyListState, null, false, null, null, null, false, (Function1) obj2, composer7, 6, 252);
                        composer7.endReplaceGroup();
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                objRememberedValue = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda20
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardScreenKt.m٨٣٦١xef3621b2($clipboardManager, $context);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٧getLambda$1993344262$app(), composer5, 805306368, 510);
                composer6 = composer5;
                ComposerKt.sourceInformationMarkerStart(composer6, -998877999, "CC(remember):DashboardScreen.kt#9igjgp");
                objRememberedValue2 = composer6.rememberedValue();
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return DashboardScreenKt.m٨٣٦٢x18ff8736();
                        }
                    };
                    composer6.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue2;
                }
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ButtonKt.TextButton((Function0) obj, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٥getLambda$1263673359$app(), composer6, 805306374, 510);
                ButtonKt.TextButton($onDismiss, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$827856178$app(), composer6, 805306368, 510);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
                DividerKt.m٢٨٤٣Divider9IZ8Weo(null, CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder(), composer2, 432, 1);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
                if (DebugLogDialog$lambda$60($lines$delegate).isEmpty()) {
                    composer2.startReplaceGroup(480147169);
                    ComposerKt.sourceInformation(composer2, "273@12093L196");
                    Modifier modifierFillMaxSize$default3 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                    Alignment center2 = Alignment.INSTANCE.getCenter();
                    ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(center2, false);
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxSize$default3);
                    constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                    int i16 = ((((54 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function3 = constructor3;
                        composer2.createNode(function3);
                    } else {
                        function3 = constructor3;
                        composer2.useNode();
                    }
                    composer8 = Updater.m٤٤٨٨constructorimpl(composer2);
                    Updater.m٤٤٩٥setimpl(composer8, measurePolicyMaybeCachedBoxMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m٤٤٩٥setimpl(composer8, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (composer8.getInserting()) {
                        i = 54;
                        composer9 = composer2;
                        if (!Intrinsics.areEqual(composer8.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                        }
                        Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                        int i17 = (i16 >> 6) & 14;
                        Composer composer13 = composer9;
                        ComposerKt.sourceInformationMarkerStart(composer13, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance3 = BoxScopeInstance.INSTANCE;
                        int i18 = ((i >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer13, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                        TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer13, 3462, 0, 131058);
                        ComposerKt.sourceInformationMarkerEnd(composer13);
                        ComposerKt.sourceInformationMarkerEnd(composer13);
                        composer9.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        composer2.endReplaceGroup();
                        composer7 = composer2;
                    } else {
                        i = 54;
                        composer9 = composer2;
                    }
                    composer8.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composer8.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash5);
                    Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                    int i19 = (i16 >> 6) & 14;
                    Composer composer14 = composer9;
                    ComposerKt.sourceInformationMarkerStart(composer14, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance4 = BoxScopeInstance.INSTANCE;
                    int i110 = ((i >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer14, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                    TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer14, 3462, 0, 131058);
                    ComposerKt.sourceInformationMarkerEnd(composer14);
                    ComposerKt.sourceInformationMarkerEnd(composer14);
                    composer9.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    composer2.endReplaceGroup();
                    composer7 = composer2;
                } else {
                    composer2.startReplaceGroup(480404283);
                    ComposerKt.sourceInformation(composer2, "277@12351L23,278@12422L117,278@12395L144,281@12625L456,281@12560L521");
                    lazyListStateRememberLazyListState = LazyListStateKt.rememberLazyListState(0, 0, composer2, 0, 3);
                    Integer numValueOf2 = Integer.valueOf(DebugLogDialog$lambda$60($lines$delegate).size());
                    ComposerKt.sourceInformationMarkerStart(composer2, -1369973590, "CC(remember):DashboardScreen.kt#9igjgp");
                    zChanged = composer2.changed($lines$delegate) | composer2.changed(lazyListStateRememberLazyListState);
                    Object objRememberedValue5 = composer2.rememberedValue();
                    if (zChanged) {
                        dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(lazyListStateRememberLazyListState, $lines$delegate, null);
                        composer2.updateRememberedValue(dashboardScreenKt$DebugLogDialog$1$1$1$3$1);
                    } else {
                        dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(lazyListStateRememberLazyListState, $lines$delegate, null);
                        composer2.updateRememberedValue(dashboardScreenKt$DebugLogDialog$1$1$1$3$1);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    EffectsKt.LaunchedEffect(numValueOf2, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) dashboardScreenKt$DebugLogDialog$1$1$1$3$1, composer2, 0);
                    Modifier modifierFillMaxSize$default4 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                    ComposerKt.sourceInformationMarkerStart(composer2, -1369966755, "CC(remember):DashboardScreen.kt#9igjgp");
                    zChanged2 = composer2.changed($lines$delegate);
                    Object objRememberedValue6 = composer2.rememberedValue();
                    if (zChanged2) {
                        obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda22
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj3) {
                                return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70($lines$delegate, (LazyListScope) obj3);
                            }
                        };
                        composer2.updateRememberedValue(obj2);
                    } else {
                        obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda22
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj3) {
                                return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70($lines$delegate, (LazyListScope) obj3);
                            }
                        };
                        composer2.updateRememberedValue(obj2);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer7 = composer2;
                    LazyDslKt.LazyColumn(modifierFillMaxSize$default4, lazyListStateRememberLazyListState, null, false, null, null, null, false, (Function1) obj2, composer7, 6, 252);
                    composer7.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composer10.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composer10.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash);
            Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i20 = (i2 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i21 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 478700431, "C242@10540L1335,269@11892L29,270@11938L49,271@12004L29:DashboardScreen.kt#2thlc2");
            Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically2, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap6 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i22 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composer3 = Updater.m٤٤٨٨constructorimpl(composer2);
            Updater.m٤٤٩٥setimpl(composer3, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer3, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer3.getInserting()) {
            }
            composer3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composer3.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash6);
            Updater.m٤٤٩٥setimpl(composer3, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
            int i23 = (i22 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
            int i24 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -3117837, "C247@10778L274,254@11073L784:DashboardScreen.kt#2thlc2");
            TextKt.m٣٥٠٢Text4IGK_g("DEBUG LOG (" + DebugLogDialog$lambda$60($lines$delegate).size() + ")", (Modifier) null, ColorKt.getGoldPrimary(), TextUnitKt.getSp(14), (FontStyle) null, FontWeight.INSTANCE.getBlack(), (FontFamily) null, TextUnitKt.getSp(1), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 12782976, 0, 130898);
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier3 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), Alignment.INSTANCE.getTop(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap7 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composer2, modifier3);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i25 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composer4 = Updater.m٤٤٨٨constructorimpl(composer2);
            Updater.m٤٤٩٥setimpl(composer4, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer4, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer4.getInserting()) {
            }
            composer4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composer4.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash7);
            Updater.m٤٤٩٥setimpl(composer4, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
            int i26 = (i25 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i111 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -900829558, "C255@11124L220,255@11103L362,261@11511L20,261@11490L162,264@11677L158:DashboardScreen.kt#2thlc2");
            ComposerKt.sourceInformationMarkerStart(composer2, -998890183, "CC(remember):DashboardScreen.kt#9igjgp");
            zChangedInstance = composer2.changedInstance($clipboardManager) | composer2.changedInstance($context);
            objRememberedValue = composer2.rememberedValue();
            if (zChangedInstance) {
                composer5 = composer2;
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                }
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٧getLambda$1993344262$app(), composer5, 805306368, 510);
                composer6 = composer5;
                ComposerKt.sourceInformationMarkerStart(composer6, -998877999, "CC(remember):DashboardScreen.kt#9igjgp");
                objRememberedValue2 = composer6.rememberedValue();
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return DashboardScreenKt.m٨٣٦٢x18ff8736();
                        }
                    };
                    composer6.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue2;
                }
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ButtonKt.TextButton((Function0) obj, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٥getLambda$1263673359$app(), composer6, 805306374, 510);
                ButtonKt.TextButton($onDismiss, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$827856178$app(), composer6, 805306368, 510);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
                DividerKt.m٢٨٤٣Divider9IZ8Weo(null, CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder(), composer2, 432, 1);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
                if (DebugLogDialog$lambda$60($lines$delegate).isEmpty()) {
                    composer2.startReplaceGroup(480147169);
                    ComposerKt.sourceInformation(composer2, "273@12093L196");
                    Modifier modifierFillMaxSize$default5 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                    Alignment center3 = Alignment.INSTANCE.getCenter();
                    ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy3 = BoxKt.maybeCachedBoxMeasurePolicy(center3, false);
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap8 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier8 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxSize$default5);
                    constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                    int i112 = ((((54 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function3 = constructor3;
                        composer2.createNode(function3);
                    } else {
                        function3 = constructor3;
                        composer2.useNode();
                    }
                    composer8 = Updater.m٤٤٨٨constructorimpl(composer2);
                    Updater.m٤٤٩٥setimpl(composer8, measurePolicyMaybeCachedBoxMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m٤٤٩٥setimpl(composer8, currentCompositionLocalMap8, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash8 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (composer8.getInserting()) {
                        i = 54;
                        composer9 = composer2;
                        if (!Intrinsics.areEqual(composer8.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                        }
                        Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
                        int i113 = (i112 >> 6) & 14;
                        Composer composer15 = composer9;
                        ComposerKt.sourceInformationMarkerStart(composer15, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance5 = BoxScopeInstance.INSTANCE;
                        int i114 = ((i >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer15, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                        TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer15, 3462, 0, 131058);
                        ComposerKt.sourceInformationMarkerEnd(composer15);
                        ComposerKt.sourceInformationMarkerEnd(composer15);
                        composer9.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        composer2.endReplaceGroup();
                        composer7 = composer2;
                    } else {
                        i = 54;
                        composer9 = composer2;
                    }
                    composer8.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composer8.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash8);
                    Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
                    int i115 = (i112 >> 6) & 14;
                    Composer composer16 = composer9;
                    ComposerKt.sourceInformationMarkerStart(composer16, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance6 = BoxScopeInstance.INSTANCE;
                    int i116 = ((i >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer16, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                    TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer16, 3462, 0, 131058);
                    ComposerKt.sourceInformationMarkerEnd(composer16);
                    ComposerKt.sourceInformationMarkerEnd(composer16);
                    composer9.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    composer2.endReplaceGroup();
                    composer7 = composer2;
                } else {
                    composer2.startReplaceGroup(480404283);
                    ComposerKt.sourceInformation(composer2, "277@12351L23,278@12422L117,278@12395L144,281@12625L456,281@12560L521");
                    lazyListStateRememberLazyListState = LazyListStateKt.rememberLazyListState(0, 0, composer2, 0, 3);
                    Integer numValueOf3 = Integer.valueOf(DebugLogDialog$lambda$60($lines$delegate).size());
                    ComposerKt.sourceInformationMarkerStart(composer2, -1369973590, "CC(remember):DashboardScreen.kt#9igjgp");
                    zChanged = composer2.changed($lines$delegate) | composer2.changed(lazyListStateRememberLazyListState);
                    Object objRememberedValue7 = composer2.rememberedValue();
                    if (zChanged) {
                        dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(lazyListStateRememberLazyListState, $lines$delegate, null);
                        composer2.updateRememberedValue(dashboardScreenKt$DebugLogDialog$1$1$1$3$1);
                    } else {
                        dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(lazyListStateRememberLazyListState, $lines$delegate, null);
                        composer2.updateRememberedValue(dashboardScreenKt$DebugLogDialog$1$1$1$3$1);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    EffectsKt.LaunchedEffect(numValueOf3, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) dashboardScreenKt$DebugLogDialog$1$1$1$3$1, composer2, 0);
                    Modifier modifierFillMaxSize$default6 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                    ComposerKt.sourceInformationMarkerStart(composer2, -1369966755, "CC(remember):DashboardScreen.kt#9igjgp");
                    zChanged2 = composer2.changed($lines$delegate);
                    Object objRememberedValue8 = composer2.rememberedValue();
                    if (zChanged2) {
                        obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda22
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj3) {
                                return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70($lines$delegate, (LazyListScope) obj3);
                            }
                        };
                        composer2.updateRememberedValue(obj2);
                    } else {
                        obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda22
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj3) {
                                return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70($lines$delegate, (LazyListScope) obj3);
                            }
                        };
                        composer2.updateRememberedValue(obj2);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer7 = composer2;
                    LazyDslKt.LazyColumn(modifierFillMaxSize$default6, lazyListStateRememberLazyListState, null, false, null, null, null, false, (Function1) obj2, composer7, 6, 252);
                    composer7.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer5 = composer2;
            }
            objRememberedValue = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda20
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return DashboardScreenKt.m٨٣٦١xef3621b2($clipboardManager, $context);
                }
            };
            composer2.updateRememberedValue(objRememberedValue);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٧getLambda$1993344262$app(), composer5, 805306368, 510);
            composer6 = composer5;
            ComposerKt.sourceInformationMarkerStart(composer6, -998877999, "CC(remember):DashboardScreen.kt#9igjgp");
            objRememberedValue2 = composer6.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda21
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardScreenKt.m٨٣٦٢x18ff8736();
                    }
                };
                composer6.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue2;
            }
            ComposerKt.sourceInformationMarkerEnd(composer6);
            ButtonKt.TextButton((Function0) obj, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٥getLambda$1263673359$app(), composer6, 805306374, 510);
            ButtonKt.TextButton($onDismiss, null, false, null, null, null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$827856178$app(), composer6, 805306368, 510);
            ComposerKt.sourceInformationMarkerEnd(composer6);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
            DividerKt.m٢٨٤٣Divider9IZ8Weo(null, CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder(), composer2, 432, 1);
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer2, 6);
            if (DebugLogDialog$lambda$60($lines$delegate).isEmpty()) {
                composer2.startReplaceGroup(480147169);
                ComposerKt.sourceInformation(composer2, "273@12093L196");
                Modifier modifierFillMaxSize$default7 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                Alignment center4 = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy4 = BoxKt.maybeCachedBoxMeasurePolicy(center4, false);
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap9 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier9 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxSize$default7);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i117 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composer8 = Updater.m٤٤٨٨constructorimpl(composer2);
                Updater.m٤٤٩٥setimpl(composer8, measurePolicyMaybeCachedBoxMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer8, currentCompositionLocalMap9, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash9 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composer8.getInserting()) {
                    i = 54;
                    composer9 = composer2;
                    if (!Intrinsics.areEqual(composer8.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    }
                    Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier9, ComposeUiNode.INSTANCE.getSetModifier());
                    int i118 = (i117 >> 6) & 14;
                    Composer composer17 = composer9;
                    ComposerKt.sourceInformationMarkerStart(composer17, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance7 = BoxScopeInstance.INSTANCE;
                    int i119 = ((i >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer17, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                    TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer17, 3462, 0, 131058);
                    ComposerKt.sourceInformationMarkerEnd(composer17);
                    ComposerKt.sourceInformationMarkerEnd(composer17);
                    composer9.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    composer2.endReplaceGroup();
                    composer7 = composer2;
                } else {
                    i = 54;
                    composer9 = composer2;
                }
                composer8.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                composer8.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash9);
                Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier9, ComposeUiNode.INSTANCE.getSetModifier());
                int i1110 = (i117 >> 6) & 14;
                Composer composer18 = composer9;
                ComposerKt.sourceInformationMarkerStart(composer18, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance8 = BoxScopeInstance.INSTANCE;
                int i1111 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer18, 1432381797, "C274@12195L72:DashboardScreen.kt#2thlc2");
                TextKt.m٣٥٠٢Text4IGK_g("No log entries yet.", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer18, 3462, 0, 131058);
                ComposerKt.sourceInformationMarkerEnd(composer18);
                ComposerKt.sourceInformationMarkerEnd(composer18);
                composer9.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer9);
                ComposerKt.sourceInformationMarkerEnd(composer9);
                ComposerKt.sourceInformationMarkerEnd(composer9);
                composer2.endReplaceGroup();
                composer7 = composer2;
            } else {
                composer2.startReplaceGroup(480404283);
                ComposerKt.sourceInformation(composer2, "277@12351L23,278@12422L117,278@12395L144,281@12625L456,281@12560L521");
                lazyListStateRememberLazyListState = LazyListStateKt.rememberLazyListState(0, 0, composer2, 0, 3);
                Integer numValueOf4 = Integer.valueOf(DebugLogDialog$lambda$60($lines$delegate).size());
                ComposerKt.sourceInformationMarkerStart(composer2, -1369973590, "CC(remember):DashboardScreen.kt#9igjgp");
                zChanged = composer2.changed($lines$delegate) | composer2.changed(lazyListStateRememberLazyListState);
                Object objRememberedValue9 = composer2.rememberedValue();
                if (zChanged) {
                    dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(lazyListStateRememberLazyListState, $lines$delegate, null);
                    composer2.updateRememberedValue(dashboardScreenKt$DebugLogDialog$1$1$1$3$1);
                } else {
                    dashboardScreenKt$DebugLogDialog$1$1$1$3$1 = new DashboardScreenKt$DebugLogDialog$1$1$1$3$1(lazyListStateRememberLazyListState, $lines$delegate, null);
                    composer2.updateRememberedValue(dashboardScreenKt$DebugLogDialog$1$1$1$3$1);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                EffectsKt.LaunchedEffect(numValueOf4, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) dashboardScreenKt$DebugLogDialog$1$1$1$3$1, composer2, 0);
                Modifier modifierFillMaxSize$default8 = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                ComposerKt.sourceInformationMarkerStart(composer2, -1369966755, "CC(remember):DashboardScreen.kt#9igjgp");
                zChanged2 = composer2.changed($lines$delegate);
                Object objRememberedValue10 = composer2.rememberedValue();
                if (zChanged2) {
                    obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda22
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj3) {
                            return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70($lines$delegate, (LazyListScope) obj3);
                        }
                    };
                    composer2.updateRememberedValue(obj2);
                } else {
                    obj2 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda22
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj3) {
                            return DashboardScreenKt.DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70($lines$delegate, (LazyListScope) obj3);
                        }
                    };
                    composer2.updateRememberedValue(obj2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer7 = composer2;
                LazyDslKt.LazyColumn(modifierFillMaxSize$default8, lazyListStateRememberLazyListState, null, false, null, null, null, false, (Function1) obj2, composer7, 6, 252);
                composer7.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$66$lambda$65$lambda$62$lambda$61, reason: contains not printable characters */
    static final Unit m٨٣٦١xef3621b2(ClipboardManager $clipboardManager, Context $context) {
        $clipboardManager.setText(new AnnotatedString(DebugLog.INSTANCE.dump(), null, null, 6, null));
        Toast.makeText($context, "Log copied to clipboard", 0).show();
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$66$lambda$65$lambda$64$lambda$63, reason: contains not printable characters */
    static final Unit m٨٣٦٢x18ff8736() {
        DebugLog.INSTANCE.clear();
        return Unit.INSTANCE;
    }

    static final Unit DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70(State $lines$delegate, LazyListScope LazyColumn) {
        Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
        final List<String> listDebugLogDialog$lambda$60 = DebugLogDialog$lambda$60($lines$delegate);
        final Function1 function1 = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70$$inlined$items$default$1
            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Object p1) {
                return invoke((String) p1);
            }

            @Override // kotlin.jvm.functions.Function1
            public final Void invoke(String str) {
                return null;
            }
        };
        LazyColumn.items(listDebugLogDialog$lambda$60.size(), null, new Function1<Integer, Object>() { // from class: com.example.ui.screens.DashboardScreenKt$DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70$$inlined$items$default$3
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            @Override // kotlin.jvm.functions.Function1
            public /* bridge */ /* synthetic */ Object invoke(Integer num) {
                return invoke(num.intValue());
            }

            public final Object invoke(int index) {
                return function1.invoke(listDebugLogDialog$lambda$60.get(index));
            }
        }, ComposableLambdaKt.composableLambdaInstance(-632812321, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.example.ui.screens.DashboardScreenKt$DebugLogDialog$lambda$74$lambda$73$lambda$72$lambda$71$lambda$70$$inlined$items$default$4
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(4);
            }

            @Override // kotlin.jvm.functions.Function4
            public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
                invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                return Unit.INSTANCE;
            }

            public final void invoke(LazyItemScope $this$items, int it, Composer $composer, int $changed) {
                ComposerKt.sourceInformation($composer, "C152@7074L22:LazyDsl.kt#428nma");
                int $dirty = $changed;
                if (($changed & 6) == 0) {
                    $dirty |= $composer.changed($this$items) ? 4 : 2;
                }
                if (($changed & 48) == 0) {
                    $dirty |= $composer.changed(it) ? 32 : 16;
                }
                if (($dirty & 147) == 146 && $composer.getSkipping()) {
                    $composer.skipToGroupEnd();
                    return;
                }
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventStart(-632812321, $dirty, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:152)");
                }
                String str = (String) listDebugLogDialog$lambda$60.get(it);
                $composer.startReplaceGroup(-1907978808);
                ComposerKt.sourceInformation($composer, "C*283@12702L331:DashboardScreen.kt#2thlc2");
                TextKt.m٣٥٠٢Text4IGK_g(str, PaddingKt.m١١٩٨paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, CDp.m٧٩٥٨constructorimpl(1), 1, null), ColorKt.getTextPrimaryDark(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) FontFamily.INSTANCE.getMonospace(), 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, ((($dirty & 14) >> 3) & 14) | 3504, 0, 130992);
                $composer.endReplaceGroup();
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
        }));
        return Unit.INSTANCE;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:71:0x014d  */
    public static final void TransactionItem(final Transaction transaction, final Function0<Unit> onCheckSingle, final Function0<Unit> onToggleAutoPoll, final Function0<Unit> onDelete, final Function0<Unit> onCopySess, final Function1<? super String, Unit> onCopyCr, Composer $composer, final int $changed) {
        int i;
        Object objMutableStateOf$default;
        Pair pair;
        long obsidianBorder;
        Object obj;
        Composer $composer2;
        Intrinsics.checkNotNullParameter(transaction, "transaction");
        Intrinsics.checkNotNullParameter(onCheckSingle, "onCheckSingle");
        Intrinsics.checkNotNullParameter(onToggleAutoPoll, "onToggleAutoPoll");
        Intrinsics.checkNotNullParameter(onDelete, "onDelete");
        Intrinsics.checkNotNullParameter(onCopySess, "onCopySess");
        Intrinsics.checkNotNullParameter(onCopyCr, "onCopyCr");
        Composer $composer3 = $composer.startRestartGroup(1526379536);
        ComposerKt.sourceInformation($composer3, "C(TransactionItem)P(5!1,4,3,2)307@13370L34,318@13750L43,319@13830L258,331@14174L196,330@14118L24,345@14659L12770,329@14094L13335:DashboardScreen.kt#2thlc2");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer3.changed(transaction) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer3.changedInstance(onCheckSingle) ? 32 : 16;
        }
        if (($changed & 384) == 0) {
            $dirty |= $composer3.changedInstance(onToggleAutoPoll) ? 256 : 128;
        }
        if (($changed & 3072) == 0) {
            $dirty |= $composer3.changedInstance(onDelete) ? 2048 : 1024;
        }
        if (($changed & 24576) == 0) {
            $dirty |= $composer3.changedInstance(onCopySess) ? 16384 : 8192;
        }
        if ((196608 & $changed) == 0) {
            $dirty |= $composer3.changedInstance(onCopyCr) ? 131072 : 65536;
        }
        if ((74899 & $dirty) == 74898 && $composer3.getSkipping()) {
            $composer3.skipToGroupEnd();
            $composer2 = $composer3;
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1526379536, $dirty, -1, "com.example.ui.screens.TransactionItem (DashboardScreen.kt:306)");
            }
            ComposerKt.sourceInformationMarkerStart($composer3, -2028073518, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue = $composer3.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                i = 0;
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer3.updateRememberedValue(objMutableStateOf$default);
            } else {
                i = 0;
                objMutableStateOf$default = objRememberedValue;
            }
            final MutableState expanded$delegate = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            switch (transaction.getStatus()) {
                case "Success":
                    pair = TuplesKt.m٨٨٢٠to("SUCCESS", Color.m٥٠٥٩boximpl(ColorKt.getStateSuccess()));
                    break;
                case "Error":
                    pair = TuplesKt.m٨٨٢٠to("ERROR", Color.m٥٠٥٩boximpl(ColorKt.getStateError()));
                    break;
                case "Polling":
                    pair = TuplesKt.m٨٨٢٠to("POLLING", Color.m٥٠٥٩boximpl(ColorKt.getStatePolling()));
                    break;
                default:
                    pair = TuplesKt.m٨٨٢٠to("PENDING", Color.m٥٠٥٩boximpl(ColorKt.getStatePending()));
                    break;
            }
            final String statusLabel = (String) pair.component1();
            final long statusColor = ((Color) pair.component2()).m٥٠٧٩unboximpl();
            int i2 = i;
            InfiniteTransition infiniteTransition = InfiniteTransitionKt.rememberInfiniteTransition("pulse", $composer3, 6, i2);
            InfiniteTransitionKt.animateFloat(infiniteTransition, 0.8f, 1.2f, AnimationSpecKt.m٥٦٧infiniteRepeatable9IiC70o$default(AnimationSpecKt.tween$default(800, i2, EasingKt.getLinearEasing(), 2, null), RepeatMode.Reverse, 0L, 4, null), "scale", $composer3, InfiniteTransition.$stable | 25008 | (InfiniteRepeatableSpec.$stable << 9), 0);
            CardColors cardColors = CardDefaults.INSTANCE.m٢٥٨٣cardColorsro_MJ88(Intrinsics.areEqual(transaction.getStatus(), "Success") ? ColorKt.getObsidianSurfaceElevated() : ColorKt.getObsidianSurface(), 0L, 0L, 0L, $composer3, CardDefaults.$stable << 12, 14);
            float f = CDp.m٧٩٥٨constructorimpl(1);
            if (Intrinsics.areEqual(transaction.getStatus(), "Success")) {
                long stateSuccess = ColorKt.getStateSuccess();
                obsidianBorder = Color.m٥٠٦٧copywmQWz5c(stateSuccess, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateSuccess) : 0.5f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateSuccess) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateSuccess) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateSuccess) : 0.0f);
            } else {
                obsidianBorder = ColorKt.getObsidianBorder();
            }
            BorderStroke borderStroke = BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(f, obsidianBorder);
            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "transaction_item_card_" + transaction.getId());
            ComposerKt.sourceInformationMarkerStart($composer3, -2028049592, "CC(remember):DashboardScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer3.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda23
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return DashboardScreenKt.TransactionItem$lambda$81$lambda$80(expanded$delegate);
                    }
                };
                $composer3.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue2;
            }
            ComposerKt.sourceInformationMarkerEnd($composer3);
            $composer2 = $composer3;
            CardKt.Card((Function0) obj, modifierTestTag, false, null, cardColors, null, borderStroke, null, ComposableLambdaKt.rememberComposableLambda(446909445, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda24
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return DashboardScreenKt.TransactionItem$lambda$102(transaction, statusColor, onCopySess, statusLabel, onCopyCr, expanded$delegate, onDelete, onCheckSingle, onToggleAutoPoll, (ColumnScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, $composer3, 54), $composer2, 100663302, 172);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda25
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return DashboardScreenKt.TransactionItem$lambda$103(transaction, onCheckSingle, onToggleAutoPoll, onDelete, onCopySess, onCopyCr, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                }
            });
        }
    }

    private static final boolean TransactionItem$lambda$77(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void TransactionItem$lambda$78(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    static final Unit TransactionItem$lambda$81$lambda$80(MutableState $expanded$delegate) {
        TransactionItem$lambda$78($expanded$delegate, !TransactionItem$lambda$77($expanded$delegate));
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x09eb  */
    /* JADX WARN: Code duplicated, block: B:103:0x09f7  */
    /* JADX WARN: Code duplicated, block: B:104:0x09fd  */
    /* JADX WARN: Code duplicated, block: B:115:0x0aa1  */
    /* JADX WARN: Code duplicated, block: B:117:0x0b79  */
    /* JADX WARN: Code duplicated, block: B:120:0x0b85  */
    /* JADX WARN: Code duplicated, block: B:121:0x0b8b  */
    /* JADX WARN: Code duplicated, block: B:124:0x0bbc  */
    /* JADX WARN: Code duplicated, block: B:127:0x0bcf  */
    /* JADX WARN: Code duplicated, block: B:128:0x0bd2  */
    /* JADX WARN: Code duplicated, block: B:132:0x0cfe  */
    /* JADX WARN: Code duplicated, block: B:136:0x0d0b A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:139:0x0d52  */
    /* JADX WARN: Code duplicated, block: B:141:0x0dcd  */
    /* JADX WARN: Code duplicated, block: B:144:0x0dd9  */
    /* JADX WARN: Code duplicated, block: B:145:0x0ddf  */
    /* JADX WARN: Code duplicated, block: B:148:0x0e10  */
    /* JADX WARN: Code duplicated, block: B:151:0x0e23  */
    /* JADX WARN: Code duplicated, block: B:152:0x0e26  */
    /* JADX WARN: Code duplicated, block: B:157:0x0f56  */
    /* JADX WARN: Code duplicated, block: B:28:0x01de  */
    /* JADX WARN: Code duplicated, block: B:31:0x01ea  */
    /* JADX WARN: Code duplicated, block: B:32:0x01f0  */
    /* JADX WARN: Code duplicated, block: B:43:0x030d  */
    /* JADX WARN: Code duplicated, block: B:46:0x0319  */
    /* JADX WARN: Code duplicated, block: B:47:0x031f  */
    /* JADX WARN: Code duplicated, block: B:58:0x042b  */
    /* JADX WARN: Code duplicated, block: B:61:0x0437  */
    /* JADX WARN: Code duplicated, block: B:62:0x043d  */
    /* JADX WARN: Code duplicated, block: B:73:0x06d6  */
    /* JADX WARN: Code duplicated, block: B:79:0x06e7  */
    /* JADX WARN: Code duplicated, block: B:81:0x06ea  */
    /* JADX WARN: Code duplicated, block: B:82:0x0780  */
    /* JADX WARN: Code duplicated, block: B:85:0x087d  */
    /* JADX WARN: Code duplicated, block: B:88:0x0889  */
    /* JADX WARN: Code duplicated, block: B:89:0x088f  */
    static final Unit TransactionItem$lambda$102(final Transaction $transaction, final long $statusColor, Function0 $onCopySess, final String $statusLabel, final Function1 $onCopyCr, MutableState $expanded$delegate, Function0 $onDelete, Function0 $onCheckSingle, final Function0 $onToggleAutoPoll, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composer3;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composer4;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composer5;
        Composer composer6;
        Composer composer7;
        int currentCompositeKeyHash4;
        Function0<ComposeUiNode> constructor4;
        Function0<ComposeUiNode> function4;
        Composer composer8;
        int currentCompositeKeyHash5;
        Function0<ComposeUiNode> constructor5;
        Function0<ComposeUiNode> function5;
        Composer composer9;
        int currentCompositeKeyHash6;
        Function0<ComposeUiNode> constructor6;
        Function0<ComposeUiNode> function6;
        Composer composer10;
        Composer composer11;
        int currentCompositeKeyHash7;
        Function0<ComposeUiNode> constructor7;
        Function0<ComposeUiNode> function7;
        Composer composer12;
        Composer composer13;
        boolean zChanged;
        Object obj;
        String cr;
        boolean z;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C346@14669L12754:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(446909445, $changed, -1, "com.example.ui.screens.TransactionItem.<anonymous> (DashboardScreen.kt:346)");
            }
            Modifier modifier = PaddingKt.m١١٩٦padding3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash8 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor8 = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor8;
                $composer.createNode(function0);
            } else {
                function0 = constructor8;
                $composer.useNode();
            }
            Composer composer14 = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer14, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer14, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer14.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composer14.rememberedValue(), Integer.valueOf(currentCompositeKeyHash8))) {
                }
                Updater.m٤٤٩٥setimpl(composer14, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i2 = (i >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                int i3 = ((6 >> 6) & 112) | 6;
                ColumnScope columnScope = ColumnScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, -12363201, "C350@14796L3219,423@18029L41,490@21304L2143,486@21125L2322,539@23461L97,542@23637L3776:DashboardScreen.kt#2thlc2");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i4 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composer3 = Updater.m٤٤٨٨constructorimpl(composer2);
                Updater.m٤٤٩٥setimpl(composer3, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer3, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer3.getInserting() || !Intrinsics.areEqual(composer3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composer3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composer3.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m٤٤٩٥setimpl(composer3, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i5 = (i4 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i6 = ((438 >> 6) & 112) | 6;
                RowScope rowScope = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, 1585697209, "C355@15014L1667,398@17017L984,393@16731L1270:DashboardScreen.kt#2thlc2");
                Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i7 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composer4 = Updater.m٤٤٨٨constructorimpl(composer2);
                Updater.m٤٤٩٥setimpl(composer4, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer4, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer4.getInserting() || !Intrinsics.areEqual(composer4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composer4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composer4.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m٤٤٩٥setimpl(composer4, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i8 = (i7 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i9 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1198895718, "C356@15075L1268,385@16491L172:DashboardScreen.kt#2thlc2");
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier2 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifier2);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i10 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composer5 = Updater.m٤٤٨٨constructorimpl(composer2);
                Updater.m٤٤٩٥setimpl(composer5, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer5, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer5.getInserting() || !Intrinsics.areEqual(composer5.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    composer5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composer5.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                }
                Updater.m٤٤٩٥setimpl(composer5, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i11 = (i10 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i12 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1052642470, "C357@15153L234,363@15412L320,370@15757L39,371@15821L500:DashboardScreen.kt#2thlc2");
                TextKt.m٣٥٠٢Text4IGK_g("SESS: ", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 200070, 0, 131026);
                TextKt.m٣٥٠٢Text4IGK_g(StringsKt.take($transaction.getSess(), 12) + "...", (Modifier) null, ColorKt.getTextPrimaryDark(), TextUnitKt.getSp(14), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) FontFamily.INSTANCE.getMonospace(), 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 200064, 0, 130962);
                SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(6)), composer2, 6);
                IconButtonKt.IconButton($onCopySess, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(18)), false, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٩getLambda$980212778$app(), composer2, 196656, 28);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                TextKt.m٣٥٠٢Text4IGK_g("Added at: " + new SimpleDateFormat("HH:mm:ss dd/MM", Locale.getDefault()).format(new Date($transaction.getCreatedAt())), (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3456, 0, 131058);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SurfaceKt.m٣٣٤٦SurfaceT9BRK9s(PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8), 0.0f, 0.0f, 0.0f, 14, null), RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(12)), Color.m٥٠٦٧copywmQWz5c($statusColor, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl($statusColor) : 0.15f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl($statusColor) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl($statusColor) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl($statusColor) : 0.0f), 0L, 0.0f, 0.0f, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(CDp.m٧٩٥٨constructorimpl(1), Color.m٥٠٦٧copywmQWz5c($statusColor, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl($statusColor) : 0.4f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl($statusColor) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl($statusColor) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl($statusColor) : 0.0f)), ComposableLambdaKt.rememberComposableLambda(185510138, true, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return DashboardScreenKt.TransactionItem$lambda$102$lambda$101$lambda$86$lambda$85($transaction, $statusColor, $statusLabel, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 12582918, 56);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(12)), composer2, 6);
                if (Intrinsics.areEqual($transaction.getStatus(), "Success")) {
                    cr = $transaction.getCr();
                    if (cr != null || cr.length() == 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if (z) {
                        composer6 = composer2;
                        composer6.startReplaceGroup(-27432953);
                    } else {
                        composer2.startReplaceGroup(-9274207);
                        ComposerKt.sourceInformation(composer2, "428@18281L61,433@18575L2480,427@18233L2822");
                        CardDefaults cardDefaults = CardDefaults.INSTANCE;
                        long stateSuccess = ColorKt.getStateSuccess();
                        CardColors cardColors = cardDefaults.m٢٥٨٣cardColorsro_MJ88(Color.m٥٠٦٧copywmQWz5c(stateSuccess, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateSuccess) : 0.08f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateSuccess) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateSuccess) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateSuccess) : 0.0f), 0L, 0L, 0L, composer2, (CardDefaults.$stable << 12) | 6, 14);
                        composer6 = composer2;
                        float f = CDp.m٧٩٥٨constructorimpl(1);
                        long stateSuccess2 = ColorKt.getStateSuccess();
                        CardKt.Card(PaddingKt.m١١٩٨paddingVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), 0.0f, CDp.m٧٩٥٨constructorimpl(4), 1, null), null, cardColors, null, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(f, Color.m٥٠٦٧copywmQWz5c(stateSuccess2, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateSuccess2) : 0.25f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateSuccess2) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateSuccess2) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateSuccess2) : 0.0f)), ComposableLambdaKt.rememberComposableLambda(1552892936, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                return DashboardScreenKt.TransactionItem$lambda$102$lambda$101$lambda$91($transaction, $onCopyCr, (ColumnScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                            }
                        }, composer6, 54), composer6, 221190, 10);
                    }
                } else {
                    composer6 = composer2;
                    composer6.startReplaceGroup(-27432953);
                }
                composer6.endReplaceGroup();
                AnimatedVisibilityKt.AnimatedVisibility(columnScope, TransactionItem$lambda$77($expanded$delegate), (Modifier) null, EnterExitTransitionKt.fadeIn$default(null, 0.0f, 3, null).plus(EnterExitTransitionKt.expandVertically$default(null, null, false, null, 15, null)), EnterExitTransitionKt.fadeOut$default(null, 0.0f, 3, null).plus(EnterExitTransitionKt.shrinkVertically$default(null, null, false, null, 15, null)), (String) null, ComposableLambdaKt.rememberComposableLambda(-2023230765, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return DashboardScreenKt.TransactionItem$lambda$102$lambda$101$lambda$94($transaction, (AnimatedVisibilityScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                    }
                }, composer6, 54), composer6, (i3 & 14) | 1600512, 18);
                DividerKt.m٢٨٤٣Divider9IZ8Weo(PaddingKt.m١١٩٨paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, CDp.m٧٩٥٨constructorimpl(8), 1, null), CDp.m٧٩٥٨constructorimpl((float) 0.5d), ColorKt.getObsidianBorder(), composer6, 438, 0);
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
                composer7 = composer6;
                Composer composer15 = composer6;
                ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically3, composer7, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
                CompositionLocalMap currentCompositionLocalMap5 = composer7.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer7, modifierFillMaxWidth$default2);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i13 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer7.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer7.startReusableNode();
                if (composer7.getInserting()) {
                    function4 = constructor4;
                    composer7.createNode(function4);
                } else {
                    function4 = constructor4;
                    composer7.useNode();
                }
                composer8 = Updater.m٤٤٨٨constructorimpl(composer7);
                Updater.m٤٤٩٥setimpl(composer8, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer8, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer8.getInserting() || !Intrinsics.areEqual(composer8.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                    composer8.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                    composer8.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash5);
                }
                Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                int i14 = (i13 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i15 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -128629450, "C548@23888L461,562@24423L2976:DashboardScreen.kt#2thlc2");
                IconButtonKt.IconButton($onDelete, TestTagKt.testTag(SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36)), "delete_tx_button_" + $transaction.getId()), false, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٨getLambda$290641549$app(), composer7, ProfileVerifier.CompilationStatus.f٩٣٠xf2722a21, 28);
                Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
                Arrangement.Horizontal horizontal = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(12));
                ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier3 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(horizontal, centerVertically4, composer7, ((432 >> 3) & 14) | ((432 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
                CompositionLocalMap currentCompositionLocalMap6 = composer7.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer7, modifier3);
                constructor5 = ComposeUiNode.INSTANCE.getConstructor();
                int i16 = ((((432 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer7.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer7.startReusableNode();
                if (composer7.getInserting()) {
                    function5 = constructor5;
                    composer7.createNode(function5);
                } else {
                    function5 = constructor5;
                    composer7.useNode();
                }
                composer9 = Updater.m٤٤٨٨constructorimpl(composer7);
                Updater.m٤٤٩٥setimpl(composer9, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer9, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composer9.getInserting() || !Intrinsics.areEqual(composer9.rememberedValue(), Integer.valueOf(currentCompositeKeyHash5))) {
                    composer9.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
                    composer9.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash6);
                }
                Updater.m٤٤٩٥setimpl(composer9, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
                int i17 = (i16 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                int i18 = ((432 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, 1720124308, "C:DashboardScreen.kt#2thlc2");
                if (Intrinsics.areEqual($transaction.getStatus(), "Success")) {
                    composer7.startReplaceGroup(1722031892);
                    ComposerKt.sourceInformation(composer7, "601@26619L740");
                    Alignment.Vertical centerVertically5 = Alignment.INSTANCE.getCenterVertically();
                    ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                    Modifier modifier4 = Modifier.INSTANCE;
                    MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically5, composer7, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
                    CompositionLocalMap currentCompositionLocalMap7 = composer7.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composer7, modifier4);
                    constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                    int i19 = ((((384 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer7.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer7.startReusableNode();
                    if (composer7.getInserting()) {
                        function6 = constructor6;
                        composer7.createNode(function6);
                    } else {
                        function6 = constructor6;
                        composer7.useNode();
                    }
                    composer10 = Updater.m٤٤٨٨constructorimpl(composer7);
                    Updater.m٤٤٩٥setimpl(composer10, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m٤٤٩٥setimpl(composer10, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (composer10.getInserting()) {
                        composer11 = composer7;
                    } else {
                        composer11 = composer7;
                        if (!Intrinsics.areEqual(composer10.rememberedValue(), Integer.valueOf(currentCompositeKeyHash6))) {
                        }
                        Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
                        int i20 = (i19 >> 6) & 14;
                        ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
                        int i21 = ((384 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer7, -1364091063, "C602@26701L284,608@27014L39,609@27082L251:DashboardScreen.kt#2thlc2");
                        IconKt.m٢٩٣٤Iconww6aTOc(CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16)), ColorKt.getStateSuccess(), composer7, 3504, 0);
                        SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(4)), composer7, 6);
                        TextKt.m٣٥٠٢Text4IGK_g("Resolved", (Modifier) null, ColorKt.getStateSuccess(), TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 200070, 0, 131026);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        composer7.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        composer11.endReplaceGroup();
                    }
                    composer10.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
                    composer10.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash7);
                    Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
                    int i22 = (i19 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance5 = RowScopeInstance.INSTANCE;
                    int i23 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer7, -1364091063, "C602@26701L284,608@27014L39,609@27082L251:DashboardScreen.kt#2thlc2");
                    IconKt.m٢٩٣٤Iconww6aTOc(CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16)), ColorKt.getStateSuccess(), composer7, 3504, 0);
                    SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(4)), composer7, 6);
                    TextKt.m٣٥٠٢Text4IGK_g("Resolved", (Modifier) null, ColorKt.getStateSuccess(), TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 200070, 0, 131026);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    composer7.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    composer11.endReplaceGroup();
                } else {
                    composer7.startReplaceGroup(1720135250);
                    ComposerKt.sourceInformation(composer7, "570@24835L44,568@24718L601,579@25392L1173");
                    ButtonKt.TextButton($onCheckSingle, TestTagKt.testTag(Modifier.INSTANCE, "check_single_button_" + $transaction.getId()), false, null, ButtonDefaults.INSTANCE.m٢٥٧٤textButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, composer7, (ButtonDefaults.$stable << 12) | 48, 13), null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$1899194514$app(), composer7, 805306368, 492);
                    Alignment.Vertical centerVertically6 = Alignment.INSTANCE.getCenterVertically();
                    ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                    Modifier modifier5 = Modifier.INSTANCE;
                    MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically6, composer7, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
                    CompositionLocalMap currentCompositionLocalMap8 = composer7.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier8 = ComposedModifierKt.materializeModifier(composer7, modifier5);
                    constructor7 = ComposeUiNode.INSTANCE.getConstructor();
                    int i24 = ((((384 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer7.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer7.startReusableNode();
                    if (composer7.getInserting()) {
                        function7 = constructor7;
                        composer7.createNode(function7);
                    } else {
                        function7 = constructor7;
                        composer7.useNode();
                    }
                    composer12 = Updater.m٤٤٨٨constructorimpl(composer7);
                    Updater.m٤٤٩٥setimpl(composer12, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m٤٤٩٥setimpl(composer12, currentCompositionLocalMap8, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash8 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (composer12.getInserting()) {
                        composer13 = composer7;
                    } else {
                        composer13 = composer7;
                        if (!Intrinsics.areEqual(composer12.rememberedValue(), Integer.valueOf(currentCompositeKeyHash7))) {
                        }
                        Updater.m٤٤٩٥setimpl(composer12, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
                        int i25 = (i24 >> 6) & 14;
                        Composer composer16 = composer13;
                        ComposerKt.sourceInformationMarkerStart(composer16, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance6 = RowScopeInstance.INSTANCE;
                        int i26 = ((384 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer16, -1844126047, "C580@25474L268,589@25978L346,588@25898L22,586@25771L768:DashboardScreen.kt#2thlc2");
                        TextKt.m٣٥٠٢Text4IGK_g("Auto-Poll", PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, CDp.m٧٩٥٨constructorimpl(6), 0.0f, 11, null), ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer16, 3510, 0, 131056);
                        boolean zIsAutoPolling = $transaction.isAutoPolling();
                        SwitchDefaults switchDefaults = SwitchDefaults.INSTANCE;
                        long goldPrimary = ColorKt.getGoldPrimary();
                        long goldPrimary2 = ColorKt.getGoldPrimary();
                        SwitchColors switchColors = switchDefaults.m٣٣٧٨colorsV1nXRL4(goldPrimary, Color.m٥٠٦٧copywmQWz5c(goldPrimary2, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(goldPrimary2) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(goldPrimary2) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(goldPrimary2) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(goldPrimary2) : 0.0f), 0L, 0L, ColorKt.getTextSecondaryDark(), ColorKt.getObsidianDark(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer16, 221238, SwitchDefaults.$stable << 18, 65484);
                        Modifier modifierTestTag = TestTagKt.testTag(scale(Modifier.INSTANCE, 0.8f), "auto_poll_switch_" + $transaction.getId());
                        ComposerKt.sourceInformationMarkerStart(composer16, -1029306737, "CC(remember):DashboardScreen.kt#9igjgp");
                        zChanged = composer16.changed($onToggleAutoPoll);
                        Object objRememberedValue = composer16.rememberedValue();
                        if (!zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            obj = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda4
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return DashboardScreenKt.m٨٣٦٣x7cff1fe3($onToggleAutoPoll, ((Boolean) obj2).booleanValue());
                                }
                            };
                            composer16.updateRememberedValue(obj);
                        } else {
                            obj = objRememberedValue;
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer16);
                        SwitchKt.Switch(zIsAutoPolling, (Function1) obj, modifierTestTag, null, false, switchColors, null, composer16, 0, 88);
                        ComposerKt.sourceInformationMarkerEnd(composer16);
                        ComposerKt.sourceInformationMarkerEnd(composer16);
                        composer13.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer13);
                        ComposerKt.sourceInformationMarkerEnd(composer13);
                        ComposerKt.sourceInformationMarkerEnd(composer13);
                        composer7.endReplaceGroup();
                        composer11 = composer7;
                    }
                    composer12.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash7));
                    composer12.apply(Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash8);
                    Updater.m٤٤٩٥setimpl(composer12, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
                    int i27 = (i24 >> 6) & 14;
                    Composer composer17 = composer13;
                    ComposerKt.sourceInformationMarkerStart(composer17, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance7 = RowScopeInstance.INSTANCE;
                    int i28 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer17, -1844126047, "C580@25474L268,589@25978L346,588@25898L22,586@25771L768:DashboardScreen.kt#2thlc2");
                    TextKt.m٣٥٠٢Text4IGK_g("Auto-Poll", PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, CDp.m٧٩٥٨constructorimpl(6), 0.0f, 11, null), ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer17, 3510, 0, 131056);
                    boolean zIsAutoPolling2 = $transaction.isAutoPolling();
                    SwitchDefaults switchDefaults2 = SwitchDefaults.INSTANCE;
                    long goldPrimary3 = ColorKt.getGoldPrimary();
                    long goldPrimary4 = ColorKt.getGoldPrimary();
                    SwitchColors switchColors2 = switchDefaults2.m٣٣٧٨colorsV1nXRL4(goldPrimary3, Color.m٥٠٦٧copywmQWz5c(goldPrimary4, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(goldPrimary4) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(goldPrimary4) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(goldPrimary4) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(goldPrimary4) : 0.0f), 0L, 0L, ColorKt.getTextSecondaryDark(), ColorKt.getObsidianDark(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer17, 221238, SwitchDefaults.$stable << 18, 65484);
                    Modifier modifierTestTag2 = TestTagKt.testTag(scale(Modifier.INSTANCE, 0.8f), "auto_poll_switch_" + $transaction.getId());
                    ComposerKt.sourceInformationMarkerStart(composer17, -1029306737, "CC(remember):DashboardScreen.kt#9igjgp");
                    zChanged = composer17.changed($onToggleAutoPoll);
                    Object objRememberedValue2 = composer17.rememberedValue();
                    if (zChanged) {
                    }
                    obj = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return DashboardScreenKt.m٨٣٦٣x7cff1fe3($onToggleAutoPoll, ((Boolean) obj2).booleanValue());
                        }
                    };
                    composer17.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer17);
                    SwitchKt.Switch(zIsAutoPolling2, (Function1) obj, modifierTestTag2, null, false, switchColors2, null, composer17, 0, 88);
                    ComposerKt.sourceInformationMarkerEnd(composer17);
                    ComposerKt.sourceInformationMarkerEnd(composer17);
                    composer13.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer13);
                    ComposerKt.sourceInformationMarkerEnd(composer13);
                    ComposerKt.sourceInformationMarkerEnd(composer13);
                    composer7.endReplaceGroup();
                    composer11 = composer7;
                }
                ComposerKt.sourceInformationMarkerEnd(composer11);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                composer7.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                composer7.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer15);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composer14.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash8));
            composer14.apply(Integer.valueOf(currentCompositeKeyHash8), setCompositeKeyHash);
            Updater.m٤٤٩٥setimpl(composer14, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i29 = (i >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            int i30 = ((6 >> 6) & 112) | 6;
            ColumnScope columnScope2 = ColumnScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, -12363201, "C350@14796L3219,423@18029L41,490@21304L2143,486@21125L2322,539@23461L97,542@23637L3776:DashboardScreen.kt#2thlc2");
            Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween3 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically7 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy7 = RowKt.rowMeasurePolicy(spaceBetween3, centerVertically7, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap9 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier9 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default3);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i31 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composer3 = Updater.m٤٤٨٨constructorimpl(composer2);
            Updater.m٤٤٩٥setimpl(composer3, measurePolicyRowMeasurePolicy7, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer3, currentCompositionLocalMap9, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash9 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer3.getInserting()) {
            }
            composer3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composer3.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash9);
            Updater.m٤٤٩٥setimpl(composer3, modifierMaterializeModifier9, ComposeUiNode.INSTANCE.getSetModifier());
            int i32 = (i31 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i33 = ((438 >> 6) & 112) | 6;
            RowScope rowScope2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, 1585697209, "C355@15014L1667,398@17017L984,393@16731L1270:DashboardScreen.kt#2thlc2");
            Modifier modifierWeight$default2 = RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null);
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap10 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier10 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default2);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i34 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composer4 = Updater.m٤٤٨٨constructorimpl(composer2);
            Updater.m٤٤٩٥setimpl(composer4, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer4, currentCompositionLocalMap10, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash10 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer4.getInserting()) {
            }
            composer4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composer4.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash10);
            Updater.m٤٤٩٥setimpl(composer4, modifierMaterializeModifier10, ComposeUiNode.INSTANCE.getSetModifier());
            int i35 = (i34 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i36 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1198895718, "C356@15075L1268,385@16491L172:DashboardScreen.kt#2thlc2");
            Alignment.Vertical centerVertically8 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier6 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy8 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically8, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap11 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier11 = ComposedModifierKt.materializeModifier(composer2, modifier6);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i110 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function3 = constructor3;
                composer2.createNode(function3);
            } else {
                function3 = constructor3;
                composer2.useNode();
            }
            composer5 = Updater.m٤٤٨٨constructorimpl(composer2);
            Updater.m٤٤٩٥setimpl(composer5, measurePolicyRowMeasurePolicy8, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer5, currentCompositionLocalMap11, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash11 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer5.getInserting()) {
            }
            composer5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composer5.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash11);
            Updater.m٤٤٩٥setimpl(composer5, modifierMaterializeModifier11, ComposeUiNode.INSTANCE.getSetModifier());
            int i111 = (i110 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance8 = RowScopeInstance.INSTANCE;
            int i112 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1052642470, "C357@15153L234,363@15412L320,370@15757L39,371@15821L500:DashboardScreen.kt#2thlc2");
            TextKt.m٣٥٠٢Text4IGK_g("SESS: ", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 200070, 0, 131026);
            TextKt.m٣٥٠٢Text4IGK_g(StringsKt.take($transaction.getSess(), 12) + "...", (Modifier) null, ColorKt.getTextPrimaryDark(), TextUnitKt.getSp(14), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) FontFamily.INSTANCE.getMonospace(), 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 200064, 0, 130962);
            SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(6)), composer2, 6);
            IconButtonKt.IconButton($onCopySess, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(18)), false, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٩getLambda$980212778$app(), composer2, 196656, 28);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            TextKt.m٣٥٠٢Text4IGK_g("Added at: " + new SimpleDateFormat("HH:mm:ss dd/MM", Locale.getDefault()).format(new Date($transaction.getCreatedAt())), (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3456, 0, 131058);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SurfaceKt.m٣٣٤٦SurfaceT9BRK9s(PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8), 0.0f, 0.0f, 0.0f, 14, null), RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(12)), Color.m٥٠٦٧copywmQWz5c($statusColor, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl($statusColor) : 0.15f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl($statusColor) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl($statusColor) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl($statusColor) : 0.0f), 0L, 0.0f, 0.0f, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(CDp.m٧٩٥٨constructorimpl(1), Color.m٥٠٦٧copywmQWz5c($statusColor, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl($statusColor) : 0.4f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl($statusColor) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl($statusColor) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl($statusColor) : 0.0f)), ComposableLambdaKt.rememberComposableLambda(185510138, true, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return DashboardScreenKt.TransactionItem$lambda$102$lambda$101$lambda$86$lambda$85($transaction, $statusColor, $statusLabel, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer2, 54), composer2, 12582918, 56);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(12)), composer2, 6);
            if (Intrinsics.areEqual($transaction.getStatus(), "Success")) {
                composer6 = composer2;
                composer6.startReplaceGroup(-27432953);
            } else {
                cr = $transaction.getCr();
                if (cr != null) {
                    z = true;
                } else {
                    z = true;
                }
                if (z) {
                    composer2.startReplaceGroup(-9274207);
                    ComposerKt.sourceInformation(composer2, "428@18281L61,433@18575L2480,427@18233L2822");
                    CardDefaults cardDefaults2 = CardDefaults.INSTANCE;
                    long stateSuccess3 = ColorKt.getStateSuccess();
                    CardColors cardColors2 = cardDefaults2.m٢٥٨٣cardColorsro_MJ88(Color.m٥٠٦٧copywmQWz5c(stateSuccess3, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateSuccess3) : 0.08f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateSuccess3) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateSuccess3) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateSuccess3) : 0.0f), 0L, 0L, 0L, composer2, (CardDefaults.$stable << 12) | 6, 14);
                    composer6 = composer2;
                    float f2 = CDp.m٧٩٥٨constructorimpl(1);
                    long stateSuccess4 = ColorKt.getStateSuccess();
                    CardKt.Card(PaddingKt.m١١٩٨paddingVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), 0.0f, CDp.m٧٩٥٨constructorimpl(4), 1, null), null, cardColors2, null, BorderStrokeKt.m٦٩٤BorderStrokecXLIe8U(f2, Color.m٥٠٦٧copywmQWz5c(stateSuccess4, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateSuccess4) : 0.25f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateSuccess4) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateSuccess4) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateSuccess4) : 0.0f)), ComposableLambdaKt.rememberComposableLambda(1552892936, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj2, Object obj3, Object obj4) {
                            return DashboardScreenKt.TransactionItem$lambda$102$lambda$101$lambda$91($transaction, $onCopyCr, (ColumnScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }, composer6, 54), composer6, 221190, 10);
                } else {
                    composer6 = composer2;
                    composer6.startReplaceGroup(-27432953);
                }
            }
            composer6.endReplaceGroup();
            AnimatedVisibilityKt.AnimatedVisibility(columnScope2, TransactionItem$lambda$77($expanded$delegate), (Modifier) null, EnterExitTransitionKt.fadeIn$default(null, 0.0f, 3, null).plus(EnterExitTransitionKt.expandVertically$default(null, null, false, null, 15, null)), EnterExitTransitionKt.fadeOut$default(null, 0.0f, 3, null).plus(EnterExitTransitionKt.shrinkVertically$default(null, null, false, null, 15, null)), (String) null, ComposableLambdaKt.rememberComposableLambda(-2023230765, true, new Function3() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return DashboardScreenKt.TransactionItem$lambda$102$lambda$101$lambda$94($transaction, (AnimatedVisibilityScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, composer6, 54), composer6, (i30 & 14) | 1600512, 18);
            DividerKt.m٢٨٤٣Divider9IZ8Weo(PaddingKt.m١١٩٨paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, CDp.m٧٩٥٨constructorimpl(8), 1, null), CDp.m٧٩٥٨constructorimpl((float) 0.5d), ColorKt.getObsidianBorder(), composer6, 438, 0);
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween4 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically9 = Alignment.INSTANCE.getCenterVertically();
            composer7 = composer6;
            Composer composer18 = composer6;
            ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy9 = RowKt.rowMeasurePolicy(spaceBetween4, centerVertically9, composer7, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
            CompositionLocalMap currentCompositionLocalMap12 = composer7.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier12 = ComposedModifierKt.materializeModifier(composer7, modifierFillMaxWidth$default4);
            constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i113 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer7.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer7.startReusableNode();
            if (composer7.getInserting()) {
                function4 = constructor4;
                composer7.createNode(function4);
            } else {
                function4 = constructor4;
                composer7.useNode();
            }
            composer8 = Updater.m٤٤٨٨constructorimpl(composer7);
            Updater.m٤٤٩٥setimpl(composer8, measurePolicyRowMeasurePolicy9, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer8, currentCompositionLocalMap12, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash12 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer8.getInserting()) {
            }
            composer8.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composer8.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash12);
            Updater.m٤٤٩٥setimpl(composer8, modifierMaterializeModifier12, ComposeUiNode.INSTANCE.getSetModifier());
            int i114 = (i113 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance9 = RowScopeInstance.INSTANCE;
            int i115 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer7, -128629450, "C548@23888L461,562@24423L2976:DashboardScreen.kt#2thlc2");
            IconButtonKt.IconButton($onDelete, TestTagKt.testTag(SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(36)), "delete_tx_button_" + $transaction.getId()), false, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.m٨٣٥٨getLambda$290641549$app(), composer7, ProfileVerifier.CompilationStatus.f٩٣٠xf2722a21, 28);
            Alignment.Vertical centerVertically10 = Alignment.INSTANCE.getCenterVertically();
            Arrangement.Horizontal horizontal2 = Arrangement.INSTANCE.m١٠٤٤spacedBy0680j_4(CDp.m٧٩٥٨constructorimpl(12));
            ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier7 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy10 = RowKt.rowMeasurePolicy(horizontal2, centerVertically10, composer7, ((432 >> 3) & 14) | ((432 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
            CompositionLocalMap currentCompositionLocalMap13 = composer7.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier13 = ComposedModifierKt.materializeModifier(composer7, modifier7);
            constructor5 = ComposeUiNode.INSTANCE.getConstructor();
            int i116 = ((((432 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer7.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer7.startReusableNode();
            if (composer7.getInserting()) {
                function5 = constructor5;
                composer7.createNode(function5);
            } else {
                function5 = constructor5;
                composer7.useNode();
            }
            composer9 = Updater.m٤٤٨٨constructorimpl(composer7);
            Updater.m٤٤٩٥setimpl(composer9, measurePolicyRowMeasurePolicy10, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer9, currentCompositionLocalMap13, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash13 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composer9.getInserting()) {
            }
            composer9.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
            composer9.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash13);
            Updater.m٤٤٩٥setimpl(composer9, modifierMaterializeModifier13, ComposeUiNode.INSTANCE.getSetModifier());
            int i117 = (i116 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance10 = RowScopeInstance.INSTANCE;
            int i118 = ((432 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer7, 1720124308, "C:DashboardScreen.kt#2thlc2");
            if (Intrinsics.areEqual($transaction.getStatus(), "Success")) {
                composer7.startReplaceGroup(1720135250);
                ComposerKt.sourceInformation(composer7, "570@24835L44,568@24718L601,579@25392L1173");
                ButtonKt.TextButton($onCheckSingle, TestTagKt.testTag(Modifier.INSTANCE, "check_single_button_" + $transaction.getId()), false, null, ButtonDefaults.INSTANCE.m٢٥٧٤textButtonColorsro_MJ88(0L, ColorKt.getGoldPrimary(), 0L, 0L, composer7, (ButtonDefaults.$stable << 12) | 48, 13), null, null, null, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$1899194514$app(), composer7, 805306368, 492);
                Alignment.Vertical centerVertically11 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier8 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy11 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically11, composer7, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
                CompositionLocalMap currentCompositionLocalMap14 = composer7.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier14 = ComposedModifierKt.materializeModifier(composer7, modifier8);
                constructor7 = ComposeUiNode.INSTANCE.getConstructor();
                int i210 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer7.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer7.startReusableNode();
                if (composer7.getInserting()) {
                    function7 = constructor7;
                    composer7.createNode(function7);
                } else {
                    function7 = constructor7;
                    composer7.useNode();
                }
                composer12 = Updater.m٤٤٨٨constructorimpl(composer7);
                Updater.m٤٤٩٥setimpl(composer12, measurePolicyRowMeasurePolicy11, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer12, currentCompositionLocalMap14, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash14 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composer12.getInserting()) {
                    composer13 = composer7;
                    if (!Intrinsics.areEqual(composer12.rememberedValue(), Integer.valueOf(currentCompositeKeyHash7))) {
                    }
                    Updater.m٤٤٩٥setimpl(composer12, modifierMaterializeModifier14, ComposeUiNode.INSTANCE.getSetModifier());
                    int i211 = (i210 >> 6) & 14;
                    Composer composer19 = composer13;
                    ComposerKt.sourceInformationMarkerStart(composer19, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance11 = RowScopeInstance.INSTANCE;
                    int i212 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer19, -1844126047, "C580@25474L268,589@25978L346,588@25898L22,586@25771L768:DashboardScreen.kt#2thlc2");
                    TextKt.m٣٥٠٢Text4IGK_g("Auto-Poll", PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, CDp.m٧٩٥٨constructorimpl(6), 0.0f, 11, null), ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer19, 3510, 0, 131056);
                    boolean zIsAutoPolling3 = $transaction.isAutoPolling();
                    SwitchDefaults switchDefaults3 = SwitchDefaults.INSTANCE;
                    long goldPrimary5 = ColorKt.getGoldPrimary();
                    long goldPrimary6 = ColorKt.getGoldPrimary();
                    SwitchColors switchColors3 = switchDefaults3.m٣٣٧٨colorsV1nXRL4(goldPrimary5, Color.m٥٠٦٧copywmQWz5c(goldPrimary6, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(goldPrimary6) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(goldPrimary6) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(goldPrimary6) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(goldPrimary6) : 0.0f), 0L, 0L, ColorKt.getTextSecondaryDark(), ColorKt.getObsidianDark(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer19, 221238, SwitchDefaults.$stable << 18, 65484);
                    Modifier modifierTestTag3 = TestTagKt.testTag(scale(Modifier.INSTANCE, 0.8f), "auto_poll_switch_" + $transaction.getId());
                    ComposerKt.sourceInformationMarkerStart(composer19, -1029306737, "CC(remember):DashboardScreen.kt#9igjgp");
                    zChanged = composer19.changed($onToggleAutoPoll);
                    Object objRememberedValue3 = composer19.rememberedValue();
                    if (zChanged) {
                    }
                    obj = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return DashboardScreenKt.m٨٣٦٣x7cff1fe3($onToggleAutoPoll, ((Boolean) obj2).booleanValue());
                        }
                    };
                    composer19.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer19);
                    SwitchKt.Switch(zIsAutoPolling3, (Function1) obj, modifierTestTag3, null, false, switchColors3, null, composer19, 0, 88);
                    ComposerKt.sourceInformationMarkerEnd(composer19);
                    ComposerKt.sourceInformationMarkerEnd(composer19);
                    composer13.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer13);
                    ComposerKt.sourceInformationMarkerEnd(composer13);
                    ComposerKt.sourceInformationMarkerEnd(composer13);
                    composer7.endReplaceGroup();
                    composer11 = composer7;
                } else {
                    composer13 = composer7;
                }
                composer12.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash7));
                composer12.apply(Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash14);
                Updater.m٤٤٩٥setimpl(composer12, modifierMaterializeModifier14, ComposeUiNode.INSTANCE.getSetModifier());
                int i213 = (i210 >> 6) & 14;
                Composer composer110 = composer13;
                ComposerKt.sourceInformationMarkerStart(composer110, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance12 = RowScopeInstance.INSTANCE;
                int i214 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer110, -1844126047, "C580@25474L268,589@25978L346,588@25898L22,586@25771L768:DashboardScreen.kt#2thlc2");
                TextKt.m٣٥٠٢Text4IGK_g("Auto-Poll", PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, CDp.m٧٩٥٨constructorimpl(6), 0.0f, 11, null), ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer110, 3510, 0, 131056);
                boolean zIsAutoPolling4 = $transaction.isAutoPolling();
                SwitchDefaults switchDefaults4 = SwitchDefaults.INSTANCE;
                long goldPrimary7 = ColorKt.getGoldPrimary();
                long goldPrimary8 = ColorKt.getGoldPrimary();
                SwitchColors switchColors4 = switchDefaults4.m٣٣٧٨colorsV1nXRL4(goldPrimary7, Color.m٥٠٦٧copywmQWz5c(goldPrimary8, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(goldPrimary8) : 0.3f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(goldPrimary8) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(goldPrimary8) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(goldPrimary8) : 0.0f), 0L, 0L, ColorKt.getTextSecondaryDark(), ColorKt.getObsidianDark(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer110, 221238, SwitchDefaults.$stable << 18, 65484);
                Modifier modifierTestTag4 = TestTagKt.testTag(scale(Modifier.INSTANCE, 0.8f), "auto_poll_switch_" + $transaction.getId());
                ComposerKt.sourceInformationMarkerStart(composer110, -1029306737, "CC(remember):DashboardScreen.kt#9igjgp");
                zChanged = composer110.changed($onToggleAutoPoll);
                Object objRememberedValue4 = composer110.rememberedValue();
                if (zChanged) {
                }
                obj = new Function1() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return DashboardScreenKt.m٨٣٦٣x7cff1fe3($onToggleAutoPoll, ((Boolean) obj2).booleanValue());
                    }
                };
                composer110.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer110);
                SwitchKt.Switch(zIsAutoPolling4, (Function1) obj, modifierTestTag4, null, false, switchColors4, null, composer110, 0, 88);
                ComposerKt.sourceInformationMarkerEnd(composer110);
                ComposerKt.sourceInformationMarkerEnd(composer110);
                composer13.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer13);
                ComposerKt.sourceInformationMarkerEnd(composer13);
                ComposerKt.sourceInformationMarkerEnd(composer13);
                composer7.endReplaceGroup();
                composer11 = composer7;
            } else {
                composer7.startReplaceGroup(1722031892);
                ComposerKt.sourceInformation(composer7, "601@26619L740");
                Alignment.Vertical centerVertically12 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer7, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier9 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy12 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically12, composer7, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer7, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer7, 0);
                CompositionLocalMap currentCompositionLocalMap15 = composer7.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier15 = ComposedModifierKt.materializeModifier(composer7, modifier9);
                constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                int i119 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer7.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer7.startReusableNode();
                if (composer7.getInserting()) {
                    function6 = constructor6;
                    composer7.createNode(function6);
                } else {
                    function6 = constructor6;
                    composer7.useNode();
                }
                composer10 = Updater.m٤٤٨٨constructorimpl(composer7);
                Updater.m٤٤٩٥setimpl(composer10, measurePolicyRowMeasurePolicy12, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m٤٤٩٥setimpl(composer10, currentCompositionLocalMap15, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash15 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composer10.getInserting()) {
                    composer11 = composer7;
                    if (!Intrinsics.areEqual(composer10.rememberedValue(), Integer.valueOf(currentCompositeKeyHash6))) {
                    }
                    Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier15, ComposeUiNode.INSTANCE.getSetModifier());
                    int i215 = (i119 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance13 = RowScopeInstance.INSTANCE;
                    int i216 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer7, -1364091063, "C602@26701L284,608@27014L39,609@27082L251:DashboardScreen.kt#2thlc2");
                    IconKt.m٢٩٣٤Iconww6aTOc(CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16)), ColorKt.getStateSuccess(), composer7, 3504, 0);
                    SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(4)), composer7, 6);
                    TextKt.m٣٥٠٢Text4IGK_g("Resolved", (Modifier) null, ColorKt.getStateSuccess(), TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 200070, 0, 131026);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    composer7.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    composer11.endReplaceGroup();
                } else {
                    composer11 = composer7;
                }
                composer10.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
                composer10.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash15);
                Updater.m٤٤٩٥setimpl(composer10, modifierMaterializeModifier15, ComposeUiNode.INSTANCE.getSetModifier());
                int i217 = (i119 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance14 = RowScopeInstance.INSTANCE;
                int i218 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -1364091063, "C602@26701L284,608@27014L39,609@27082L251:DashboardScreen.kt#2thlc2");
                IconKt.m٢٩٣٤Iconww6aTOc(CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m١٢٦٦size3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(16)), ColorKt.getStateSuccess(), composer7, 3504, 0);
                SpacerKt.Spacer(SizeKt.m١٢٧١width3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(4)), composer7, 6);
                TextKt.m٣٥٠٢Text4IGK_g("Resolved", (Modifier) null, ColorKt.getStateSuccess(), TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 200070, 0, 131026);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                composer7.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                composer11.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer11);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            composer7.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            composer7.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer18);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit TransactionItem$lambda$102$lambda$101$lambda$86$lambda$85(Transaction $transaction, long $statusColor, String $statusLabel, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C399@17039L944:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(185510138, $changed, -1, "com.example.ui.screens.TransactionItem.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DashboardScreen.kt:399)");
            }
            Modifier modifier = PaddingKt.m١١٩٧paddingVpY3zN4(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8), CDp.m٧٩٥٨constructorimpl(4));
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer, ((390 >> 3) & 14) | ((390 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((390 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composer = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer.getInserting() || !Intrinsics.areEqual(composer.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composer.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composer.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m٤٤٩٥setimpl(composer, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            int i3 = ((390 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 198019016, "C412@17677L284:DashboardScreen.kt#2thlc2");
            if (Intrinsics.areEqual($transaction.getStatus(), "Polling")) {
                $composer.startReplaceGroup(198044993);
                ComposerKt.sourceInformation($composer, "404@17319L307");
                BoxKt.Box(BackgroundKt.m٦٦٧backgroundbw27NRU$default(ClipKt.clip(SizeKt.m١٢٦٦size3ABfNKs(PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, 0.0f, CDp.m٧٩٥٨constructorimpl(6), 0.0f, 11, null), CDp.m٧٩٥٨constructorimpl(8)), RoundedCornerShapeKt.getCircleShape()), $statusColor, null, 2, null), $composer, 0);
            } else {
                $composer.startReplaceGroup(180882060);
            }
            $composer.endReplaceGroup();
            TextKt.m٣٥٠٢Text4IGK_g($statusLabel, (Modifier) null, $statusColor, TextUnitKt.getSp(10), (FontStyle) null, FontWeight.INSTANCE.getBlack(), (FontFamily) null, TextUnitKt.getSp(0.5d), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 12782592, 0, 130898);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:51:0x0412  */
    static final Unit TransactionItem$lambda$102$lambda$101$lambda$91(final Transaction $transaction, final Function1 $onCopyCr, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Function0<ComposeUiNode> function1;
        RoundedCornerShape roundedCornerShape;
        Object obj;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C434@18597L2440:DashboardScreen.kt#2thlc2");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1552892936, $changed, -1, "com.example.ui.screens.TransactionItem.<anonymous>.<anonymous>.<anonymous> (DashboardScreen.kt:434)");
            }
            Modifier modifier = PaddingKt.m١١٩٦padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), CDp.m٧٩٥٨constructorimpl(12));
            Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor;
                $composer.createNode(function0);
            } else {
                function0 = constructor;
                $composer.useNode();
            }
            Composer composer = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer.getInserting() || !Intrinsics.areEqual(composer.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composer.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composer.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m٤٤٩٥setimpl(composer, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i3 = ((438 >> 6) & 112) | 6;
            RowScope rowScope = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart($composer, -1459978608, "C441@18928L962,463@20044L165,462@19962L28,461@19916L1099:DashboardScreen.kt#2thlc2");
            Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierWeight$default);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor2;
                $composer.createNode(function1);
            } else {
                function1 = constructor2;
                $composer.useNode();
            }
            Composer composer2 = Updater.m٤٤٨٨constructorimpl($composer);
            Updater.m٤٤٩٥setimpl(composer2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m٤٤٩٥setimpl(composer2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composer2.getInserting() || !Intrinsics.areEqual(composer2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                composer2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composer2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
            }
            Updater.m٤٤٩٥setimpl(composer2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i4 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i6 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 763114782, "C442@18997L331,449@19357L40,450@19426L438:DashboardScreen.kt#2thlc2");
            TextKt.m٣٥٠٢Text4IGK_g("CLIENT ID / OPERATOR ID RETURNED:", (Modifier) null, ColorKt.getStateSuccess(), TextUnitKt.getSp(9), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, TextUnitKt.getSp(0.5d), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 12782982, 0, 130898);
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(2)), $composer, 6);
            TextKt.m٣٥٠٢Text4IGK_g($transaction.getCr(), (Modifier) null, ColorKt.getTextPrimaryDark(), TextUnitKt.getSp(16), (FontStyle) null, FontWeight.INSTANCE.getBlack(), (FontFamily) FontFamily.INSTANCE.getMonospace(), 0L, (TextDecoration) null, (TextAlign) null, 0L, TextOverflow.INSTANCE.m٧٨٦٣getEllipsisgIe3tQ8(), false, 1, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200064, 3120, 120722);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ButtonColors buttonColors = ButtonDefaults.INSTANCE.m٢٥٦٣buttonColorsro_MJ88(ColorKt.getStateSuccess(), Color.INSTANCE.m٥١٠٦getWhite0d7_KjU(), 0L, 0L, $composer, (ButtonDefaults.$stable << 12) | 54, 12);
            PaddingValues paddingValues = PaddingKt.m١١٩٠PaddingValuesYgX7TsA(CDp.m٧٩٥٨constructorimpl(12), CDp.m٧٩٥٨constructorimpl(6));
            RoundedCornerShape roundedCornerShape2 = RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(4));
            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(32)), "copy_cr_button_" + $transaction.getId());
            ComposerKt.sourceInformationMarkerStart($composer, -878349048, "CC(remember):DashboardScreen.kt#9igjgp");
            boolean zChanged = $composer.changed($onCopyCr) | $composer.changed($transaction);
            Object objRememberedValue = $composer.rememberedValue();
            if (zChanged) {
                roundedCornerShape = roundedCornerShape2;
            } else {
                roundedCornerShape = roundedCornerShape2;
                if (objRememberedValue != Composer.INSTANCE.getEmpty()) {
                    obj = objRememberedValue;
                }
                ComposerKt.sourceInformationMarkerEnd($composer);
                ButtonKt.Button((Function0) obj, modifierTestTag, false, roundedCornerShape, buttonColors, null, null, paddingValues, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$1798087516$app(), $composer, 817889280, 356);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            obj = new Function0() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return DashboardScreenKt.m٨٣٦٤x32f6144($onCopyCr, $transaction);
                }
            };
            $composer.updateRememberedValue(obj);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ButtonKt.Button((Function0) obj, modifierTestTag, false, roundedCornerShape, buttonColors, null, null, paddingValues, null, ComposableSingletons$DashboardScreenKt.INSTANCE.getLambda$1798087516$app(), $composer, 817889280, 356);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: TransactionItem$lambda$102$lambda$101$lambda$91$lambda$90$lambda$89$lambda$88, reason: contains not printable characters */
    static final Unit m٨٣٦٤x32f6144(Function1 $onCopyCr, Transaction $transaction) {
        $onCopyCr.invoke($transaction.getCr());
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:23:0x01e6  */
    /* JADX WARN: Code duplicated, block: B:24:0x026d  */
    /* JADX WARN: Code duplicated, block: B:31:0x0288  */
    /* JADX WARN: Code duplicated, block: B:33:0x028c  */
    /* JADX WARN: Code duplicated, block: B:34:0x0303  */
    /* JADX WARN: Code duplicated, block: B:37:0x033f  */
    static final Unit TransactionItem$lambda$102$lambda$101$lambda$94(final Transaction $transaction, AnimatedVisibilityScope AnimatedVisibility, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        Composer composer;
        String lastErrorMessage;
        boolean z;
        Intrinsics.checkNotNullParameter(AnimatedVisibility, "$this$AnimatedVisibility");
        ComposerKt.sourceInformation($composer, "C491@21322L2111:DashboardScreen.kt#2thlc2");
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventStart(-2023230765, $changed, -1, "com.example.ui.screens.TransactionItem.<anonymous>.<anonymous>.<anonymous> (DashboardScreen.kt:491)");
        }
        Modifier modifier = PaddingKt.m١٢٠٠paddingqDBjuR0$default(Modifier.INSTANCE, 0.0f, CDp.m٧٩٥٨constructorimpl(10), 0.0f, 0.0f, 13, null);
        ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
        MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
        ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
        int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
        CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
        Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
        Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
        int i2 = ((((6 << 3) & 112) << 6) & 896) | 6;
        ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
        if (!($composer.getApplier() instanceof Applier)) {
            ComposablesKt.invalidApplier();
        }
        $composer.startReusableNode();
        if ($composer.getInserting()) {
            function0 = constructor;
            $composer.createNode(function0);
        } else {
            function0 = constructor;
            $composer.useNode();
        }
        Composer composer2 = Updater.m٤٤٨٨constructorimpl($composer);
        Updater.m٤٤٩٥setimpl(composer2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
        Updater.m٤٤٩٥setimpl(composer2, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
        Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
        if (!composer2.getInserting()) {
            i = 6;
            if (!Intrinsics.areEqual(composer2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
            }
            Updater.m٤٤٩٥setimpl(composer2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i3 = (i2 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i4 = ((i >> 6) & 112) | 6;
            composer = $composer;
            ComposerKt.sourceInformationMarkerStart(composer, 1165908660, "C492@21393L49,493@21463L41,495@21526L223,501@21770L322,535@23374L41:DashboardScreen.kt#2thlc2");
            DividerKt.m٢٨٤٣Divider9IZ8Weo(null, CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder(), $composer, 432, 1);
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(10)), composer, 6);
            TextKt.m٣٥٠٢Text4IGK_g("Full Token Key:", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer, 200070, 0, 131026);
            TextKt.m٣٥٠٢Text4IGK_g($transaction.getToken(), (Modifier) null, ColorKt.getTextPrimaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) FontFamily.INSTANCE.getMonospace(), 0L, (TextDecoration) null, (TextAlign) null, 0L, TextOverflow.INSTANCE.m٧٨٦٣getEllipsisgIe3tQ8(), false, 3, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer, 3456, 3120, 120754);
            if ($transaction.getLastCheckedAt() > 0) {
                composer.startReplaceGroup(1166609848);
                ComposerKt.sourceInformation(composer, "511@22175L40,513@22379L197");
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer, 6);
                TextKt.m٣٥٠٢Text4IGK_g("Last Checked: " + new SimpleDateFormat("HH:mm:ss dd/MM", Locale.getDefault()).format(new Date($transaction.getLastCheckedAt())), (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer, 3456, 0, 131058);
                composer = composer;
            } else {
                composer.startReplaceGroup(1144623129);
            }
            composer.endReplaceGroup();
            lastErrorMessage = $transaction.getLastErrorMessage();
            if (lastErrorMessage != null || lastErrorMessage.length() == 0) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                composer.startReplaceGroup(1144623129);
            } else {
                composer.startReplaceGroup(1167134895);
                ComposerKt.sourceInformation(composer, "521@22697L40,526@22989L342,522@22762L569");
                SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer, 6);
                long stateError = ColorKt.getStateError();
                SurfaceKt.m٣٣٤٦SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(4)), Color.m٥٠٦٧copywmQWz5c(stateError, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateError) : 0.1f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateError) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateError) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateError) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-899427210, true, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda18
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return DashboardScreenKt.m٨٣٦٥xb5d7a89($transaction, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer, 54), composer, 12583302, 120);
            }
            composer.endReplaceGroup();
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(10)), composer, 6);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            r4.endNode();
            ComposerKt.sourceInformationMarkerEnd(r4);
            ComposerKt.sourceInformationMarkerEnd(r4);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            return Unit.INSTANCE;
        }
        i = 6;
        composer2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
        composer2.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
        Updater.m٤٤٩٥setimpl(composer2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
        int i5 = (i2 >> 6) & 14;
        ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
        ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
        int i6 = ((i >> 6) & 112) | 6;
        composer = $composer;
        ComposerKt.sourceInformationMarkerStart(composer, 1165908660, "C492@21393L49,493@21463L41,495@21526L223,501@21770L322,535@23374L41:DashboardScreen.kt#2thlc2");
        DividerKt.m٢٨٤٣Divider9IZ8Weo(null, CDp.m٧٩٥٨constructorimpl(1), ColorKt.getObsidianBorder(), $composer, 432, 1);
        SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(10)), composer, 6);
        TextKt.m٣٥٠٢Text4IGK_g("Full Token Key:", (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer, 200070, 0, 131026);
        TextKt.m٣٥٠٢Text4IGK_g($transaction.getToken(), (Modifier) null, ColorKt.getTextPrimaryDark(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) FontFamily.INSTANCE.getMonospace(), 0L, (TextDecoration) null, (TextAlign) null, 0L, TextOverflow.INSTANCE.m٧٨٦٣getEllipsisgIe3tQ8(), false, 3, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer, 3456, 3120, 120754);
        if ($transaction.getLastCheckedAt() > 0) {
            composer.startReplaceGroup(1166609848);
            ComposerKt.sourceInformation(composer, "511@22175L40,513@22379L197");
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer, 6);
            TextKt.m٣٥٠٢Text4IGK_g("Last Checked: " + new SimpleDateFormat("HH:mm:ss dd/MM", Locale.getDefault()).format(new Date($transaction.getLastCheckedAt())), (Modifier) null, ColorKt.getTextSecondaryDark(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer, 3456, 0, 131058);
            composer = composer;
        } else {
            composer.startReplaceGroup(1144623129);
        }
        composer.endReplaceGroup();
        lastErrorMessage = $transaction.getLastErrorMessage();
        if (lastErrorMessage != null) {
            z = true;
        } else {
            z = true;
        }
        if (z) {
            composer.startReplaceGroup(1167134895);
            ComposerKt.sourceInformation(composer, "521@22697L40,526@22989L342,522@22762L569");
            SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), composer, 6);
            long stateError2 = ColorKt.getStateError();
            SurfaceKt.m٣٣٤٦SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m١٥٧١RoundedCornerShape0680j_4(CDp.m٧٩٥٨constructorimpl(4)), Color.m٥٠٦٧copywmQWz5c(stateError2, (14 & 1) != 0 ? Color.m٥٠٧١getAlphaimpl(stateError2) : 0.1f, (14 & 2) != 0 ? Color.m٥٠٧٥getRedimpl(stateError2) : 0.0f, (14 & 4) != 0 ? Color.m٥٠٧٤getGreenimpl(stateError2) : 0.0f, (14 & 8) != 0 ? Color.m٥٠٧٢getBlueimpl(stateError2) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-899427210, true, new Function2() { // from class: com.example.ui.screens.DashboardScreenKt$$ExternalSyntheticLambda18
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return DashboardScreenKt.m٨٣٦٥xb5d7a89($transaction, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, composer, 54), composer, 12583302, 120);
        } else {
            composer.startReplaceGroup(1144623129);
        }
        composer.endReplaceGroup();
        SpacerKt.Spacer(SizeKt.m١٢٥٢height3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(10)), composer, 6);
        ComposerKt.sourceInformationMarkerEnd(composer);
        ComposerKt.sourceInformationMarkerEnd($composer);
        r4.endNode();
        ComposerKt.sourceInformationMarkerEnd(r4);
        ComposerKt.sourceInformationMarkerEnd(r4);
        ComposerKt.sourceInformationMarkerEnd($composer);
        if (ComposerKt.isTraceInProgress()) {
            ComposerKt.traceEventEnd();
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: TransactionItem$lambda$102$lambda$101$lambda$94$lambda$93$lambda$92, reason: contains not printable characters */
    static final Unit m٨٣٦٥xb5d7a89(Transaction $transaction, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C527@23019L286:DashboardScreen.kt#2thlc2");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-899427210, $changed, -1, "com.example.ui.screens.TransactionItem.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DashboardScreen.kt:527)");
            }
            TextKt.m٣٥٠٢Text4IGK_g("Message: " + $transaction.getLastErrorMessage(), PaddingKt.m١١٩٦padding3ABfNKs(Modifier.INSTANCE, CDp.m٧٩٥٨constructorimpl(8)), ColorKt.getStateError(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3504, 0, 131056);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX INFO: renamed from: TransactionItem$lambda$102$lambda$101$lambda$100$lambda$99$lambda$97$lambda$96$lambda$95, reason: contains not printable characters */
    static final Unit m٨٣٦٣x7cff1fe3(Function0 $onToggleAutoPoll, boolean it) {
        $onToggleAutoPoll.invoke();
        return Unit.INSTANCE;
    }

    private static final Modifier scale(Modifier $this$scale, float scale) {
        new Matrix().setScale(scale, scale);
        return $this$scale.then(Modifier.INSTANCE);
    }
}
