package com.example.p٠١٩ui.screens;

import com.example.util.DebugLog;
import java.net.URL;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: BookerBridge.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0011\n\u0002\u0010\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J.\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0005R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\u0007\"\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\u0007\"\u0004\b\f\u0010\tR\u001a\u0010\r\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u0007\"\u0004\b\u000f\u0010\tR\u001a\u0010\u0010\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0007\"\u0004\b\u0012\u0010\tR\u001a\u0010\u0013\u001a\u00020\u0005X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0007\"\u0004\b\u0015\u0010\t¨\u0006\u001a"}, m٨٧٩٩d2 = {"Lcom/example/ui/screens/Spoof;", "", "<init>", "()V", "ip", "", "getIp", "()Ljava/lang/String;", "setIp", "(Ljava/lang/String;)V", "ozHost", "getOzHost", "setOzHost", "fakeUa", "getFakeUa", "setFakeUa", "blsHost", "getBlsHost", "setBlsHost", "proxyline", "getProxyline", "setProxyline", "save", "", "ozPlugin", "ua", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class Spoof {
    public static final Spoof INSTANCE = new Spoof();
    private static volatile String ip = "";
    private static volatile String ozHost = "";
    private static volatile String fakeUa = "";
    private static volatile String blsHost = "";
    private static volatile String proxyline = "";
    public static final int $stable = 8;

    private Spoof() {
    }

    public final String getIp() {
        return ip;
    }

    public final void setIp(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        ip = str;
    }

    public final String getOzHost() {
        return ozHost;
    }

    public final void setOzHost(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        ozHost = str;
    }

    public final String getFakeUa() {
        return fakeUa;
    }

    public final void setFakeUa(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        fakeUa = str;
    }

    public final String getBlsHost() {
        return blsHost;
    }

    public final void setBlsHost(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        blsHost = str;
    }

    public final String getProxyline() {
        return proxyline;
    }

    public final void setProxyline(String str) {
        Intrinsics.checkNotNullParameter(str, "<set-?>");
        proxyline = str;
    }

    public final void save(String ip2, String ozPlugin, String ua, String blsHost2, String proxyline2) {
        String str = "";
        Intrinsics.checkNotNullParameter(ip2, "ip");
        Intrinsics.checkNotNullParameter(ozPlugin, "ozPlugin");
        Intrinsics.checkNotNullParameter(ua, "ua");
        Intrinsics.checkNotNullParameter(blsHost2, "blsHost");
        Intrinsics.checkNotNullParameter(proxyline2, "proxyline");
        ip = StringsKt.trim((CharSequence) ip2).toString();
        fakeUa = StringsKt.trim((CharSequence) ua).toString();
        blsHost = StringsKt.trim((CharSequence) blsHost2).toString();
        proxyline = StringsKt.trim((CharSequence) proxyline2).toString();
        try {
            String host = !StringsKt.isBlank(ozPlugin) ? new URL(ozPlugin).getHost() : "";
            Intrinsics.checkNotNull(host);
            str = host;
        } catch (Exception e) {
        }
        ozHost = str;
        DebugLog.INSTANCE.add("SPOOF", "ip=" + ip2 + " ozHost=" + ozHost + " ua=" + StringsKt.take(ua, 40) + "… blsHost=" + blsHost2 + " proxyline=" + proxyline2);
    }
}
