package com.example.p٠١٩ui.theme;

import kotlin.Metadata;

/* JADX INFO: compiled from: Color.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001e\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0013\u0010\u000b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0013\u0010\r\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\"\u0013\u0010\u000f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0010\u0010\u0003\"\u0013\u0010\u0011\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0012\u0010\u0003\"\u0013\u0010\u0013\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0014\u0010\u0003\"\u0013\u0010\u0015\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0016\u0010\u0003\"\u0013\u0010\u0017\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0018\u0010\u0003\"\u0013\u0010\u0019\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001a\u0010\u0003\"\u0013\u0010\u001b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001c\u0010\u0003\"\u0013\u0010\u001d\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001e\u0010\u0003¨\u0006\u001f"}, m٨٧٩٩d2 = {"ObsidianDark", "Landroidx/compose/ui/graphics/Color;", "getObsidianDark", "()J", "J", "ObsidianSurface", "getObsidianSurface", "ObsidianSurfaceElevated", "getObsidianSurfaceElevated", "ObsidianBorder", "getObsidianBorder", "GoldPrimary", "getGoldPrimary", "GoldSecondary", "getGoldSecondary", "GoldTertiary", "getGoldTertiary", "StateSuccess", "getStateSuccess", "StateError", "getStateError", "StatePolling", "getStatePolling", "StatePending", "getStatePending", "TextPrimaryDark", "getTextPrimaryDark", "TextSecondaryDark", "getTextSecondaryDark", "TextOnGold", "getTextOnGold", "app"}, m٨٨٠٠k = 2, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class ColorKt {
    private static final long ObsidianDark = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4278979598L);
    private static final long ObsidianSurface = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4279505944L);
    private static final long ObsidianSurfaceElevated = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4280032548L);
    private static final long ObsidianBorder = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4280822324L);
    private static final long GoldPrimary = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4294956800L);
    private static final long GoldSecondary = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4293247232L);
    private static final long GoldTertiary = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4289958400L);
    private static final long StateSuccess = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4281257073L);
    private static final long StateError = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4293348412L);
    private static final long StatePolling = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4294155282L);
    private static final long StatePending = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4287997350L);
    private static final long TextPrimaryDark = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4293980405L);
    private static final long TextSecondaryDark = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4288718261L);
    private static final long TextOnGold = androidx.compose.p٠١٤ui.graphics.ColorKt.Color(4278716426L);

    public static final long getObsidianDark() {
        return ObsidianDark;
    }

    public static final long getObsidianSurface() {
        return ObsidianSurface;
    }

    public static final long getObsidianSurfaceElevated() {
        return ObsidianSurfaceElevated;
    }

    public static final long getObsidianBorder() {
        return ObsidianBorder;
    }

    public static final long getGoldPrimary() {
        return GoldPrimary;
    }

    public static final long getGoldSecondary() {
        return GoldSecondary;
    }

    public static final long getGoldTertiary() {
        return GoldTertiary;
    }

    public static final long getStateSuccess() {
        return StateSuccess;
    }

    public static final long getStateError() {
        return StateError;
    }

    public static final long getStatePolling() {
        return StatePolling;
    }

    public static final long getStatePending() {
        return StatePending;
    }

    public static final long getTextPrimaryDark() {
        return TextPrimaryDark;
    }

    public static final long getTextSecondaryDark() {
        return TextSecondaryDark;
    }

    public static final long getTextOnGold() {
        return TextOnGold;
    }
}
