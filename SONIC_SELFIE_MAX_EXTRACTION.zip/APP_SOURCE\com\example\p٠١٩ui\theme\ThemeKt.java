package com.example.p٠١٩ui.theme;

import androidx.compose.foundation.DarkThemeKt;
import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.MaterialThemeKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Theme.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a*\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u0011\u0010\u0006\u001a\r\u0012\u0004\u0012\u00020\u00030\u0007¢\u0006\u0002\b\bH\u0007¢\u0006\u0002\u0010\t\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\n"}, m٨٧٩٩d2 = {"DarkColorScheme", "Landroidx/compose/material3/ColorScheme;", "MyApplicationTheme", "", "darkTheme", "", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(ZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "app"}, m٨٨٠٠k = 2, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class ThemeKt {
    private static final ColorScheme DarkColorScheme = ColorSchemeKt.m٢٦٩٨darkColorSchemeCXl9yA$default(ColorKt.getGoldPrimary(), ColorKt.getTextOnGold(), ColorKt.getGoldTertiary(), ColorKt.getTextPrimaryDark(), 0, ColorKt.getGoldSecondary(), ColorKt.getTextOnGold(), 0, 0, ColorKt.getGoldTertiary(), ColorKt.getTextPrimaryDark(), 0, 0, ColorKt.getObsidianDark(), ColorKt.getTextPrimaryDark(), ColorKt.getObsidianSurface(), ColorKt.getTextPrimaryDark(), ColorKt.getObsidianSurfaceElevated(), ColorKt.getTextSecondaryDark(), 0, 0, 0, 0, 0, 0, 0, ColorKt.getObsidianBorder(), 0, 0, 0, 0, 0, 0, 0, 0, 0, -67626608, 15, null);

    static final Unit MyApplicationTheme$lambda$0(boolean z, Function2 function2, int i, int i2, Composer composer, int i3) {
        MyApplicationTheme(z, function2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    public static final void MyApplicationTheme(final boolean darkTheme, Function2<? super Composer, ? super Integer, Unit> content, Composer $composer, final int $changed, final int i) {
        final Function2<? super Composer, ? super Integer, Unit> function2;
        Intrinsics.checkNotNullParameter(content, "content");
        Composer $composer2 = $composer.startRestartGroup(-2046409659);
        ComposerKt.sourceInformation($composer2, "C(MyApplicationTheme)P(1)32@1062L118:Theme.kt#75kw8w");
        int $dirty = $changed;
        if (($changed & 48) == 0) {
            $dirty |= $composer2.changedInstance(content) ? 32 : 16;
        }
        if (($dirty & 17) == 16 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            function2 = content;
        } else {
            $composer2.startDefaults();
            ComposerKt.sourceInformation($composer2, "28@886L21");
            if (($changed & 1) != 0 && !$composer2.getDefaultsInvalid()) {
                $composer2.skipToGroupEnd();
                if ((i & 1) != 0) {
                    $dirty &= -15;
                }
            } else if ((i & 1) != 0) {
                darkTheme = DarkThemeKt.isSystemInDarkTheme($composer2, 0);
                $dirty &= -15;
            }
            $composer2.endDefaults();
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-2046409659, $dirty, -1, "com.example.ui.theme.MyApplicationTheme (Theme.kt:30)");
            }
            function2 = content;
            MaterialThemeKt.MaterialTheme(DarkColorScheme, null, TypeKt.getTypography(), function2, $composer2, (($dirty << 6) & 7168) | 390, 2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return ThemeKt.MyApplicationTheme$lambda$0(darkTheme, function2, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }
}
