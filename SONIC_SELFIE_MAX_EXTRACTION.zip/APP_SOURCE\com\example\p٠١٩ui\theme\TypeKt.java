package com.example.p٠١٩ui.theme;

import androidx.compose.material3.Typography;
import androidx.compose.p٠١٤ui.graphics.Shadow;
import androidx.compose.p٠١٤ui.graphics.drawscope.DrawStyle;
import androidx.compose.p٠١٤ui.text.PlatformTextStyle;
import androidx.compose.p٠١٤ui.text.TextStyle;
import androidx.compose.p٠١٤ui.text.font.FontFamily;
import androidx.compose.p٠١٤ui.text.font.FontStyle;
import androidx.compose.p٠١٤ui.text.font.FontSynthesis;
import androidx.compose.p٠١٤ui.text.font.FontWeight;
import androidx.compose.p٠١٤ui.text.font.SystemFontFamily;
import androidx.compose.p٠١٤ui.text.intl.LocaleList;
import androidx.compose.p٠١٤ui.text.style.BaselineShift;
import androidx.compose.p٠١٤ui.text.style.LineHeightStyle;
import androidx.compose.p٠١٤ui.text.style.TextDecoration;
import androidx.compose.p٠١٤ui.text.style.TextGeometricTransform;
import androidx.compose.p٠١٤ui.text.style.TextIndent;
import androidx.compose.p٠١٤ui.text.style.TextMotion;
import androidx.compose.p٠١٤ui.unit.TextUnitKt;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

/* JADX INFO: compiled from: Type.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0011\u0010\u0000\u001a\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, m٨٧٩٩d2 = {"Typography", "Landroidx/compose/material3/Typography;", "getTypography", "()Landroidx/compose/material3/Typography;", "app"}, m٨٨٠٠k = 2, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class TypeKt {
    private static final Typography Typography;

    public static final Typography getTypography() {
        return Typography;
    }

    static {
        SystemFontFamily systemFontFamily = FontFamily.INSTANCE.getDefault();
        FontWeight normal = FontWeight.INSTANCE.getNormal();
        SystemFontFamily systemFontFamily2 = systemFontFamily;
        Typography = new Typography(null, null, null, null, null, null, null, null, null, new TextStyle(0L, TextUnitKt.getSp(16), normal, (FontStyle) null, (FontSynthesis) null, systemFontFamily2, (String) null, TextUnitKt.getSp(0.5d), (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, TextUnitKt.getSp(24), (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16645977, (DefaultConstructorMarker) null), null, null, null, null, null, 32255, null);
    }
}
