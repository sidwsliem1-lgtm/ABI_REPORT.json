package com.example.p٠١٩ui.viewmodel;

import com.example.data.model.Transaction;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: TransactionViewModel.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
@DebugMetadata(m١٠٠٢٥c = "com.example.ui.viewmodel.TransactionViewModel$startPollingJob$job$1", m١٠٠٢٦f = "TransactionViewModel.kt", m١٠٠٢٧i = {1, 2, 2}, m١٠٠٢٨l = {354, 359, 371}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {"currentTx", "currentTx", "result"}, m١٠٠٣١s = {"L$0", "L$0", "L$1"})
final class TransactionViewModel$startPollingJob$job$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ Transaction $transaction;
    Object L$0;
    Object L$1;
    int label;
    final /* synthetic */ TransactionViewModel this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    TransactionViewModel$startPollingJob$job$1(Transaction transaction, TransactionViewModel transactionViewModel, Continuation<? super TransactionViewModel$startPollingJob$job$1> continuation) {
        super(2, continuation);
        this.$transaction = transaction;
        this.this$0 = transactionViewModel;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new TransactionViewModel$startPollingJob$job$1(this.$transaction, this.this$0, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((TransactionViewModel$startPollingJob$job$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0087 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:13:0x0088  */
    /* JADX WARN: Code duplicated, block: B:16:0x0091  */
    /* JADX WARN: Code duplicated, block: B:23:0x00c9 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:24:0x00ca  */
    /* JADX WARN: Code duplicated, block: B:27:0x00d7  */
    /* JADX WARN: Code duplicated, block: B:29:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:30:0x00df  */
    /* JADX WARN: Code duplicated, block: B:33:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:37:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:41:0x0101  */
    /* JADX WARN: Code duplicated, block: B:43:0x0104  */
    /* JADX WARN: Code duplicated, block: B:46:0x0132 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:47:0x0133  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:47:0x0133 -> B:48:0x0136). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object r12) {
        /*
            Method dump skipped, instruction units count: 348
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.p٠١٩ui.viewmodel.TransactionViewModel$startPollingJob$job$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
