package com.example.p٠١٩ui.viewmodel;

import android.app.Application;
import android.content.SharedPreferences;
import android.util.Base64;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.ViewModelKt;
import com.example.data.api.AchatNetworkClient;
import com.example.data.api.SyncCodeResponse;
import com.example.data.model.Transaction;
import com.example.data.p٠١٨db.AppDatabase;
import com.example.data.repository.TransactionRepository;
import com.google.android.gms.common.internal.ImagesContract;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.flow.FlowCollector;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.SharingStarted;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* JADX INFO: compiled from: TransactionViewModel.kt */
/* JADX INFO: loaded from: classes9.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u000f\b\u0007\u0018\u00002\u00020\u0001:\u0001DB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u000eJ\u0006\u0010\u001f\u001a\u00020\u001dJF\u0010 \u001a\u00020\u001d2\u0006\u0010!\u001a\u00020\u000e26\u0010\"\u001a2\u0012\u0013\u0012\u00110$¢\u0006\f\b%\u0012\b\b&\u0012\u0004\b\b('\u0012\u0013\u0012\u00110\u000e¢\u0006\f\b%\u0012\b\b&\u0012\u0004\b\b((\u0012\u0004\u0012\u00020\u001d0#J\u0016\u00100\u001a\u00020\u001d2\u0006\u00101\u001a\u00020\u000e2\u0006\u00102\u001a\u00020\u0016J\u0012\u00103\u001a\u0004\u0018\u00010\u000e2\u0006\u00104\u001a\u00020\u000eH\u0002J\u000e\u00105\u001a\u0002062\u0006\u00107\u001a\u00020\u000eJ \u00108\u001a\u00020\u001d2\u0006\u00109\u001a\u00020\u000e2\u0006\u0010:\u001a\u00020\u000e2\b\b\u0002\u0010;\u001a\u00020$J\u000e\u0010<\u001a\u00020\u001d2\u0006\u0010=\u001a\u00020+J\u000e\u0010>\u001a\u00020\u001d2\u0006\u0010=\u001a\u00020+J\u000e\u0010?\u001a\u00020\u001d2\u0006\u0010=\u001a\u00020+J\u0010\u0010@\u001a\u00020\u001d2\u0006\u0010=\u001a\u00020+H\u0002J\u0010\u0010A\u001a\u00020\u001d2\u0006\u0010B\u001a\u00020\u0016H\u0002J\b\u0010C\u001a\u00020\u001dH\u0014R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\n\u001a\n \f*\u0004\u0018\u00010\u000b0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082D¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00160\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00160\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0016\u0010\u0019\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u001a\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0014R\u001d\u0010)\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020+0*0\u0012¢\u0006\b\n\u0000\u001a\u0004\b,\u0010\u0014R\u001a\u0010-\u001a\u000e\u0012\u0004\u0012\u00020\u0016\u0012\u0004\u0012\u00020/0.X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006E"}, m٨٧٩٩d2 = {"Lcom/example/ui/viewmodel/TransactionViewModel;", "Landroidx/lifecycle/AndroidViewModel;", "application", "Landroid/app/Application;", "<init>", "(Landroid/app/Application;)V", "database", "Lcom/example/data/db/AppDatabase;", "repository", "Lcom/example/data/repository/TransactionRepository;", "sharedPrefs", "Landroid/content/SharedPreferences;", "kotlin.jvm.PlatformType", "defaultEndpoint", "", "_endpointUrl", "Lkotlinx/coroutines/flow/MutableStateFlow;", "endpointUrl", "Lkotlinx/coroutines/flow/StateFlow;", "getEndpointUrl", "()Lkotlinx/coroutines/flow/StateFlow;", "_pollingIntervalSeconds", "", "pollingIntervalSeconds", "getPollingIntervalSeconds", "_pendingLaunchUrl", "pendingLaunchUrl", "getPendingLaunchUrl", "launchInBrowser", "", ImagesContract.URL, "clearPendingLaunch", "startSelfieWithSyncCode", "code", "onResult", "Lkotlin/Function2;", "", "Lkotlin/ParameterName;", "name", "success", "message", "transactions", "", "Lcom/example/data/model/Transaction;", "getTransactions", "activeJobs", "", "Lkotlinx/coroutines/Job;", "updateSettings", "newUrl", "interval", "tryBase64Decode", "str", "parseInputText", "Lcom/example/ui/viewmodel/TransactionViewModel$ParseResult;", "input", "addTransaction", "sess", "token", "isAutoPoll", "checkStatusSingle", "transaction", "toggleAutoPolling", "deleteTransaction", "startPollingJob", "stopPollingJob", "id", "onCleared", "ParseResult", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class TransactionViewModel extends AndroidViewModel {
    public static final int $stable = 8;
    private final MutableStateFlow<String> _endpointUrl;
    private final MutableStateFlow<String> _pendingLaunchUrl;
    private final MutableStateFlow<Integer> _pollingIntervalSeconds;
    private final Map<Integer, Job> activeJobs;
    private final AppDatabase database;
    private final String defaultEndpoint;
    private final StateFlow<String> endpointUrl;
    private final StateFlow<String> pendingLaunchUrl;
    private final StateFlow<Integer> pollingIntervalSeconds;
    private final TransactionRepository repository;
    private final SharedPreferences sharedPrefs;
    private final StateFlow<List<Transaction>> transactions;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TransactionViewModel(Application application) {
        String str;
        super(application);
        Intrinsics.checkNotNullParameter(application, "application");
        this.database = AppDatabase.INSTANCE.getDatabase(application);
        this.repository = new TransactionRepository(this.database.transactionDao(), AchatNetworkClient.INSTANCE.getApiService());
        this.sharedPrefs = application.getSharedPreferences("achat_tracker_prefs", 0);
        this.defaultEndpoint = "https://dz.blsappointment.com/Selfie2.0/check.php";
        TransactionViewModel transactionViewModel = this;
        String string = transactionViewModel.sharedPrefs.getString("endpoint_url", transactionViewModel.defaultEndpoint);
        string = string == null ? transactionViewModel.defaultEndpoint : string;
        if (StringsKt.isBlank(string) || StringsKt.contains((CharSequence) string, (CharSequence) "BLS_Selfie.php", true)) {
            transactionViewModel.sharedPrefs.edit().putString("endpoint_url", transactionViewModel.defaultEndpoint).apply();
            str = transactionViewModel.defaultEndpoint;
        } else {
            str = string;
        }
        this._endpointUrl = StateFlowKt.MutableStateFlow(str);
        this.endpointUrl = FlowKt.asStateFlow(this._endpointUrl);
        this._pollingIntervalSeconds = StateFlowKt.MutableStateFlow(Integer.valueOf(this.sharedPrefs.getInt("polling_interval", 5)));
        this.pollingIntervalSeconds = FlowKt.asStateFlow(this._pollingIntervalSeconds);
        this._pendingLaunchUrl = StateFlowKt.MutableStateFlow(null);
        this.pendingLaunchUrl = FlowKt.asStateFlow(this._pendingLaunchUrl);
        this.transactions = FlowKt.stateIn(this.repository.getAllTransactions(), ViewModelKt.getViewModelScope(this), SharingStarted.Companion.WhileSubscribed$default(SharingStarted.INSTANCE, 5000L, 0L, 2, null), CollectionsKt.emptyList());
        this.activeJobs = new LinkedHashMap();
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C1(null), 3, null);
    }

    public final StateFlow<String> getEndpointUrl() {
        return this.endpointUrl;
    }

    public final StateFlow<Integer> getPollingIntervalSeconds() {
        return this.pollingIntervalSeconds;
    }

    public final StateFlow<String> getPendingLaunchUrl() {
        return this.pendingLaunchUrl;
    }

    public final void launchInBrowser(String url) {
        Intrinsics.checkNotNullParameter(url, "url");
        this._pendingLaunchUrl.setValue(url);
    }

    public final void clearPendingLaunch() {
        this._pendingLaunchUrl.setValue(null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TransactionViewModel$startSelfieWithSyncCode$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TransactionViewModel.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    @DebugMetadata(m١٠٠٢٥c = "com.example.ui.viewmodel.TransactionViewModel$startSelfieWithSyncCode$1", m١٠٠٢٦f = "TransactionViewModel.kt", m١٠٠٢٧i = {}, m١٠٠٢٨l = {79}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {}, m١٠٠٣١s = {})
    static final class C٤٦٢٣1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $code;
        final /* synthetic */ Function2<Boolean, String, Unit> $onResult;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        /* JADX WARN: Multi-variable type inference failed */
        C٤٦٢٣1(String str, Function2<? super Boolean, ? super String, Unit> function2, Continuation<? super C٤٦٢٣1> continuation) {
            super(2, continuation);
            this.$code = str;
            this.$onResult = function2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TransactionViewModel.this.new C٤٦٢٣1(this.$code, this.$onResult, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C٤٦٢٣1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object value;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    Object obj = TransactionViewModel.this.repository.m٨٣٤٥resolveSyncCode0E7RQCE(StringsKt.trim((CharSequence) this.$code).toString(), (String) TransactionViewModel.this._endpointUrl.getValue(), this);
                    if (obj == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    value = obj;
                    break;
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    value = ((Result) $result).getValue();
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            TransactionViewModel transactionViewModel = TransactionViewModel.this;
            Function2<Boolean, String, Unit> function2 = this.$onResult;
            if (Result.m٨٨١٦isSuccessimpl(value)) {
                SyncCodeResponse syncCodeResponse = (SyncCodeResponse) value;
                String str = syncCodeResponse.getSession_id() + "," + syncCodeResponse.getClient_token();
                Charset UTF_8 = StandardCharsets.UTF_8;
                Intrinsics.checkNotNullExpressionValue(UTF_8, "UTF_8");
                byte[] bytes = str.getBytes(UTF_8);
                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                transactionViewModel.launchInBrowser("https://dz.blsappointment.com/Selfie2.0/BLS_Selfie.php?code=" + Base64.encodeToString(bytes, 2));
                function2.invoke(Boxing.boxBoolean(true), "OK");
            }
            Function2<Boolean, String, Unit> function3 = this.$onResult;
            Throwable th = Result.m٨٨١٢exceptionOrNullimpl(value);
            if (th != null) {
                Boolean boolBoxBoolean = Boxing.boxBoolean(false);
                String message = th.getMessage();
                if (message == null) {
                    message = "Invalid or expired code";
                }
                function3.invoke(boolBoxBoolean, message);
            }
            return Unit.INSTANCE;
        }
    }

    public final void startSelfieWithSyncCode(String code, Function2<? super Boolean, ? super String, Unit> onResult) {
        Intrinsics.checkNotNullParameter(code, "code");
        Intrinsics.checkNotNullParameter(onResult, "onResult");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C٤٦٢٣1(code, onResult, null), 3, null);
    }

    public final StateFlow<List<Transaction>> getTransactions() {
        return this.transactions;
    }

    /* JADX INFO: compiled from: TransactionViewModel.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0011\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0006HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00062\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000b¨\u0006\u001a"}, m٨٧٩٩d2 = {"Lcom/example/ui/viewmodel/TransactionViewModel$ParseResult;", "", "sess", "", "token", "success", "", "message", "<init>", "(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)V", "getSess", "()Ljava/lang/String;", "getToken", "getSuccess", "()Z", "getMessage", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "", "toString", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    public static final /* data */ class ParseResult {
        public static final int $stable = 0;
        private final String message;
        private final String sess;
        private final boolean success;
        private final String token;

        public static /* synthetic */ ParseResult copy$default(ParseResult parseResult, String str, String str2, boolean z, String str3, int i, Object obj) {
            if ((i & 1) != 0) {
                str = parseResult.sess;
            }
            if ((i & 2) != 0) {
                str2 = parseResult.token;
            }
            if ((i & 4) != 0) {
                z = parseResult.success;
            }
            if ((i & 8) != 0) {
                str3 = parseResult.message;
            }
            return parseResult.copy(str, str2, z, str3);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getSess() {
            return this.sess;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getToken() {
            return this.token;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final boolean getSuccess() {
            return this.success;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final String getMessage() {
            return this.message;
        }

        public final ParseResult copy(String sess, String token, boolean success, String message) {
            Intrinsics.checkNotNullParameter(sess, "sess");
            Intrinsics.checkNotNullParameter(token, "token");
            Intrinsics.checkNotNullParameter(message, "message");
            return new ParseResult(sess, token, success, message);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ParseResult)) {
                return false;
            }
            ParseResult parseResult = (ParseResult) other;
            return Intrinsics.areEqual(this.sess, parseResult.sess) && Intrinsics.areEqual(this.token, parseResult.token) && this.success == parseResult.success && Intrinsics.areEqual(this.message, parseResult.message);
        }

        public int hashCode() {
            return (((((this.sess.hashCode() * 31) + this.token.hashCode()) * 31) + Boolean.hashCode(this.success)) * 31) + this.message.hashCode();
        }

        public String toString() {
            return "ParseResult(sess=" + this.sess + ", token=" + this.token + ", success=" + this.success + ", message=" + this.message + ")";
        }

        public ParseResult(String sess, String token, boolean success, String message) {
            Intrinsics.checkNotNullParameter(sess, "sess");
            Intrinsics.checkNotNullParameter(token, "token");
            Intrinsics.checkNotNullParameter(message, "message");
            this.sess = sess;
            this.token = token;
            this.success = success;
            this.message = message;
        }

        public final String getSess() {
            return this.sess;
        }

        public final String getToken() {
            return this.token;
        }

        public final boolean getSuccess() {
            return this.success;
        }

        public final String getMessage() {
            return this.message;
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TransactionViewModel$1, reason: invalid class name */
    /* JADX INFO: compiled from: TransactionViewModel.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    @DebugMetadata(m١٠٠٢٥c = "com.example.ui.viewmodel.TransactionViewModel$1", m١٠٠٢٦f = "TransactionViewModel.kt", m١٠٠٢٧i = {}, m١٠٠٢٨l = {117}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {}, m١٠٠٣١s = {})
    static final class C1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        int label;

        C1(Continuation<? super C1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TransactionViewModel.this.new C1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    StateFlow<List<Transaction>> transactions = TransactionViewModel.this.getTransactions();
                    final TransactionViewModel transactionViewModel = TransactionViewModel.this;
                    this.label = 1;
                    if (transactions.collect(new FlowCollector() { // from class: com.example.ui.viewmodel.TransactionViewModel.1.1
                        @Override // kotlinx.coroutines.flow.FlowCollector
                        public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
                            return emit((List<Transaction>) value, (Continuation<? super Unit>) $completion);
                        }

                        public final Object emit(List<Transaction> list, Continuation<? super Unit> continuation) {
                            TransactionViewModel transactionViewModel2 = transactionViewModel;
                            for (Transaction transaction : list) {
                                if (transaction.isAutoPolling() && !Intrinsics.areEqual(transaction.getStatus(), "Success") && !transactionViewModel2.activeJobs.containsKey(Boxing.boxInt(transaction.getId()))) {
                                    transactionViewModel2.startPollingJob(transaction);
                                }
                            }
                            return Unit.INSTANCE;
                        }
                    }, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            throw new KotlinNothingValueException();
        }
    }

    public final void updateSettings(String newUrl, int interval) {
        Intrinsics.checkNotNullParameter(newUrl, "newUrl");
        this.sharedPrefs.edit().putString("endpoint_url", newUrl).putInt("polling_interval", interval).apply();
        this._endpointUrl.setValue(newUrl);
        this._pollingIntervalSeconds.setValue(Integer.valueOf(interval));
    }

    /* JADX WARN: Code duplicated, block: B:113:0x0181 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:83:0x0183 A[LOOP:3: B:100:0x0154->B:83:0x0183, LOOP_END] */
    private final String tryBase64Decode(String str) {
        String str2;
        char c;
        char c2;
        boolean z;
        char c3;
        String str3;
        boolean z2;
        String cleaned = new Regex("[^A-Za-z0-9+/=\\-_]").replace(StringsKt.trim((CharSequence) str).toString(), "");
        int i = 1;
        int i2 = 0;
        String str4 = null;
        if (cleaned.length() == 0) {
            return null;
        }
        char c4 = '\t';
        List flags = CollectionsKt.listOf((Object[]) new Integer[]{0, 1, 8, 9});
        Iterator it = flags.iterator();
        while (true) {
            char c5 = '\n';
            if (!it.hasNext()) {
                String str5 = str4;
                switch (cleaned.length() % 4) {
                    case 2:
                        str2 = cleaned + "==";
                        break;
                    case 3:
                        str2 = cleaned + "=";
                        break;
                    default:
                        str2 = cleaned;
                        break;
                }
                String padded = str2;
                if (!Intrinsics.areEqual(padded, cleaned)) {
                    Iterator it2 = flags.iterator();
                    while (it2.hasNext()) {
                        int flag = ((Number) it2.next()).intValue();
                        try {
                            byte[] decodedBytes = Base64.decode(padded, flag);
                            Intrinsics.checkNotNull(decodedBytes);
                            Charset UTF_8 = StandardCharsets.UTF_8;
                            Intrinsics.checkNotNullExpressionValue(UTF_8, "UTF_8");
                            String decodedStr = new String(decodedBytes, UTF_8);
                            if (decodedStr.length() > 0) {
                                String str6 = decodedStr;
                                int i3 = 0;
                                while (true) {
                                    try {
                                        if (i3 < str6.length()) {
                                            char cCharAt = str6.charAt(i3);
                                            if ((' ' <= cCharAt && cCharAt < 127) || cCharAt == c5 || cCharAt == '\r') {
                                                c2 = '\t';
                                            } else {
                                                c2 = '\t';
                                                if (cCharAt != '\t') {
                                                    c3 = 0;
                                                }
                                                if (c3 == 0) {
                                                    z = false;
                                                } else {
                                                    i3++;
                                                    c5 = '\n';
                                                }
                                            }
                                            c3 = 1;
                                            if (c3 == 0) {
                                                z = false;
                                            } else {
                                                i3++;
                                                c5 = '\n';
                                            }
                                        } else {
                                            c2 = '\t';
                                            z = true;
                                        }
                                    } catch (Exception e) {
                                        c = '\t';
                                        c4 = c;
                                        c5 = '\n';
                                    }
                                }
                                if (z) {
                                    return decodedStr;
                                }
                                c4 = c2;
                            }
                            c5 = '\n';
                        } catch (Exception e2) {
                            c = c4;
                        }
                    }
                }
                return str5;
            }
            int flag2 = ((Number) it.next()).intValue();
            try {
                byte[] decodedBytes2 = Base64.decode(cleaned, flag2);
                Intrinsics.checkNotNull(decodedBytes2);
                Charset UTF_9 = StandardCharsets.UTF_8;
                Intrinsics.checkNotNullExpressionValue(UTF_9, "UTF_8");
                String decodedStr2 = new String(decodedBytes2, UTF_9);
                if ((decodedStr2.length() > 0 ? i : i2) != 0) {
                    String str7 = decodedStr2;
                    int i4 = i2;
                    while (true) {
                        if (i4 >= str7.length()) {
                            str3 = str4;
                            z2 = true;
                            break;
                        }
                        char cCharAt2 = str7.charAt(i4);
                        str3 = str4;
                        if ((((' ' <= cCharAt2 && cCharAt2 < 127) || cCharAt2 == '\n' || cCharAt2 == '\r' || cCharAt2 == '\t') ? (char) 1 : (char) 0) == 0) {
                            z2 = false;
                            break;
                        }
                        i4++;
                        str4 = str3;
                    }
                    if (z2) {
                        return decodedStr2;
                    }
                    str4 = str3;
                }
                i = 1;
                i2 = 0;
            } catch (Exception e3) {
                str4 = str4;
                i = 1;
                i2 = 0;
            }
        }
    }

    public final ParseResult parseInputText(String input) {
        String str;
        String str2;
        String str3 = "q=";
        String str4 = ",";
        Intrinsics.checkNotNullParameter(input, "input");
        String trimmed = StringsKt.trim((CharSequence) input).toString();
        boolean z = false;
        if (trimmed.length() == 0) {
            return new ParseResult("", "", false, "Input is empty");
        }
        try {
            Object obj = null;
            int i = 2;
            if (StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "%", false, 2, (Object) null)) {
                for (int i2 = 0; i2 < 3; i2++) {
                    try {
                        if (!StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "%", false, 2, (Object) null)) {
                            break;
                        }
                        String strDecode = URLDecoder.decode(trimmed, StandardCharsets.UTF_8.name());
                        Intrinsics.checkNotNullExpressionValue(strDecode, "decode(...)");
                        trimmed = strDecode;
                    } catch (Exception e) {
                    }
                }
            }
            String extractedCode = trimmed;
            if (StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "?code=", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "&code=", false, 2, (Object) null)) {
                List querySplit = StringsKt.split$default((CharSequence) trimmed, new String[]{"code="}, false, 0, 6, (Object) null);
                if (querySplit.size() > 1) {
                    String rawCode = (String) StringsKt.split$default((CharSequence) querySplit.get(1), new String[]{"&"}, false, 0, 6, (Object) null).get(0);
                    String strDecode2 = URLDecoder.decode(rawCode, StandardCharsets.UTF_8.name());
                    Intrinsics.checkNotNullExpressionValue(strDecode2, "decode(...)");
                    extractedCode = strDecode2;
                }
            } else if (!StringsKt.contains$default((CharSequence) trimmed, (CharSequence) "q=", false, 2, (Object) null)) {
                str4 = ",";
            } else {
                String queryParams = (String) CollectionsKt.lastOrNull(StringsKt.split$default((CharSequence) trimmed, new String[]{"?"}, false, 0, 6, (Object) null));
                if (queryParams == null) {
                    queryParams = trimmed;
                }
                List<String> params = StringsKt.split$default((CharSequence) queryParams, new String[]{"&"}, false, 0, 6, (Object) null);
                for (String param : params) {
                    if (!StringsKt.startsWith$default(param, str3, z, i, obj)) {
                        str = str3;
                        str2 = str4;
                    } else {
                        String nestedUrl = param.substring(i);
                        Intrinsics.checkNotNullExpressionValue(nestedUrl, "substring(...)");
                        str = str3;
                        str2 = str4;
                        if (StringsKt.contains$default((CharSequence) nestedUrl, (CharSequence) "code=", false, 2, (Object) null)) {
                            List innerSplit = StringsKt.split$default((CharSequence) nestedUrl, new String[]{"code="}, false, 0, 6, (Object) null);
                            if (innerSplit.size() > 1) {
                                extractedCode = (String) StringsKt.split$default((CharSequence) innerSplit.get(1), new String[]{"&"}, false, 0, 6, (Object) null).get(0);
                                str3 = str;
                                str4 = str2;
                                z = false;
                                obj = null;
                                i = 2;
                            }
                        }
                    }
                    str3 = str;
                    str4 = str2;
                    z = false;
                    obj = null;
                    i = 2;
                }
                str4 = str4;
            }
            if (StringsKt.contains$default((CharSequence) extractedCode, (CharSequence) str4, false, 2, (Object) null)) {
                List parts = StringsKt.split$default((CharSequence) extractedCode, new String[]{str4}, false, 0, 6, (Object) null);
                if (parts.size() >= 2) {
                    String part1 = StringsKt.trim((CharSequence) parts.get(0)).toString();
                    String part2 = StringsKt.trim((CharSequence) parts.get(1)).toString();
                    String decodedSess = tryBase64Decode(part1);
                    if (decodedSess == null) {
                        decodedSess = part1;
                    }
                    String decodedToken = tryBase64Decode(part2);
                    if (decodedToken == null) {
                        decodedToken = part2;
                    }
                    if (decodedSess.length() > 0) {
                        if (decodedToken.length() > 0) {
                            return new ParseResult(decodedSess, decodedToken, true, "Success! Extracted and decoded session and token.");
                        }
                    }
                }
            }
            String decodedWhole = tryBase64Decode(extractedCode);
            if (decodedWhole != null && StringsKt.contains$default((CharSequence) decodedWhole, (CharSequence) str4, false, 2, (Object) null)) {
                List parts2 = StringsKt.split$default((CharSequence) decodedWhole, new String[]{str4}, false, 0, 6, (Object) null);
                if (parts2.size() >= 2) {
                    String sess = StringsKt.trim((CharSequence) parts2.get(0)).toString();
                    String token = StringsKt.trim((CharSequence) parts2.get(1)).toString();
                    if (sess.length() > 0) {
                        if (token.length() > 0) {
                            return new ParseResult(sess, token, true, "Success! Fully decoded code containing session and token.");
                        }
                    }
                }
            }
            String decodedSingle = tryBase64Decode(extractedCode);
            if (decodedSingle == null) {
                decodedSingle = extractedCode;
            }
            if (decodedSingle.length() == 32) {
                return new ParseResult(decodedSingle, "", false, "Detected a 32-character Session/Transaction ID, but Bearer Token is missing.");
            }
            return new ParseResult("", "", false, "Could not extract session ID and token. Make sure it is a valid base64 code or 'sess,token' pair.");
        } catch (Exception e2) {
            return new ParseResult("", "", false, "Decoding error: " + e2.getLocalizedMessage());
        }
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TransactionViewModel$addTransaction$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TransactionViewModel.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    @DebugMetadata(m١٠٠٢٥c = "com.example.ui.viewmodel.TransactionViewModel$addTransaction$1", m١٠٠٢٦f = "TransactionViewModel.kt", m١٠٠٢٧i = {1, 1, 2, 2, 3, 3, 3}, m١٠٠٢٨l = {275, 286, 299, 301}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {"existing", "updated", "existing", "newTx", "existing", "newTx", "newId"}, m١٠٠٣١s = {"L$0", "L$1", "L$0", "L$1", "L$0", "L$1", "I$0"})
    static final class C٤٦٢٠1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ boolean $isAutoPoll;
        final /* synthetic */ String $sess;
        final /* synthetic */ String $token;
        int I$0;
        Object L$0;
        Object L$1;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C٤٦٢٠1(String str, String str2, boolean z, Continuation<? super C٤٦٢٠1> continuation) {
            super(2, continuation);
            this.$sess = str;
            this.$token = str2;
            this.$isAutoPoll = z;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TransactionViewModel.this.new C٤٦٢٠1(this.$sess, this.$token, this.$isAutoPoll, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C٤٦٢٠1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:15:0x0064  */
        /* JADX WARN: Code duplicated, block: B:17:0x0099 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:18:0x009a  */
        /* JADX WARN: Code duplicated, block: B:21:0x00a2  */
        /* JADX WARN: Code duplicated, block: B:22:0x00a7  */
        /* JADX WARN: Code duplicated, block: B:23:0x00b0  */
        /* JADX WARN: Code duplicated, block: B:25:0x00ba  */
        /* JADX WARN: Code duplicated, block: B:26:0x00bd  */
        /* JADX WARN: Code duplicated, block: B:29:0x00f0 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:32:0x00fc  */
        /* JADX WARN: Code duplicated, block: B:34:0x011c A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:35:0x011d  */
        /* JADX WARN: Code duplicated, block: B:38:0x0123  */
        /* JADX WARN: Code duplicated, block: B:40:0x012a  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object transactionBySess;
            Transaction existing;
            Transaction newTx;
            String str;
            Object objInsert;
            Transaction updated;
            Transaction updated2;
            boolean z;
            TransactionViewModel transactionViewModel;
            int newId;
            Object transactionById;
            Transaction insertedTx;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    transactionBySess = TransactionViewModel.this.repository.getTransactionBySess(this.$sess, this);
                    if (transactionBySess == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    existing = (Transaction) transactionBySess;
                    if (existing != null) {
                        updated = Transaction.copy$default(existing, 0, null, this.$token, "Pending", null, this.$isAutoPoll, 0L, 0L, null, 67, null);
                        this.L$0 = SpillingKt.nullOutSpilledVariable(existing);
                        this.L$1 = updated;
                        this.label = 2;
                        if (TransactionViewModel.this.repository.update(updated, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        updated2 = updated;
                        z = this.$isAutoPoll;
                        transactionViewModel = TransactionViewModel.this;
                        if (z) {
                            transactionViewModel.startPollingJob(updated2);
                        } else {
                            transactionViewModel.stopPollingJob(updated2.getId());
                        }
                        return Unit.INSTANCE;
                    }
                    String str2 = this.$sess;
                    String str3 = this.$token;
                    if (this.$isAutoPoll) {
                        str = "Polling";
                    } else {
                        str = "Pending";
                    }
                    newTx = new Transaction(0, str2, str3, str, null, this.$isAutoPoll, 0L, 0L, null, 465, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(existing);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(newTx);
                    this.label = 3;
                    objInsert = TransactionViewModel.this.repository.insert(newTx, this);
                    if (objInsert == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    newId = (int) ((Number) objInsert).longValue();
                    if (this.$isAutoPoll) {
                        this.L$0 = SpillingKt.nullOutSpilledVariable(existing);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(newTx);
                        this.I$0 = newId;
                        this.label = 4;
                        transactionById = TransactionViewModel.this.repository.getTransactionById(newId, this);
                        if (transactionById == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        insertedTx = (Transaction) transactionById;
                        if (insertedTx != null) {
                            TransactionViewModel.this.startPollingJob(insertedTx);
                        }
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    transactionBySess = $result;
                    existing = (Transaction) transactionBySess;
                    if (existing != null) {
                        updated = Transaction.copy$default(existing, 0, null, this.$token, "Pending", null, this.$isAutoPoll, 0L, 0L, null, 67, null);
                        this.L$0 = SpillingKt.nullOutSpilledVariable(existing);
                        this.L$1 = updated;
                        this.label = 2;
                        if (TransactionViewModel.this.repository.update(updated, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        updated2 = updated;
                        z = this.$isAutoPoll;
                        transactionViewModel = TransactionViewModel.this;
                        if (z) {
                            transactionViewModel.startPollingJob(updated2);
                        } else {
                            transactionViewModel.stopPollingJob(updated2.getId());
                        }
                        return Unit.INSTANCE;
                    }
                    String str4 = this.$sess;
                    String str5 = this.$token;
                    if (this.$isAutoPoll) {
                        str = "Polling";
                    } else {
                        str = "Pending";
                    }
                    newTx = new Transaction(0, str4, str5, str, null, this.$isAutoPoll, 0L, 0L, null, 465, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(existing);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(newTx);
                    this.label = 3;
                    objInsert = TransactionViewModel.this.repository.insert(newTx, this);
                    if (objInsert == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    newId = (int) ((Number) objInsert).longValue();
                    if (this.$isAutoPoll) {
                        this.L$0 = SpillingKt.nullOutSpilledVariable(existing);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(newTx);
                        this.I$0 = newId;
                        this.label = 4;
                        transactionById = TransactionViewModel.this.repository.getTransactionById(newId, this);
                        if (transactionById == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        insertedTx = (Transaction) transactionById;
                        if (insertedTx != null) {
                            TransactionViewModel.this.startPollingJob(insertedTx);
                        }
                    }
                    return Unit.INSTANCE;
                case 2:
                    updated2 = (Transaction) this.L$1;
                    ResultKt.throwOnFailure($result);
                    z = this.$isAutoPoll;
                    transactionViewModel = TransactionViewModel.this;
                    if (z) {
                        transactionViewModel.startPollingJob(updated2);
                    } else {
                        transactionViewModel.stopPollingJob(updated2.getId());
                    }
                    return Unit.INSTANCE;
                case 3:
                    Transaction newTx2 = (Transaction) this.L$1;
                    existing = (Transaction) this.L$0;
                    ResultKt.throwOnFailure($result);
                    newTx = newTx2;
                    objInsert = $result;
                    newId = (int) ((Number) objInsert).longValue();
                    if (this.$isAutoPoll) {
                        this.L$0 = SpillingKt.nullOutSpilledVariable(existing);
                        this.L$1 = SpillingKt.nullOutSpilledVariable(newTx);
                        this.I$0 = newId;
                        this.label = 4;
                        transactionById = TransactionViewModel.this.repository.getTransactionById(newId, this);
                        if (transactionById == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                        insertedTx = (Transaction) transactionById;
                        if (insertedTx != null) {
                            TransactionViewModel.this.startPollingJob(insertedTx);
                        }
                    }
                    return Unit.INSTANCE;
                case 4:
                    int i = this.I$0;
                    existing = (Transaction) this.L$0;
                    ResultKt.throwOnFailure($result);
                    transactionById = $result;
                    insertedTx = (Transaction) transactionById;
                    if (insertedTx != null) {
                        TransactionViewModel.this.startPollingJob(insertedTx);
                    }
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public static /* synthetic */ void addTransaction$default(TransactionViewModel transactionViewModel, String str, String str2, boolean z, int i, Object obj) {
        if ((i & 4) != 0) {
            z = false;
        }
        transactionViewModel.addTransaction(str, str2, z);
    }

    public final void addTransaction(String sess, String token, boolean isAutoPoll) {
        Intrinsics.checkNotNullParameter(sess, "sess");
        Intrinsics.checkNotNullParameter(token, "token");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C٤٦٢٠1(sess, token, isAutoPoll, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TransactionViewModel$checkStatusSingle$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TransactionViewModel.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    @DebugMetadata(m١٠٠٢٥c = "com.example.ui.viewmodel.TransactionViewModel$checkStatusSingle$1", m١٠٠٢٦f = "TransactionViewModel.kt", m١٠٠٢٧i = {0, 1}, m١٠٠٢٨l = {314, 316}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {"checkingTx", "checkingTx"}, m١٠٠٣١s = {"L$0", "L$0"})
    static final class C٤٦٢١1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Transaction $transaction;
        Object L$0;
        int label;
        final /* synthetic */ TransactionViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C٤٦٢١1(Transaction transaction, TransactionViewModel transactionViewModel, Continuation<? super C٤٦٢١1> continuation) {
            super(2, continuation);
            this.$transaction = transaction;
            this.this$0 = transactionViewModel;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C٤٦٢١1(this.$transaction, this.this$0, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C٤٦٢١1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:13:0x0082 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:14:0x0083  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Transaction checkingTx;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    checkingTx = Transaction.copy$default(this.$transaction, 0, null, null, "Polling", null, false, 0L, 0L, null, 503, null);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(checkingTx);
                    this.label = 1;
                    if (this.this$0.repository.update(checkingTx, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    this.L$0 = SpillingKt.nullOutSpilledVariable(checkingTx);
                    this.label = 2;
                    if (this.this$0.repository.m٨٣٤٤checkSessionStatus0E7RQCE(this.$transaction, (String) this.this$0._endpointUrl.getValue(), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 1:
                    checkingTx = (Transaction) this.L$0;
                    ResultKt.throwOnFailure($result);
                    this.L$0 = SpillingKt.nullOutSpilledVariable(checkingTx);
                    this.label = 2;
                    if (this.this$0.repository.m٨٣٤٤checkSessionStatus0E7RQCE(this.$transaction, (String) this.this$0._endpointUrl.getValue(), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    ((Result) $result).getValue();
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void checkStatusSingle(Transaction transaction) {
        Intrinsics.checkNotNullParameter(transaction, "transaction");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C٤٦٢١1(transaction, this, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TransactionViewModel$toggleAutoPolling$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TransactionViewModel.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    @DebugMetadata(m١٠٠٢٥c = "com.example.ui.viewmodel.TransactionViewModel$toggleAutoPolling$1", m١٠٠٢٦f = "TransactionViewModel.kt", m١٠٠٢٧i = {0, 1}, m١٠٠٢٨l = {323, 331}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {"updated", "updated"}, m١٠٠٣١s = {"L$0", "L$0"})
    static final class C٤٦٢٤1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Transaction $transaction;
        Object L$0;
        int label;
        final /* synthetic */ TransactionViewModel this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C٤٦٢٤1(Transaction transaction, TransactionViewModel transactionViewModel, Continuation<? super C٤٦٢٤1> continuation) {
            super(2, continuation);
            this.$transaction = transaction;
            this.this$0 = transactionViewModel;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new C٤٦٢٤1(this.$transaction, this.this$0, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C٤٦٢٤1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:14:0x0063  */
        /* JADX WARN: Code duplicated, block: B:15:0x0067  */
        /* JADX WARN: Code duplicated, block: B:17:0x007a  */
        /* JADX WARN: Code duplicated, block: B:19:0x00a6 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:20:0x00a7  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Transaction updated;
            boolean zIsAutoPolling;
            TransactionViewModel transactionViewModel;
            Transaction updated2;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    Transaction updated3 = Transaction.copy$default(this.$transaction, 0, null, null, null, null, !this.$transaction.isAutoPolling(), 0L, 0L, null, 479, null);
                    this.L$0 = updated3;
                    this.label = 1;
                    if (this.this$0.repository.update(updated3, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    updated = updated3;
                    zIsAutoPolling = updated.isAutoPolling();
                    transactionViewModel = this.this$0;
                    if (zIsAutoPolling) {
                        transactionViewModel.startPollingJob(updated);
                    } else {
                        transactionViewModel.stopPollingJob(updated.getId());
                        if (Intrinsics.areEqual(updated.getStatus(), "Polling")) {
                            this.L$0 = SpillingKt.nullOutSpilledVariable(updated);
                            this.label = 2;
                            if (this.this$0.repository.update(Transaction.copy$default(updated, 0, null, null, "Pending", null, false, 0L, 0L, null, 503, null), this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            updated2 = updated;
                        }
                    }
                    return Unit.INSTANCE;
                case 1:
                    Transaction updated4 = (Transaction) this.L$0;
                    ResultKt.throwOnFailure($result);
                    updated = updated4;
                    zIsAutoPolling = updated.isAutoPolling();
                    transactionViewModel = this.this$0;
                    if (zIsAutoPolling) {
                        transactionViewModel.startPollingJob(updated);
                    } else {
                        transactionViewModel.stopPollingJob(updated.getId());
                        if (Intrinsics.areEqual(updated.getStatus(), "Polling")) {
                            this.L$0 = SpillingKt.nullOutSpilledVariable(updated);
                            this.label = 2;
                            if (this.this$0.repository.update(Transaction.copy$default(updated, 0, null, null, "Pending", null, false, 0L, 0L, null, 503, null), this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            updated2 = updated;
                        }
                    }
                    return Unit.INSTANCE;
                case 2:
                    updated2 = (Transaction) this.L$0;
                    ResultKt.throwOnFailure($result);
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    public final void toggleAutoPolling(Transaction transaction) {
        Intrinsics.checkNotNullParameter(transaction, "transaction");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C٤٦٢٤1(transaction, this, null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.ui.viewmodel.TransactionViewModel$deleteTransaction$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: TransactionViewModel.kt */
    @Metadata(m٨٧٩٨d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, m٨٧٩٩d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, m٨٨٠٠k = 3, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
    @DebugMetadata(m١٠٠٢٥c = "com.example.ui.viewmodel.TransactionViewModel$deleteTransaction$1", m١٠٠٢٦f = "TransactionViewModel.kt", m١٠٠٢٧i = {}, m١٠٠٢٨l = {340}, m١٠٠٢٩m = "invokeSuspend", m١٠٠٣٠n = {}, m١٠٠٣١s = {})
    static final class C٤٦٢٢1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Transaction $transaction;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C٤٦٢٢1(Transaction transaction, Continuation<? super C٤٦٢٢1> continuation) {
            super(2, continuation);
            this.$transaction = transaction;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return TransactionViewModel.this.new C٤٦٢٢1(this.$transaction, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C٤٦٢٢1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    TransactionViewModel.this.stopPollingJob(this.$transaction.getId());
                    this.label = 1;
                    if (TransactionViewModel.this.repository.delete(this.$transaction, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    break;
                case 1:
                    ResultKt.throwOnFailure($result);
                    break;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public final void deleteTransaction(Transaction transaction) {
        Intrinsics.checkNotNullParameter(transaction, "transaction");
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C٤٦٢٢1(transaction, null), 3, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void startPollingJob(Transaction transaction) {
        stopPollingJob(transaction.getId());
        Job job = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new TransactionViewModel$startPollingJob$job$1(transaction, this, null), 3, null);
        this.activeJobs.put(Integer.valueOf(transaction.getId()), job);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void stopPollingJob(int id) {
        Job job = this.activeJobs.get(Integer.valueOf(id));
        if (job != null) {
            Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
        }
        this.activeJobs.remove(Integer.valueOf(id));
    }

    @Override // androidx.lifecycle.ViewModel
    protected void onCleared() {
        super.onCleared();
        Iterator it = this.activeJobs.values().iterator();
        while (it.hasNext()) {
            Job.DefaultImpls.cancel$default((Job) it.next(), (CancellationException) null, 1, (Object) null);
        }
        this.activeJobs.clear();
    }
}
