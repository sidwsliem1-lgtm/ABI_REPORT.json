package com.example.util;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* JADX INFO: compiled from: DebugLog.kt */
/* JADX INFO: loaded from: classes8.dex */
@Metadata(m٨٧٩٨d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0007\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\n2\u0006\u0010\u0015\u001a\u00020\nJ\u0006\u0010\u0016\u001a\u00020\u0013J\u0006\u0010\u0017\u001a\u00020\nJ\u000e\u0010\u0018\u001a\u00020\n2\u0006\u0010\u0019\u001a\u00020\nR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u000b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\r0\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001d\u0010\u000e\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\r0\u000f¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001a"}, m٨٧٩٩d2 = {"Lcom/example/util/DebugLog;", "", "<init>", "()V", "MAX_LINES", "", "ts", "Ljava/text/SimpleDateFormat;", "buffer", "Ljava/util/ArrayDeque;", "", "_lines", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "lines", "Lkotlinx/coroutines/flow/StateFlow;", "getLines", "()Lkotlinx/coroutines/flow/StateFlow;", "add", "", "tag", "message", "clear", "dump", "maskToken", "token", "app"}, m٨٨٠٠k = 1, m٨٨٠١mv = {2, 2, 0}, m٨٨٠٣xi = 48)
public final class DebugLog {
    private static final int MAX_LINES = 800;
    public static final DebugLog INSTANCE = new DebugLog();
    private static final SimpleDateFormat ts = new SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault());
    private static final ArrayDeque<String> buffer = new ArrayDeque<>();
    private static final MutableStateFlow<List<String>> _lines = StateFlowKt.MutableStateFlow(CollectionsKt.emptyList());
    private static final StateFlow<List<String>> lines = FlowKt.asStateFlow(_lines);
    public static final int $stable = 8;

    private DebugLog() {
    }

    public final StateFlow<List<String>> getLines() {
        return lines;
    }

    public final synchronized void add(String tag, String message) {
        Intrinsics.checkNotNullParameter(tag, "tag");
        Intrinsics.checkNotNullParameter(message, "message");
        String line = "[" + ts.format(new Date()) + "] [" + tag + "] " + message;
        buffer.addLast(line);
        while (buffer.size() > MAX_LINES) {
            buffer.pollFirst();
        }
        _lines.setValue(CollectionsKt.toList(buffer));
    }

    public final synchronized void clear() {
        buffer.clear();
        _lines.setValue(CollectionsKt.emptyList());
    }

    public final synchronized String dump() {
        return CollectionsKt.joinToString$default(buffer, "\n", null, null, 0, null, null, 62, null);
    }

    public final String maskToken(String token) {
        Intrinsics.checkNotNullParameter(token, "token");
        String t = StringsKt.trim((CharSequence) StringsKt.removePrefix(token, (CharSequence) "Bearer ")).toString();
        if (t.length() <= 6) {
            return "****";
        }
        return "****" + StringsKt.takeLast(t, 6) + " (len=" + t.length() + ")";
    }
}
